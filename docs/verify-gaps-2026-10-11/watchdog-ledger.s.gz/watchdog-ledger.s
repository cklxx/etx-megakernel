	.amdgcn_target "amdgcn-amd-amdhsa-unknown-gfx942"
	.amdhsa_code_object_version 6
	.text
	.protected	etx_megakernel_d0       ; -- Begin function etx_megakernel_d0
	.globl	etx_megakernel_d0
	.p2align	8
	.type	etx_megakernel_d0,@function
etx_megakernel_d0:                      ; @etx_megakernel_d0
	.cfi_startproc
; %bb.0:
	.cfi_escape 0x0f, 0x04, 0x30, 0x36, 0xe9, 0x02 ; CFA is 0 in private_wave aspace
	.cfi_undefined 16
	s_load_dwordx2 s[46:47], s[0:1], 0xe8
	s_load_dwordx4 s[28:31], s[0:1], 0xd8
	s_load_dwordx4 s[36:39], s[0:1], 0x150
	s_load_dwordx8 s[12:19], s[0:1], 0x130
	s_load_dwordx2 s[34:35], s[0:1], 0x10
	s_load_dwordx2 s[2:3], s[0:1], 0x20
                                        ; implicit-def: $vgpr126 : SGPR spill to VGPR lane
	v_cmp_eq_u32_e64 s[10:11], 0, v0
	s_waitcnt lgkmcnt(0)
	v_writelane_b32 v126, s2, 0
	s_nop 1
	v_writelane_b32 v126, s3, 1
	s_and_saveexec_b64 s[2:3], s[10:11]
	s_cbranch_execz .LBB0_4
; %bb.1:
	s_load_dword s8, s[0:1], 0x98
	s_mov_b64 s[4:5], exec
	v_mbcnt_lo_u32_b32 v1, s4, 0
	s_getreg_b32 s6, hwreg(HW_REG_XCC_ID, 0, 4)
	v_mbcnt_hi_u32_b32 v1, s5, v1
	s_and_b32 s9, s6, 15
	v_cmp_eq_u32_e32 vcc, 0, v1
                                        ; implicit-def: $vgpr2
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_3
; %bb.2:
	s_load_dwordx2 s[20:21], s[0:1], 0x90
	s_lshl_b32 s22, s9, 2
	s_bcnt1_i32_b64 s4, s[4:5]
	v_mov_b32_e32 v2, s22
	v_mov_b32_e32 v3, s4
	s_waitcnt lgkmcnt(0)
	global_atomic_add v2, v2, v3, s[20:21] sc0
.LBB0_3:
	s_or_b64 exec, exec, s[6:7]
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s4, v2
	s_waitcnt lgkmcnt(0)
	s_mul_i32 s9, s9, s8
	v_add_u32_e32 v1, s4, v1
	v_add_u32_e32 v2, s9, v1
	v_cmp_gt_i32_e32 vcc, s8, v1
	s_nop 1
	v_cndmask_b32_e32 v1, -1, v2, vcc
	v_mov_b32_e32 v2, 0
	ds_write_b32 v2, v1 offset:21144
.LBB0_4:                                ; %Flow661
	s_or_b64 exec, exec, s[2:3]
	v_mov_b32_e32 v33, 0
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b32 v26, v33 offset:21144
	s_load_dword s33, s[0:1], 0x18
	s_load_dwordx8 s[20:27], s[0:1], 0x40
	s_waitcnt lgkmcnt(0)
	v_cmp_eq_u32_e32 vcc, -1, v26
	s_cbranch_vccnz .LBB0_6
; %bb.5:
	v_mov_b32_e32 v27, 0
	v_lshlrev_b64 v[2:3], 2, v[26:27]
	v_lshl_add_u64 v[4:5], s[26:27], 0, v[2:3]
	v_lshl_add_u64 v[2:3], s[24:25], 0, v[2:3]
	global_load_dword v34, v[2:3], off
	global_load_dword v1, v[4:5], off
	s_branch .LBB0_7
.LBB0_6:
	v_mov_b64_e32 v[26:27], 0xffffffff
	v_mov_b32_e32 v1, 0
	v_mov_b32_e32 v34, 0
.LBB0_7:
	s_cmp_lg_u64 s[28:29], 0
	s_cselect_b64 s[2:3], -1, 0
	s_and_b64 s[48:49], s[2:3], s[10:11]
	s_cmp_lg_u64 s[30:31], 0
	s_cselect_b64 s[2:3], -1, 0
	s_and_b64 s[50:51], s[10:11], s[2:3]
	s_cmp_lg_u64 s[12:13], 0
	s_cselect_b64 s[2:3], -1, 0
	v_writelane_b32 v126, s2, 2
	s_and_b64 s[54:55], s[10:11], s[2:3]
	s_add_u32 s56, s0, 0x160
	v_writelane_b32 v126, s3, 3
	v_cmp_gt_u32_e64 s[2:3], 64, v0
	s_addc_u32 s57, s1, 0
	v_and_b32_e32 v36, 63, v0
	v_writelane_b32 v126, s2, 4
	s_cmp_lg_u64 s[16:17], 0
	v_cmp_eq_u32_e64 s[4:5], 0, v36
	v_writelane_b32 v126, s3, 5
	s_cselect_b64 s[2:3], -1, 0
	s_load_dword s6, s[0:1], 0x16c
	s_and_b64 s[60:61], s[4:5], s[2:3]
	s_cmp_eq_u64 s[14:15], 0
	s_cselect_b64 s[2:3], -1, 0
	s_cmp_lg_u64 s[14:15], 0
	s_cselect_b64 s[0:1], -1, 0
	s_cmp_lg_u64 s[38:39], 0
	s_cselect_b64 s[8:9], -1, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s88, s6, 0xffff
	v_lshlrev_b32_e32 v48, 2, v0
	s_cmpk_gt_u32 s88, 0x1ff
	v_and_b32_e32 v2, 0xfc, v48
	s_cselect_b64 s[64:65], -1, 0
	s_bfe_u32 s89, s6, 0xa0006
	v_xor_b32_e32 v49, 0x80, v2
	v_cvt_f32_u32_e32 v2, s89
	s_sub_i32 s6, 0, s89
	v_lshrrev_b32_e32 v3, 2, v0
	v_and_b32_e32 v32, 0xf0, v3
	v_rcp_f32_e32 v2, v2
	s_add_i32 s90, s89, -1
	s_bfe_u32 s92, s88, 0x30006
	s_and_b32 s93, s89, 0x3f8
	v_mul_f32_e32 v2, 0x4f7ffffe, v2
	v_cvt_u32_f32_e32 v2, v2
	v_lshl_add_u64 v[38:39], s[16:17], 0, v[32:33]
	v_and_b32_e32 v32, 0xf8, v3
	v_writelane_b32 v126, s8, 6
	v_readfirstlane_b32 s7, v2
	s_mul_i32 s6, s6, s7
	s_mul_hi_u32 s6, s7, s6
	s_add_i32 s91, s7, s6
	s_cmp_lg_u32 s92, 0
	v_lshl_add_u64 v[40:41], s[16:17], 0, v[32:33]
	s_cselect_b64 s[16:17], -1, 0
	s_cmp_gt_u32 s90, 6
	v_writelane_b32 v126, s9, 7
	s_cselect_b64 s[6:7], -1, 0
	v_writelane_b32 v126, s6, 8
	v_mov_b32_e32 v4, 0
	s_xor_b64 s[2:3], s[2:3], -1
	v_writelane_b32 v126, s7, 9
	v_mbcnt_lo_u32_b32 v2, -1, 0
	v_writelane_b32 v126, s2, 10
	v_mbcnt_hi_u32_b32 v63, -1, v2
	v_lshlrev_b32_e32 v37, 4, v36
	s_mov_b32 s59, 0
	v_mov_b32_e32 v5, v4
	v_mov_b32_e32 v6, v4
	v_mov_b32_e32 v7, v4
	v_mov_b32_e32 v8, v4
	v_mov_b32_e32 v9, v4
	v_writelane_b32 v126, s3, 11
	s_movk_i32 s2, 0x5000
	v_and_b32_e32 v2, 64, v63
	v_add_u32_e32 v50, v37, v37
	v_or_b32_e32 v51, 64, v0
	v_add_u32_e32 v52, -4, v0
	v_add_u32_e32 v53, -3, v0
	v_add_u32_e32 v54, -2, v0
	v_add_u32_e32 v55, -1, v0
	v_lshlrev_b32_e32 v56, 5, v0
	s_lshl_b32 s94, s88, 5
	v_lshl_or_b32 v42, v0, 4, 8
	v_mov_b32_e32 v43, s59
	s_lshl_b32 s68, s88, 4
	s_mov_b32 s69, s59
	s_lshl_b32 s95, s88, 2
	v_mov_b32_e32 v57, -1
	v_mov_b64_e32 v[44:45], 0
	s_movk_i32 s97, 0x7fff
	v_add_u32_e64 v58, s2, 0
	v_lshlrev_b32_e32 v59, 1, v0
	v_mov_b32_e32 v60, 0x800000
	v_mov_b32_e32 v61, 0x7fc00000
	v_mov_b32_e32 v62, 0x7f800000
	v_add_u32_e32 v64, 64, v2
	v_xor_b32_e32 v65, 32, v63
	v_xor_b32_e32 v66, 16, v63
	v_xor_b32_e32 v67, 8, v63
	v_xor_b32_e32 v68, 4, v63
	v_xor_b32_e32 v69, 2, v63
	v_xor_b32_e32 v70, 1, v63
	v_mov_b32_e32 v71, 1
	v_mov_b64_e32 v[80:81], v[8:9]
	v_mov_b64_e32 v[78:79], v[6:7]
	v_mov_b64_e32 v[76:77], v[4:5]
	v_mov_b64_e32 v[74:75], v[2:3]
	v_mov_b64_e32 v[88:89], v[8:9]
	v_mov_b64_e32 v[86:87], v[6:7]
	v_mov_b64_e32 v[84:85], v[4:5]
	v_mov_b64_e32 v[82:83], v[2:3]
                                        ; implicit-def: $sgpr2
                                        ; kill: killed $sgpr2
                                        ; implicit-def: $vgpr28_vgpr29_vgpr30_vgpr31
                                        ; implicit-def: $vgpr102_vgpr103_vgpr104_vgpr105
                                        ; implicit-def: $vgpr110_vgpr111
                                        ; implicit-def: $vgpr108_vgpr109
                                        ; implicit-def: $vgpr106_vgpr107
                                        ; implicit-def: $vgpr98_vgpr99_vgpr100_vgpr101
	s_branch .LBB0_9
.LBB0_8:                                ; %Flow390
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_barrier
.LBB0_9:                                ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_74 Depth 2
                                        ;     Child Loop BB0_80 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;       Child Loop BB0_159 Depth 3
                                        ;       Child Loop BB0_164 Depth 3
                                        ;       Child Loop BB0_193 Depth 3
                                        ;         Child Loop BB0_195 Depth 4
                                        ;         Child Loop BB0_199 Depth 4
                                        ;       Child Loop BB0_90 Depth 3
                                        ;       Child Loop BB0_95 Depth 3
                                        ;       Child Loop BB0_149 Depth 3
                                        ;         Child Loop BB0_151 Depth 4
                                        ;         Child Loop BB0_155 Depth 4
                                        ;     Child Loop BB0_226 Depth 2
                                        ;     Child Loop BB0_258 Depth 2
                                        ;     Child Loop BB0_264 Depth 2
                                        ;     Child Loop BB0_508 Depth 2
                                        ;     Child Loop BB0_513 Depth 2
                                        ;     Child Loop BB0_542 Depth 2
                                        ;       Child Loop BB0_544 Depth 3
                                        ;       Child Loop BB0_548 Depth 3
                                        ;     Child Loop BB0_272 Depth 2
                                        ;       Child Loop BB0_275 Depth 3
                                        ;       Child Loop BB0_280 Depth 3
                                        ;       Child Loop BB0_333 Depth 3
                                        ;         Child Loop BB0_335 Depth 4
                                        ;         Child Loop BB0_339 Depth 4
                                        ;       Child Loop BB0_344 Depth 3
                                        ;       Child Loop BB0_349 Depth 3
                                        ;       Child Loop BB0_378 Depth 3
                                        ;         Child Loop BB0_380 Depth 4
                                        ;         Child Loop BB0_384 Depth 4
                                        ;     Child Loop BB0_388 Depth 2
                                        ;       Child Loop BB0_391 Depth 3
                                        ;       Child Loop BB0_396 Depth 3
                                        ;       Child Loop BB0_449 Depth 3
                                        ;         Child Loop BB0_451 Depth 4
                                        ;         Child Loop BB0_455 Depth 4
                                        ;       Child Loop BB0_460 Depth 3
                                        ;       Child Loop BB0_465 Depth 3
                                        ;       Child Loop BB0_494 Depth 3
                                        ;         Child Loop BB0_496 Depth 4
                                        ;         Child Loop BB0_500 Depth 4
                                        ;     Child Loop BB0_551 Depth 2
                                        ;     Child Loop BB0_241 Depth 2
	s_and_saveexec_b64 s[6:7], s[10:11]
	s_cbranch_execz .LBB0_15
; %bb.10:                               ;   in Loop: Header=BB0_9 Depth=1
	s_waitcnt vmcnt(0)
	v_cmp_ge_i32_e32 vcc, v34, v1
	s_and_saveexec_b64 s[2:3], vcc
	s_xor_b64 s[8:9], exec, s[2:3]
; %bb.11:                               ;   in Loop: Header=BB0_9 Depth=1
	ds_write_b32 v33, v57 offset:21140
; %bb.12:                               ; %Flow657
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_andn2_saveexec_b64 s[8:9], s[8:9]
	s_cbranch_execz .LBB0_14
; %bb.13:                               ;   in Loop: Header=BB0_9 Depth=1
	v_ashrrev_i32_e32 v35, 31, v34
	v_lshl_add_u64 v[10:11], v[34:35], 2, s[20:21]
	v_mad_i64_i32 v[12:13], s[2:3], v34, 20, s[22:23]
	global_load_dwordx4 v[14:17], v[12:13], off
	s_nop 0
	global_load_dword v12, v[12:13], off offset:16
	s_nop 0
	global_load_dword v10, v[10:11], off
	v_add_u32_e32 v34, 1, v34
	s_waitcnt vmcnt(2)
	ds_write_b128 v33, v[14:17] offset:21120
	s_waitcnt vmcnt(0)
	ds_write2_b32 v58, v12, v10 offset0:164 offset1:165
.LBB0_14:                               ; %Flow658
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[8:9]
.LBB0_15:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b32 v10, v33 offset:21140
	s_waitcnt lgkmcnt(0)
	v_cmp_gt_i32_e32 vcc, 0, v10
	v_readfirstlane_b32 s58, v10
	s_cbranch_vccnz .LBB0_34
; %bb.16:                               ;   in Loop: Header=BB0_9 Depth=1
	ds_read_b64 v[10:11], v33 offset:21120
	s_waitcnt lgkmcnt(0)
	v_readfirstlane_b32 s98, v10
	v_readfirstlane_b32 s99, v11
	s_and_saveexec_b64 s[6:7], s[48:49]
	s_cbranch_execz .LBB0_19
; %bb.17:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[8:9], exec
	v_mbcnt_lo_u32_b32 v10, s8, 0
	v_mbcnt_hi_u32_b32 v10, s9, v10
	v_cmp_eq_u32_e32 vcc, 0, v10
	s_and_b64 s[2:3], exec, vcc
	s_mov_b64 exec, s[2:3]
	s_cbranch_execz .LBB0_19
; %bb.18:                               ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[2:3], s[58:59], 2
	s_add_u32 s2, s28, s2
	s_addc_u32 s3, s29, s3
	s_bcnt1_i32_b64 s8, s[8:9]
	v_mov_b32_e32 v10, s8
	global_atomic_add v33, v10, s[2:3]
.LBB0_19:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_lshl_b64 s[2:3], s[58:59], 5
	s_add_u32 s72, s30, s2
	s_addc_u32 s73, s31, s3
	s_and_saveexec_b64 s[6:7], s[50:51]
	s_cbranch_execz .LBB0_21
; %bb.20:                               ;   in Loop: Header=BB0_9 Depth=1
	s_memrealtime s[2:3]
	s_waitcnt lgkmcnt(0)
	v_mov_b64_e32 v[10:11], s[2:3]
	global_store_dwordx2 v33, v[10:11], s[72:73]
	s_or_b64 exec, exec, s[6:7]
	s_and_saveexec_b64 s[6:7], s[54:55]
	s_cbranch_execz .LBB0_23
	s_branch .LBB0_22
.LBB0_21:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_and_saveexec_b64 s[6:7], s[54:55]
	s_cbranch_execz .LBB0_23
.LBB0_22:                               ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[2:3], s[58:59], 3
	s_add_u32 s2, s12, s2
	s_addc_u32 s3, s13, s3
	global_store_dwordx2 v33, v[44:45], s[2:3]
.LBB0_23:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_cmp_lt_i32 s98, 1
	s_mov_b64 s[6:7], -1
                                        ; implicit-def: $sgpr2
                                        ; implicit-def: $sgpr96
	s_cbranch_scc1 .LBB0_33
; %bb.24:                               ; %LeafBlock376
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_cmp_eq_u32 s98, 1
	s_cbranch_scc0 .LBB0_35
; %bb.25:                               ;   in Loop: Header=BB0_9 Depth=1
	s_and_saveexec_b64 s[6:7], s[10:11]
	s_cbranch_execz .LBB0_39
; %bb.26:                               ;   in Loop: Header=BB0_9 Depth=1
	v_mov_b32_e32 v10, v33
	;;#ASMSTART
	;;#ASMEND
	v_readlane_b32 s2, v126, 0
	v_lshlrev_b32_e32 v10, 5, v10
	v_ashrrev_i32_e32 v11, 31, v10
	v_readlane_b32 s3, v126, 1
	s_nop 1
	v_lshl_add_u64 v[10:11], v[10:11], 2, s[2:3]
	global_load_dword v12, v[10:11], off sc1
	s_waitcnt vmcnt(0)
	v_cmp_lt_i32_e32 vcc, 0, v12
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_36
; %bb.27:                               ; %.preheader82
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s2, 1
	s_mov_b64 s[24:25], 0
	s_branch .LBB0_29
.LBB0_28:                               ; %Flow648
                                        ;   in Loop: Header=BB0_29 Depth=2
	s_and_b64 s[26:27], exec, s[26:27]
	s_or_b64 s[24:25], s[26:27], s[24:25]
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execz .LBB0_36
.LBB0_29:                               ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	s_and_b32 s3, s2, 0xff
	s_cselect_b64 s[26:27], -1, 0
	s_and_b64 vcc, exec, s[26:27]
	s_sleep 8
	s_cbranch_vccnz .LBB0_31
; %bb.30:                               ;   in Loop: Header=BB0_29 Depth=2
	global_load_dword v12, v33, s[46:47] sc1
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s3, v12
	s_cmp_eq_u32 s3, 0
	s_cselect_b64 s[26:27], -1, 0
.LBB0_31:                               ; %Flow647
                                        ;   in Loop: Header=BB0_29 Depth=2
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s3, 1, 0
	s_cmp_lg_u32 s3, 1
	s_mov_b64 s[26:27], -1
	s_cbranch_scc1 .LBB0_28
; %bb.32:                               ;   in Loop: Header=BB0_29 Depth=2
	global_load_dword v12, v[10:11], off sc1
	s_add_i32 s2, s2, 1
	s_waitcnt vmcnt(0)
	v_cmp_gt_i32_e32 vcc, 1, v12
	s_orn2_b64 s[26:27], vcc, exec
	s_branch .LBB0_28
.LBB0_33:                               ; %Flow654
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_and_b64 s[6:7], s[6:7], exec
	s_cselect_b32 s3, 1, 0
	s_cmp_lg_u32 s3, 1
	s_cbranch_scc1 .LBB0_44
	s_branch .LBB0_41
.LBB0_34:                               ;   in Loop: Header=BB0_9 Depth=1
                                        ; implicit-def: $vgpr82_vgpr83_vgpr84_vgpr85_vgpr86_vgpr87_vgpr88_vgpr89
                                        ; implicit-def: $vgpr74_vgpr75_vgpr76_vgpr77_vgpr78_vgpr79_vgpr80_vgpr81
                                        ; implicit-def: $vgpr2_vgpr3_vgpr4_vgpr5_vgpr6_vgpr7_vgpr8_vgpr9
                                        ; implicit-def: $vgpr98_vgpr99_vgpr100_vgpr101
                                        ; implicit-def: $vgpr106_vgpr107
                                        ; implicit-def: $vgpr108_vgpr109
                                        ; implicit-def: $vgpr110_vgpr111
                                        ; implicit-def: $vgpr102_vgpr103_vgpr104_vgpr105
                                        ; implicit-def: $vgpr28_vgpr29_vgpr30_vgpr31
                                        ; implicit-def: $sgpr2
                                        ; kill: killed $sgpr2
	s_cbranch_execz .LBB0_9
	s_branch .LBB0_553
.LBB0_35:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s96, 0
	s_mov_b32 s2, -1
	s_branch .LBB0_40
.LBB0_36:                               ; %Flow650
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_readlane_b32 s2, v126, 2
	v_readlane_b32 s3, v126, 3
	s_and_b64 s[2:3], s[2:3], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_cbranch_scc1 .LBB0_38
; %bb.37:                               ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[2:3], s[58:59], 3
	s_add_u32 s2, s12, s2
	s_addc_u32 s3, s13, s3
	;;#ASMSTART
	s_memrealtime s[8:9]
	;;#ASMEND
	s_nop 0
	v_mov_b64_e32 v[10:11], s[8:9]
	global_store_dwordx2 v33, v[10:11], s[2:3]
.LBB0_38:                               ;   in Loop: Header=BB0_9 Depth=1
	;;#ASMSTART
	buffer_inv sc1
	;;#ASMEND
.LBB0_39:                               ; %Flow651
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_movk_i32 s96, 0xa0
	s_mov_b32 s2, 1
.LBB0_40:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[6:7], 0
	s_and_b64 s[6:7], s[6:7], exec
	s_cselect_b32 s3, 1, 0
	s_cmp_lg_u32 s3, 1
	s_cbranch_scc1 .LBB0_44
.LBB0_41:                               ; %LeafBlock
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_cmp_lg_u32 s98, 0
	s_mov_b32 s2, -1
	s_cbranch_scc1 .LBB0_43
; %bb.42:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s2, 0
.LBB0_43:                               ; %Flow653
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s96, 0
.LBB0_44:                               ;   in Loop: Header=BB0_9 Depth=1
	s_barrier
	s_and_saveexec_b64 s[6:7], s[50:51]
	s_cbranch_execz .LBB0_46
; %bb.45:                               ;   in Loop: Header=BB0_9 Depth=1
	s_memrealtime s[8:9]
	s_waitcnt lgkmcnt(0)
	v_mov_b64_e32 v[10:11], s[8:9]
	global_store_dwordx2 v33, v[10:11], s[72:73] offset:8
.LBB0_46:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mul_i32 s6, s98, s33
	s_ashr_i32 s7, s6, 31
	s_lshl_b64 s[6:7], s[6:7], 3
	s_add_u32 s74, s34, s6
	s_addc_u32 s75, s35, s7
	s_cmp_gt_i32 s2, 0
	s_mov_b64 s[6:7], -1
                                        ; implicit-def: $vgpr90_vgpr91_vgpr92_vgpr93_vgpr94_vgpr95_vgpr96_vgpr97
                                        ; implicit-def: $vgpr10_vgpr11_vgpr12_vgpr13_vgpr14_vgpr15_vgpr16_vgpr17
	s_cbranch_scc0 .LBB0_202
; %bb.47:                               ;   in Loop: Header=BB0_9 Depth=1
	s_load_dwordx2 s[6:7], s[74:75], 0x0
	s_ashr_i32 s67, s96, 31
	v_mov_b64_e32 v[96:97], v[88:89]
	v_mov_b64_e32 v[94:95], v[86:87]
	v_mov_b64_e32 v[92:93], v[84:85]
	s_waitcnt lgkmcnt(0)
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s67
	s_load_dword s3, s[8:9], 0x9c
	v_mov_b64_e32 v[90:91], v[82:83]
	v_mov_b64_e32 v[10:11], v[74:75]
	v_mov_b64_e32 v[12:13], v[76:77]
	v_mov_b64_e32 v[14:15], v[78:79]
	s_waitcnt lgkmcnt(0)
	s_cmp_ge_i32 s99, s3
	v_mov_b64_e32 v[16:17], v[80:81]
	s_cbranch_scc1 .LBB0_201
; %bb.48:                               ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s67
	s_load_dwordx2 s[24:25], s[8:9], 0x38
	s_load_dword s62, s[8:9], 0x30
	s_abs_i32 s8, s99
	v_mov_b64_e32 v[96:97], v[88:89]
	v_mov_b64_e32 v[94:95], v[86:87]
	s_waitcnt lgkmcnt(0)
	s_abs_i32 s3, s25
	v_cvt_f32_u32_e32 v10, s3
	s_sub_i32 s26, 0, s3
	s_xor_b32 s9, s99, s25
	s_ashr_i32 s9, s9, 31
	v_rcp_f32_e32 v10, v10
	v_mov_b64_e32 v[92:93], v[84:85]
	v_mov_b64_e32 v[90:91], v[82:83]
	v_mov_b64_e32 v[12:13], v[76:77]
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	v_mov_b64_e32 v[14:15], v[78:79]
	v_mov_b64_e32 v[16:17], v[80:81]
	v_readfirstlane_b32 s27, v10
	s_mul_i32 s26, s26, s27
	s_mul_hi_u32 s26, s27, s26
	s_add_i32 s27, s27, s26
	s_mul_hi_u32 s26, s8, s27
	s_mul_i32 s27, s26, s3
	s_sub_i32 s8, s8, s27
	s_add_i32 s40, s26, 1
	s_sub_i32 s27, s8, s3
	s_cmp_ge_u32 s8, s3
	s_cselect_b32 s26, s40, s26
	s_cselect_b32 s8, s27, s8
	s_add_i32 s27, s26, 1
	s_cmp_ge_u32 s8, s3
	s_cselect_b32 s3, s27, s26
	s_xor_b32 s3, s3, s9
	s_sub_i32 s76, s3, s9
	s_mul_i32 s3, s76, s25
	s_sub_i32 s3, s99, s3
	s_mul_i32 s53, s3, s24
	s_add_i32 s3, s53, s24
	s_min_i32 s3, s62, s3
	s_cmp_ge_i32 s53, s3
	v_mov_b64_e32 v[10:11], v[74:75]
	s_cbranch_scc1 .LBB0_201
; %bb.49:                               ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s67
	s_load_dwordx4 s[24:27], s[8:9], 0x0
	s_load_dwordx2 s[78:79], s[8:9], 0x10
	s_load_dwordx4 s[40:43], s[8:9], 0x20
	s_load_dword s52, s[8:9], 0x34
	s_load_dword s63, s[8:9], 0x68
	s_mov_b64 s[8:9], -1
                                        ; implicit-def: $sgpr70
	s_waitcnt lgkmcnt(0)
	s_cmp_lt_i32 s63, 2
	s_cselect_b64 s[80:81], -1, 0
	s_and_b64 vcc, exec, s[80:81]
	s_cbranch_vccz .LBB0_51
; %bb.50:                               ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s67
	s_load_dwordx2 s[8:9], s[8:9], 0x18
	s_ashr_i32 s77, s76, 31
	s_lshl_b64 s[44:45], s[76:77], 2
	s_waitcnt lgkmcnt(0)
	s_add_u32 s8, s8, s44
	s_addc_u32 s9, s9, s45
	global_load_dword v10, v33, s[8:9] sc0 sc1
	s_mov_b64 s[8:9], 0
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s70, v10
.LBB0_51:                               ; %Flow468
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b32 s66, s52, 2
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_cbranch_scc1 .LBB0_78
; %bb.52:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[82:83], exec
	v_readlane_b32 s8, v126, 4
	v_readlane_b32 s9, v126, 5
	s_and_b64 s[8:9], s[82:83], s[8:9]
	s_mov_b64 exec, s[8:9]
	s_cbranch_execz .LBB0_77
; %bb.53:                               ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s6, s6, s96
	s_addc_u32 s7, s7, s67
	s_load_dword s70, s[6:7], 0x6c
	s_load_dwordx2 s[84:85], s[6:7], 0x70
	s_load_dword s67, s[6:7], 0x60
	v_mov_b32_e32 v10, 0xff800000
	v_mov_b32_e32 v12, v10
	s_waitcnt lgkmcnt(0)
	v_cmp_gt_i32_e64 s[6:7], s70, v0
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execz .LBB0_55
; %bb.54:                               ;   in Loop: Header=BB0_9 Depth=1
	global_load_ushort v11, v59, s[84:85] sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v12, 16, v11
.LBB0_55:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_cmp_gt_i32_e64 s[8:9], s70, v51
	s_and_saveexec_b64 s[86:87], s[8:9]
	s_cbranch_execz .LBB0_57
; %bb.56:                               ;   in Loop: Header=BB0_9 Depth=1
	global_load_ushort v10, v59, s[84:85] offset:128 sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v10, 16, v10
.LBB0_57:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[86:87]
	v_mov_b32_e32 v16, 0
	v_mov_b32_e32 v15, v16
	s_and_saveexec_b64 s[44:45], s[6:7]
	s_xor_b64 s[84:85], exec, s[44:45]
	s_cbranch_execz .LBB0_59
; %bb.58:                               ;   in Loop: Header=BB0_9 Depth=1
	v_bfe_u32 v11, v12, 16, 15
	s_mov_b32 s44, 0x8000
	v_sub_u32_e32 v11, 0x8000, v11
	v_or_b32_sdwa v13, v12, s44 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v12
	s_nop 1
	v_cndmask_b32_e32 v11, v13, v11, vcc
	v_lshl_or_b32 v11, v11, 7, v60
	v_cmp_o_f32_e32 vcc, v12, v12
	s_nop 1
	v_cndmask_b32_e32 v11, v60, v11, vcc
	v_or_b32_e32 v11, v11, v0
	v_xor_b32_e32 v15, 0x7f, v11
.LBB0_59:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[84:85]
	s_and_saveexec_b64 s[84:85], s[8:9]
	s_cbranch_execz .LBB0_61
; %bb.60:                               ;   in Loop: Header=BB0_9 Depth=1
	v_bfe_u32 v11, v10, 16, 15
	s_mov_b32 s44, 0x8000
	v_sub_u32_e32 v11, 0x8000, v11
	v_or_b32_sdwa v13, v10, s44 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v10
	s_nop 1
	v_cndmask_b32_e32 v11, v13, v11, vcc
	v_lshl_or_b32 v11, v11, 7, v60
	v_cmp_o_f32_e32 vcc, v10, v10
	s_nop 1
	v_cndmask_b32_e32 v11, v60, v11, vcc
	v_or_b32_e32 v11, v11, v51
	v_xor_b32_e32 v16, 0x7f, v11
.LBB0_61:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[84:85]
	v_max_u32_e32 v11, v15, v16
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s70, v11, 63
	s_lshr_b32 s44, s70, 7
	s_bfe_u32 s45, s70, 0x100007
	s_add_i32 s71, s44, 0xffff8000
	s_sub_i32 s44, 0x8000, s44
	s_bitset1_b32 s44, 15
	s_cmpk_gt_u32 s45, 0x7fff
	s_cselect_b32 s44, s71, s44
	s_lshl_b32 s44, s44, 16
	s_cmp_lg_u32 s45, 0
	v_mov_b32_e32 v11, s44
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v61, v11, vcc
	v_mov_b32_e32 v11, 0
	v_mov_b32_e32 v13, v11
	s_and_saveexec_b64 s[84:85], s[6:7]
	s_cbranch_execz .LBB0_63
; %bb.62:                               ;   in Loop: Header=BB0_9 Depth=1
	v_sub_f32_e32 v12, v12, v14
	v_mul_f32_e32 v13, 0x3fb8aa3b, v12
	s_mov_b32 s44, 0x3fb8aa3b
	v_fma_f32 v17, v12, s44, -v13
	v_rndne_f32_e32 v18, v13
	v_fmac_f32_e32 v17, 0x32a5705f, v12
	v_sub_f32_e32 v13, v13, v18
	v_add_f32_e32 v13, v13, v17
	v_cvt_i32_f32_e32 v17, v18
	v_exp_f32_e32 v13, v13
	s_mov_b32 s44, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s44, v12
	s_mov_b32 s44, 0x42b17218
	v_ldexp_f32 v13, v13, v17
	v_cndmask_b32_e32 v13, 0, v13, vcc
	v_cmp_nlt_f32_e32 vcc, s44, v12
	s_nop 1
	v_cndmask_b32_e32 v13, v62, v13, vcc
.LBB0_63:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[84:85]
	v_mov_b32_e32 v12, 0
	s_and_saveexec_b64 s[84:85], s[8:9]
	s_cbranch_execz .LBB0_65
; %bb.64:                               ;   in Loop: Header=BB0_9 Depth=1
	v_sub_f32_e32 v10, v10, v14
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10
	s_mov_b32 s44, 0x3fb8aa3b
	v_fma_f32 v14, v10, s44, -v11
	v_rndne_f32_e32 v17, v11
	v_fmac_f32_e32 v14, 0x32a5705f, v10
	v_sub_f32_e32 v11, v11, v17
	v_add_f32_e32 v11, v11, v14
	v_cvt_i32_f32_e32 v14, v17
	v_exp_f32_e32 v11, v11
	s_mov_b32 s44, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s44, v10
	s_mov_b32 s44, 0x42b17218
	v_ldexp_f32 v11, v11, v14
	v_cndmask_b32_e32 v11, 0, v11, vcc
	v_cmp_nlt_f32_e32 vcc, s44, v10
	s_nop 1
	v_cndmask_b32_e32 v11, v62, v11, vcc
.LBB0_65:                               ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[84:85]
	v_cmp_lt_u32_e32 vcc, v65, v64
	v_add_f32_e32 v10, v13, v11
	s_cmp_lt_i32 s67, 1
	v_cndmask_b32_e32 v14, v63, v65, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v66, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v66, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v67, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v67, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v68, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v68, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v69, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v69, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v70, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v70, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	s_cbranch_scc1 .LBB0_71
; %bb.66:                               ;   in Loop: Header=BB0_9 Depth=1
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_div_scale_f32 v12, s[44:45], v10, v10, 1.0
	v_rcp_f32_e32 v14, v12
	v_div_scale_f32 v17, vcc, 1.0, v10, 1.0
	v_fma_f32 v18, -v12, v14, 1.0
	v_fmac_f32_e32 v14, v18, v14
	v_mul_f32_e32 v18, v17, v14
	v_fma_f32 v19, -v12, v18, v17
	v_fmac_f32_e32 v18, v19, v14
	v_fma_f32 v12, -v12, v18, v17
	v_div_fmas_f32 v12, v12, v14, v18
	v_div_fixup_f32 v10, v12, v10, 1.0
	v_mul_f32_e32 v12, v10, v13
	v_mul_f32_e32 v11, v10, v11
	v_cndmask_b32_e64 v10, 0, v12, s[6:7]
	s_andn2_b32 s6, 0x7f, s70
	s_cmp_lg_u32 s70, 0
	s_cselect_b32 s6, s6, 0
	s_cmp_gt_u32 s6, 63
	v_cndmask_b32_e64 v11, 0, v11, s[8:9]
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v12, v10, v11, vcc
	s_cmp_eq_u32 s67, 1
	v_readlane_b32 s7, v12, s6
	s_nop 1
	v_mov_b32_e32 v12, s7
	v_cndmask_b32_e64 v13, 0, v12, s[10:11]
	v_mov_b32_e32 v12, s6
	v_cndmask_b32_e64 v14, 0, v12, s[10:11]
	v_add_f32_e64 v12, s7, 0
	s_cbranch_scc1 .LBB0_75
; %bb.67:                               ;   in Loop: Header=BB0_9 Depth=1
	v_cmp_ne_u32_e32 vcc, s70, v15
	s_add_i32 s6, s67, -1
	s_add_i32 s7, s67, -2
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s70, v16
	s_and_b32 s8, s6, 3
	s_cmp_lt_u32 s7, 3
	v_cndmask_b32_e32 v16, 0, v16, vcc
	s_cbranch_scc1 .LBB0_72
; %bb.68:                               ;   in Loop: Header=BB0_9 Depth=1
	s_and_b32 s7, s6, -4
	s_mov_b32 s6, 0
.LBB0_69:                               ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_max_u32_e32 v17, v15, v16
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	v_max_u32_e32 v17, v15, v16
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v18, s9
	v_readlane_b32 s9, v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s6, v55
	v_mov_b32_e32 v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_nop 0
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	v_max_u32_e32 v17, v15, v16
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v18, s9
	v_readlane_b32 s9, v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s6, v54
	v_mov_b32_e32 v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_nop 0
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	v_max_u32_e32 v17, v15, v16
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v18, s9
	v_readlane_b32 s9, v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s6, v53
	v_mov_b32_e32 v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_nop 0
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v18, v10, v11, vcc
	v_mov_b32_e32 v17, s9
	v_readlane_b32 s9, v18, s9
	v_cmp_eq_u32_e32 vcc, s6, v52
	s_add_i32 s6, s6, 4
	v_mov_b32_e32 v18, s9
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v18, vcc
	s_cmp_eq_u32 s7, s6
	v_cndmask_b32_e32 v14, v14, v17, vcc
	s_cbranch_scc0 .LBB0_69
; %bb.70:                               ;   in Loop: Header=BB0_9 Depth=1
	s_add_i32 s9, s6, 1
	s_cmp_lg_u32 s8, 0
	s_cselect_b64 s[6:7], -1, 0
	s_and_b64 vcc, exec, s[6:7]
	s_cbranch_vccnz .LBB0_73
	s_branch .LBB0_75
.LBB0_71:                               ;   in Loop: Header=BB0_9 Depth=1
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v14, 0
	v_mov_b32_e32 v13, 0
	s_branch .LBB0_75
.LBB0_72:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s9, 1
	s_cbranch_execz .LBB0_75
.LBB0_73:                               ;   in Loop: Header=BB0_9 Depth=1
	v_subrev_u32_e32 v17, s9, v0
.LBB0_74:                               ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_max_u32_e32 v18, v15, v16
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s6, v18, 63
	s_andn2_b32 s7, 0x7f, s6
	s_cmp_lg_u32 s6, 0
	v_cmp_ne_u32_e32 vcc, s6, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s6, v16
	s_cselect_b32 s6, s7, 0
	s_cmp_gt_u32 s6, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_mov_b32_e32 v18, s6
	v_readlane_b32 s6, v19, s6
	s_add_i32 s8, s8, -1
	v_subrev_co_u32_e32 v17, vcc, 1, v17
	v_mov_b32_e32 v19, s6
	s_cmp_lg_u32 s8, 0
	v_add_f32_e32 v12, s6, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_cbranch_scc1 .LBB0_74
.LBB0_75:                               ;   in Loop: Header=BB0_9 Depth=1
	v_cmp_gt_i32_e32 vcc, s67, v0
	s_and_b64 exec, exec, vcc
	s_cbranch_execz .LBB0_77
; %bb.76:                               ;   in Loop: Header=BB0_9 Depth=1
	v_div_scale_f32 v10, s[6:7], v12, v12, v13
	v_rcp_f32_e32 v11, v10
	v_div_scale_f32 v15, vcc, v13, v12, v13
	s_cmp_eq_u32 s63, 3
	v_fma_f32 v16, -v10, v11, 1.0
	v_fmac_f32_e32 v11, v16, v11
	v_mul_f32_e32 v16, v15, v11
	v_fma_f32 v17, -v10, v16, v15
	v_fmac_f32_e32 v16, v17, v11
	v_fma_f32 v10, -v10, v16, v15
	v_div_fmas_f32 v10, v10, v11, v16
	v_div_fixup_f32 v10, v10, v12, v13
	s_cselect_b64 vcc, -1, 0
	v_lshl_add_u32 v11, v0, 2, s66
	v_cndmask_b32_e32 v10, v13, v10, vcc
	v_add_u32_e32 v11, 0x1000, v11
	ds_write2_b32 v11, v14, v10 offset1:16
.LBB0_77:                               ; %Flow467
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[82:83]
	s_lshl2_add_u32 s6, s76, s66
	v_mov_b32_e32 v10, s6
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b32 v10, v10 offset:4096
	s_ashr_i32 s77, s76, 31
	s_waitcnt lgkmcnt(0)
	v_readfirstlane_b32 s70, v10
.LBB0_78:                               ;   in Loop: Header=BB0_9 Depth=1
	s_ashr_i32 s67, s52, 31
	s_lshr_b32 s6, s67, 29
	s_add_i32 s6, s52, s6
	s_ashr_i32 s63, s6, 3
	v_cmp_gt_i32_e32 vcc, s63, v0
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_81
; %bb.79:                               ; %.preheader79
                                        ;   in Loop: Header=BB0_9 Depth=1
	v_lshl_add_u64 v[10:11], s[26:27], 0, v[42:43]
	s_lshl_b32 s26, s76, 1
	s_lshr_b64 s[8:9], s[76:77], 31
	s_mul_i32 s27, s26, s67
	s_mul_i32 s8, s8, s52
	v_mov_b32_e32 v12, s52
	s_add_i32 s27, s27, s8
	v_mad_u64_u32 v[10:11], s[8:9], s26, v12, v[10:11]
	v_add_u32_e32 v11, s27, v11
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v12, v56
	v_mov_b32_e32 v13, v0
.LBB0_80:                               ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	global_load_dwordx2 v[18:19], v[10:11], off offset:-8 sc0 sc1
	global_load_dwordx2 v[20:21], v[10:11], off sc0 sc1
	v_add_u32_e32 v13, s88, v13
	v_cmp_le_i32_e32 vcc, s63, v13
	v_lshl_add_u64 v[10:11], v[10:11], 0, s[68:69]
	s_or_b64 s[8:9], vcc, s[8:9]
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v15, 0xffff0000, v18
	v_lshlrev_b32_e32 v14, 16, v18
	v_and_b32_e32 v17, 0xffff0000, v19
	v_lshlrev_b32_e32 v16, 16, v19
	ds_write_b128 v12, v[14:17]
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v15, 0xffff0000, v20
	v_lshlrev_b32_e32 v14, 16, v20
	v_and_b32_e32 v17, 0xffff0000, v21
	v_lshlrev_b32_e32 v16, 16, v21
	ds_write_b128 v12, v[14:17] offset:16
	v_add_u32_e32 v12, s94, v12
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB0_80
.LBB0_81:                               ; %Flow458
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_and_b64 vcc, exec, s[80:81]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cbranch_vccz .LBB0_83
; %bb.82:                               ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[6:7], s[76:77], 2
	s_add_u32 s6, s40, s6
	s_addc_u32 s7, s41, s7
	global_load_dword v35, v33, s[6:7] sc0 sc1
	s_mov_b64 s[6:7], 0
	s_and_b64 s[6:7], s[6:7], exec
	s_cselect_b32 s6, 1, 0
	s_cmp_lg_u32 s6, 1
	s_cbranch_scc0 .LBB0_84
	s_branch .LBB0_85
.LBB0_83:                               ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[6:7], -1
                                        ; implicit-def: $vgpr35
	s_and_b64 s[6:7], s[6:7], exec
	s_cselect_b32 s6, 1, 0
	s_cmp_lg_u32 s6, 1
	s_cbranch_scc1 .LBB0_85
.LBB0_84:                               ;   in Loop: Header=BB0_9 Depth=1
	s_lshl2_add_u32 s6, s76, s66
	v_mov_b32_e32 v10, s6
	s_waitcnt vmcnt(0)
	ds_read_b32 v35, v10 offset:4160
.LBB0_85:                               ;   in Loop: Header=BB0_9 Depth=1
	s_ashr_i32 s6, s62, 31
	s_mul_hi_u32 s7, s76, s62
	s_mul_i32 s6, s76, s6
	s_add_i32 s6, s7, s6
	s_mul_i32 s7, s77, s62
	s_add_i32 s7, s6, s7
	s_mul_i32 s6, s76, s62
	s_lshl_b64 s[6:7], s[6:7], 1
	s_add_u32 s6, s78, s6
	s_addc_u32 s7, s79, s7
	s_ashr_i32 s8, s70, 31
	s_mul_hi_u32 s9, s42, s70
	s_mul_i32 s8, s42, s8
	s_add_i32 s8, s9, s8
	s_mul_i32 s9, s43, s70
	s_add_i32 s9, s8, s9
	s_mul_i32 s8, s42, s70
	s_lshl_b64 s[8:9], s[8:9], 1
	s_add_u32 s80, s24, s8
	s_addc_u32 s81, s25, s9
	s_and_b32 s8, s52, 0x1ff
	s_cselect_b64 s[8:9], -1, 0
	v_lshl_add_u32 v72, s52, 2, v48
	v_mov_b64_e32 v[96:97], v[88:89]
	v_mov_b64_e32 v[94:95], v[86:87]
	v_mov_b64_e32 v[92:93], v[84:85]
	v_mov_b64_e32 v[90:91], v[82:83]
	v_mov_b64_e32 v[10:11], v[74:75]
	v_mov_b64_e32 v[12:13], v[76:77]
	v_mov_b64_e32 v[14:15], v[78:79]
	v_mov_b64_e32 v[16:17], v[80:81]
	s_branch .LBB0_87
.LBB0_86:                               ;   in Loop: Header=BB0_87 Depth=2
	v_mov_b64_e32 v[96:97], v[24:25]
	v_mov_b64_e32 v[94:95], v[22:23]
	v_mov_b64_e32 v[92:93], v[20:21]
	v_mov_b64_e32 v[90:91], v[18:19]
	s_cmp_lt_i32 s82, s3
	s_mov_b32 s53, s82
	s_waitcnt lgkmcnt(0)
	s_cbranch_scc0 .LBB0_201
.LBB0_87:                               ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_159 Depth 3
                                        ;       Child Loop BB0_164 Depth 3
                                        ;       Child Loop BB0_193 Depth 3
                                        ;         Child Loop BB0_195 Depth 4
                                        ;         Child Loop BB0_199 Depth 4
                                        ;       Child Loop BB0_90 Depth 3
                                        ;       Child Loop BB0_95 Depth 3
                                        ;       Child Loop BB0_149 Depth 3
                                        ;         Child Loop BB0_151 Depth 4
                                        ;         Child Loop BB0_155 Depth 4
	s_add_i32 s82, s53, 64
	s_min_i32 s83, s3, s82
	s_and_b64 vcc, exec, s[8:9]
	s_mul_hi_i32 s25, s53, s52
	s_mul_i32 s24, s53, s52
	s_cbranch_vccz .LBB0_111
; %bb.88:                               ;   in Loop: Header=BB0_87 Depth=2
	s_load_dword s26, s[56:57], 0xc
	s_sub_i32 s85, s83, s53
	v_readfirstlane_b32 s42, v0
	s_waitcnt lgkmcnt(0)
	s_bfe_u32 s62, s26, 0xa0006
	s_mul_i32 s43, s62, s85
	s_and_b32 s84, s26, 0xffff
	v_cmp_gt_i32_e32 vcc, s43, v0
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execz .LBB0_91
; %bb.89:                               ; %.preheader65
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_lshl_b32 s63, s84, 2
	s_mov_b64 s[40:41], 0
	v_mov_b32_e32 v18, v72
	v_mov_b32_e32 v19, v0
.LBB0_90:                               ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	v_add_u32_e32 v19, s84, v19
	v_cmp_le_i32_e32 vcc, s43, v19
	ds_write_b32 v18, v33
	s_or_b64 s[40:41], vcc, s[40:41]
	v_add_u32_e32 v18, s63, v18
	s_andn2_b64 exec, exec, s[40:41]
	s_cbranch_execnz .LBB0_90
.LBB0_91:                               ; %Flow424
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_cvt_f32_u32_e32 v18, s62
	s_lshr_b32 s26, s67, 24
	s_add_i32 s26, s52, s26
	s_ashr_i32 s86, s26, 8
	v_rcp_f32_e32 v18, v18
	s_lshr_b32 s63, s42, 6
	s_mul_i32 s26, s85, s86
	s_sub_i32 s41, 0, s62
	v_mul_f32_e32 v18, 0x4f7ffffe, v18
	v_cvt_u32_f32_e32 v18, v18
	s_add_i32 s27, s26, s62
	s_add_i32 s27, s27, -1
	s_ashr_i32 s40, s27, 31
	v_readfirstlane_b32 s42, v18
	s_mul_i32 s41, s41, s42
	s_mul_hi_u32 s41, s42, s41
	s_abs_i32 s27, s27
	s_add_i32 s42, s42, s41
	s_mul_hi_u32 s41, s27, s42
	s_mul_i32 s42, s41, s62
	s_sub_i32 s27, s27, s42
	s_add_i32 s42, s41, 1
	s_sub_i32 s43, s27, s62
	s_cmp_ge_u32 s27, s62
	s_cselect_b32 s41, s42, s41
	s_cselect_b32 s27, s43, s27
	s_add_i32 s42, s41, 1
	s_cmp_ge_u32 s27, s62
	s_cselect_b32 s27, s42, s41
	s_xor_b32 s27, s27, s40
	s_sub_i32 s27, s27, s40
	s_mul_i32 s78, s27, s63
	s_add_i32 s27, s78, s27
	s_min_i32 s79, s26, s27
	s_lshl_b64 s[26:27], s[24:25], 1
	s_add_u32 s26, s80, s26
	s_addc_u32 s27, s81, s27
	s_abs_i32 s40, s86
	v_cvt_f32_u32_e32 v18, s40
	s_sub_i32 s43, 0, s40
	s_abs_i32 s42, s78
	s_xor_b32 s41, s78, s86
	v_rcp_f32_e32 v18, v18
	s_ashr_i32 s41, s41, 31
	v_mov_b32_e32 v73, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v18, 0x4f7ffffe, v18
	v_cvt_u32_f32_e32 v18, v18
	s_barrier
	v_readfirstlane_b32 s44, v18
	s_mul_i32 s43, s43, s44
	s_mul_hi_u32 s43, s44, s43
	s_add_i32 s44, s44, s43
	s_mul_hi_u32 s43, s42, s44
	s_mul_i32 s44, s43, s40
	s_sub_i32 s42, s42, s44
	s_add_i32 s44, s43, 1
	s_sub_i32 s45, s42, s40
	s_cmp_ge_u32 s42, s40
	s_cselect_b32 s43, s44, s43
	s_cselect_b32 s42, s45, s42
	s_add_i32 s44, s43, 1
	s_cmp_ge_u32 s42, s40
	s_cselect_b32 s40, s44, s43
	s_xor_b32 s40, s40, s41
	s_sub_i32 vcc_lo, s40, s41
	s_mul_i32 s40, vcc_lo, s86
	s_sub_i32 s70, s78, s40
	s_add_i32 s40, s78, 4
	s_cmp_le_i32 s40, s79
	s_cbranch_scc0 .LBB0_112
; %bb.92:                               ;   in Loop: Header=BB0_87 Depth=2
	v_lshlrev_b32_e32 v32, 3, v36
	s_mul_i32 s40, s63, s85
	v_lshl_add_u64 v[18:19], s[26:27], 0, v[32:33]
	s_lshl2_add_u32 vcc_hi, s40, s66
	v_mov_b32_e32 v73, 0
	s_mov_b32 s40, s78
	s_mov_b32 s87, vcc_lo
	s_branch .LBB0_95
.LBB0_93:                               ; %Flow412
                                        ;   in Loop: Header=BB0_95 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v32, 0
	s_mov_b32 s87, s41
.LBB0_94:                               ;   in Loop: Header=BB0_95 Depth=3
	s_and_b64 s[42:43], s[42:43], exec
	s_cselect_b32 s42, 0, s70
	v_lshl_or_b32 v46, s42, 10, v37
	ds_read_b128 v[112:115], v46
	s_add_i32 s70, s42, 1
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v117, 0xffff0000, v24
	v_lshlrev_b32_e32 v116, 16, v24
	s_cmp_eq_u32 s70, s86
	v_and_b32_e32 v47, 0xffff0000, v25
	v_lshlrev_b32_e32 v46, 16, v25
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	s_cselect_b64 s[42:43], -1, 0
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v73, v112, v113
	s_and_b64 s[44:45], s[42:43], exec
	v_add_f32_e32 v46, v73, v46
	s_cselect_b32 s70, 0, s70
	s_cmp_lg_u64 s[42:43], 0
	v_add_f32_e32 v46, v46, v47
	s_addc_u32 vcc_lo, s41, 0
	s_add_i32 s76, s40, 4
	s_add_i32 s40, s40, 8
	v_add_f32_e32 v73, v32, v46
	s_cmp_le_i32 s40, s79
	s_mov_b32 s40, s76
	s_cbranch_scc0 .LBB0_113
.LBB0_95:                               ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_ashr_i32 s41, s40, 31
	s_lshl_b64 s[42:43], s[40:41], 9
	v_lshl_add_u64 v[20:21], v[18:19], 0, s[42:43]
	s_add_i32 s42, s40, 1
	s_ashr_i32 s43, s42, 31
	s_lshl_b64 s[42:43], s[42:43], 9
	global_load_dwordx2 v[46:47], v[20:21], off nt
	v_lshl_add_u64 v[20:21], v[18:19], 0, s[42:43]
	s_add_i32 s42, s40, 2
	s_ashr_i32 s43, s42, 31
	s_lshl_b64 s[42:43], s[42:43], 9
	v_lshl_add_u64 v[22:23], v[18:19], 0, s[42:43]
	s_add_i32 s42, s40, 3
	s_ashr_i32 s43, s42, 31
	s_lshl_b64 s[42:43], s[42:43], 9
	v_lshl_add_u64 v[24:25], v[18:19], 0, s[42:43]
	global_load_dwordx2 v[20:21], v[20:21], off nt
	s_cmp_eq_u32 vcc_lo, s87
	global_load_dwordx2 v[22:23], v[22:23], off nt
	s_nop 0
	global_load_dwordx2 v[24:25], v[24:25], off nt
	s_cbranch_scc1 .LBB0_99
; %bb.96:                               ;   in Loop: Header=BB0_95 Depth=3
	ds_bpermute_b32 v32, v49, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v73, v32
	ds_swizzle_b32 v73, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v73
	v_mov_b32_e32 v73, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v73, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[42:43], s[4:5]
	s_cbranch_execz .LBB0_98
; %bb.97:                               ;   in Loop: Header=BB0_95 Depth=3
	s_lshl2_add_u32 s41, s87, vcc_hi
	v_add_f32_e32 v32, v32, v73
	v_mov_b32_e32 v73, s41
	ds_read_b32 v112, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v112
	ds_write_b32 v73, v32
.LBB0_98:                               ; %Flow417
                                        ;   in Loop: Header=BB0_95 Depth=3
	s_or_b64 exec, exec, s[42:43]
	v_mov_b32_e32 v73, 0
.LBB0_99:                               ;   in Loop: Header=BB0_95 Depth=3
	v_lshl_or_b32 v32, s70, 10, v37
	ds_read_b128 v[112:115], v32
	s_waitcnt vmcnt(3)
	v_and_b32_e32 v117, 0xffff0000, v47
	v_lshlrev_b32_e32 v116, 16, v47
	v_and_b32_e32 v47, 0xffff0000, v46
	v_lshlrev_b32_e32 v46, 16, v46
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[112:113], v[46:47]
	v_pk_mul_f32 v[114:115], v[114:115], v[116:117]
	v_add_f32_e32 v32, v46, v47
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v32, v32, v114
	s_cmp_eq_u32 s70, s86
	v_add_f32_e32 v32, v32, v115
	s_cselect_b64 s[42:43], -1, 0
	s_addc_u32 s41, vcc_lo, 0
	s_cmp_lg_u32 s70, s86
	v_add_f32_e32 v32, v73, v32
	s_cbranch_scc1 .LBB0_103
; %bb.100:                              ;   in Loop: Header=BB0_95 Depth=3
	ds_bpermute_b32 v46, v49, v32
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_102
; %bb.101:                              ;   in Loop: Header=BB0_95 Depth=3
	s_lshl2_add_u32 s44, vcc_lo, vcc_hi
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_102:                              ; %Flow416
                                        ;   in Loop: Header=BB0_95 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v32, 0
	s_mov_b32 vcc_lo, s41
.LBB0_103:                              ;   in Loop: Header=BB0_95 Depth=3
	s_and_b64 s[42:43], s[42:43], exec
	s_cselect_b32 s70, 0, s70
	v_lshl_or_b32 v46, s70, 10, v37
	ds_read_b128 v[112:115], v46
	s_waitcnt vmcnt(2)
	v_and_b32_e32 v117, 0xffff0000, v20
	v_lshlrev_b32_e32 v116, 16, v20
	v_and_b32_e32 v47, 0xffff0000, v21
	v_lshlrev_b32_e32 v46, 16, v21
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v73, v112, v113
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v46, v73, v46
	s_cmp_eq_u32 s70, s86
	v_add_f32_e32 v46, v46, v47
	s_cselect_b64 s[42:43], -1, 0
	s_addc_u32 s41, s41, 0
	s_cmp_eq_u32 s41, vcc_lo
	v_add_f32_e32 v32, v32, v46
	s_cbranch_scc1 .LBB0_107
; %bb.104:                              ;   in Loop: Header=BB0_95 Depth=3
	ds_bpermute_b32 v46, v49, v32
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_106
; %bb.105:                              ;   in Loop: Header=BB0_95 Depth=3
	s_lshl2_add_u32 s44, vcc_lo, vcc_hi
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_106:                              ; %Flow414
                                        ;   in Loop: Header=BB0_95 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v32, 0
	s_mov_b32 vcc_lo, s41
.LBB0_107:                              ;   in Loop: Header=BB0_95 Depth=3
	s_and_b64 s[42:43], s[42:43], exec
	s_cselect_b32 s70, 0, s70
	v_lshl_or_b32 v46, s70, 10, v37
	ds_read_b128 v[112:115], v46
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v117, 0xffff0000, v22
	v_lshlrev_b32_e32 v116, 16, v22
	v_and_b32_e32 v47, 0xffff0000, v23
	v_lshlrev_b32_e32 v46, 16, v23
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v73, v112, v113
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v46, v73, v46
	s_cmp_eq_u32 s70, s86
	v_add_f32_e32 v46, v46, v47
	s_cselect_b64 s[42:43], -1, 0
	s_addc_u32 s41, s41, 0
	s_cmp_eq_u32 s41, vcc_lo
	v_add_f32_e32 v32, v32, v46
	s_cbranch_scc1 .LBB0_110
; %bb.108:                              ;   in Loop: Header=BB0_95 Depth=3
	ds_bpermute_b32 v46, v49, v32
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_93
; %bb.109:                              ;   in Loop: Header=BB0_95 Depth=3
	s_lshl2_add_u32 s44, vcc_lo, vcc_hi
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
	s_branch .LBB0_93
.LBB0_110:                              ;   in Loop: Header=BB0_95 Depth=3
	s_mov_b32 s87, vcc_lo
	s_branch .LBB0_94
.LBB0_111:                              ;   in Loop: Header=BB0_87 Depth=2
                                        ; implicit-def: $vgpr18_vgpr19_vgpr20_vgpr21_vgpr22_vgpr23_vgpr24_vgpr25
	s_cbranch_execnz .LBB0_157
	s_branch .LBB0_86
.LBB0_112:                              ;   in Loop: Header=BB0_87 Depth=2
	s_mov_b32 s76, s78
	v_mov_b64_e32 v[18:19], v[90:91]
	v_mov_b64_e32 v[20:21], v[92:93]
	v_mov_b64_e32 v[22:23], v[94:95]
	v_mov_b64_e32 v[24:25], v[96:97]
	s_mov_b32 s87, vcc_lo
.LBB0_113:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_ge_i32 s76, s79
	s_cbranch_scc1 .LBB0_142
; %bb.114:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshlrev_b32_e32 v32, 3, v36
	s_ashr_i32 s77, s76, 31
	v_lshl_add_u64 v[46:47], s[26:27], 0, v[32:33]
	s_lshl_b64 s[26:27], s[76:77], 9
	v_lshl_add_u64 v[18:19], v[46:47], 0, s[26:27]
	global_load_dwordx2 v[18:19], v[18:19], off nt
	s_add_i32 s26, s76, 1
	s_cmp_lt_i32 s26, s79
	s_cselect_b64 s[42:43], -1, 0
	s_cmp_ge_i32 s26, s79
	s_cbranch_scc1 .LBB0_116
; %bb.115:                              ;   in Loop: Header=BB0_87 Depth=2
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[20:21], v[46:47], 0, s[26:27]
	global_load_dwordx2 v[20:21], v[20:21], off nt
.LBB0_116:                              ;   in Loop: Header=BB0_87 Depth=2
	s_add_i32 s26, s76, 2
	s_cmp_lt_i32 s26, s79
	s_cselect_b64 s[40:41], -1, 0
	s_cmp_ge_i32 s26, s79
	s_cbranch_scc1 .LBB0_118
; %bb.117:                              ;   in Loop: Header=BB0_87 Depth=2
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[22:23], v[46:47], 0, s[26:27]
	global_load_dwordx2 v[22:23], v[22:23], off nt
.LBB0_118:                              ;   in Loop: Header=BB0_87 Depth=2
	s_add_i32 s76, s76, 3
	s_cmp_lt_i32 s76, s79
	s_cselect_b64 s[26:27], -1, 0
	s_cmp_ge_i32 s76, s79
	s_cbranch_scc1 .LBB0_120
; %bb.119:                              ;   in Loop: Header=BB0_87 Depth=2
	s_ashr_i32 s77, s76, 31
	s_lshl_b64 s[44:45], s[76:77], 9
	v_lshl_add_u64 v[24:25], v[46:47], 0, s[44:45]
	global_load_dwordx2 v[24:25], v[24:25], off nt
.LBB0_120:                              ;   in Loop: Header=BB0_87 Depth=2
	s_mul_i32 s44, s63, s85
	s_lshl2_add_u32 s71, s44, s66
	s_cmp_eq_u32 vcc_lo, s87
	s_cbranch_scc1 .LBB0_124
; %bb.121:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v32, v49, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v73, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_123
; %bb.122:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl2_add_u32 s44, s87, s71
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_123:                              ; %Flow409
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v73, 0
	s_mov_b32 s87, vcc_lo
.LBB0_124:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshl_or_b32 v32, s70, 10, v37
	ds_read_b128 v[112:115], v32
	s_add_i32 s70, s70, 1
	s_cmp_eq_u32 s70, s86
	s_cselect_b64 s[44:45], -1, 0
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v117, 0xffff0000, v18
	v_lshlrev_b32_e32 v116, 16, v18
	s_and_b64 s[76:77], s[44:45], exec
	v_and_b32_e32 v47, 0xffff0000, v19
	v_lshlrev_b32_e32 v46, 16, v19
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	s_cselect_b32 s70, 0, s70
	s_cmp_lg_u64 s[44:45], 0
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v32, v112, v113
	s_addc_u32 s76, vcc_lo, 0
	v_add_f32_e32 v32, v32, v46
	s_and_b64 s[42:43], s[42:43], exec
	v_add_f32_e32 v32, v32, v47
	s_cselect_b32 s42, 1, 0
	s_cmp_lg_u32 s42, 1
	v_add_f32_e32 v73, v73, v32
	s_cbranch_scc1 .LBB0_136
; %bb.125:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_eq_u32 s76, s87
	s_cbranch_scc1 .LBB0_129
; %bb.126:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v32, v49, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v73, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[42:43], s[4:5]
	s_cbranch_execz .LBB0_128
; %bb.127:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl2_add_u32 s44, s87, s71
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_128:                              ; %Flow406
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[42:43]
	v_mov_b32_e32 v73, 0
	s_mov_b32 s87, s76
.LBB0_129:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshl_or_b32 v32, s70, 10, v37
	ds_read_b128 v[112:115], v32
	v_and_b32_e32 v117, 0xffff0000, v20
	v_lshlrev_b32_e32 v116, 16, v20
	s_add_i32 s70, s70, 1
	v_and_b32_e32 v47, 0xffff0000, v21
	v_lshlrev_b32_e32 v46, 16, v21
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	s_cmp_eq_u32 s70, s86
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v32, v112, v113
	s_cselect_b64 s[42:43], -1, 0
	v_add_f32_e32 v32, v32, v46
	s_and_b64 s[44:45], s[42:43], exec
	v_add_f32_e32 v32, v32, v47
	s_cselect_b32 s70, 0, s70
	s_cmp_lg_u64 s[42:43], 0
	v_add_f32_e32 v73, v73, v32
	s_addc_u32 s76, s76, 0
	s_and_b64 s[40:41], s[40:41], exec
	s_cselect_b32 s40, 1, 0
	s_cmp_lg_u32 s40, 1
	s_cbranch_scc0 .LBB0_137
.LBB0_130:                              ;   in Loop: Header=BB0_87 Depth=2
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	s_cbranch_scc1 .LBB0_142
.LBB0_131:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_eq_u32 s76, s87
	s_cbranch_scc1 .LBB0_135
; %bb.132:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v32, v49, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v73, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_134
; %bb.133:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl2_add_u32 s40, s87, s71
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s40
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_134:                              ; %Flow400
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v73, 0
	s_mov_b32 s87, s76
.LBB0_135:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshl_or_b32 v32, s70, 10, v37
	ds_read_b128 v[112:115], v32
	v_and_b32_e32 v117, 0xffff0000, v24
	v_lshlrev_b32_e32 v116, 16, v24
	v_and_b32_e32 v47, 0xffff0000, v25
	v_lshlrev_b32_e32 v46, 16, v25
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v32, v112, v113
	v_add_f32_e32 v32, v32, v46
	v_add_f32_e32 v32, v32, v47
	v_add_f32_e32 v73, v73, v32
	s_cmp_ge_i32 s78, s79
	s_cbranch_scc0 .LBB0_143
	s_branch .LBB0_146
.LBB0_136:                              ;   in Loop: Header=BB0_87 Depth=2
	s_and_b64 s[40:41], s[40:41], exec
	s_cselect_b32 s40, 1, 0
	s_cmp_lg_u32 s40, 1
	s_cbranch_scc1 .LBB0_130
.LBB0_137:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_eq_u32 s76, s87
	s_cbranch_scc1 .LBB0_141
; %bb.138:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v32, v49, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v73, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[40:41], s[4:5]
	s_cbranch_execz .LBB0_140
; %bb.139:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl2_add_u32 s42, s87, s71
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s42
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_140:                              ; %Flow403
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[40:41]
	v_mov_b32_e32 v73, 0
	s_mov_b32 s87, s76
.LBB0_141:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshl_or_b32 v32, s70, 10, v37
	ds_read_b128 v[112:115], v32
	v_and_b32_e32 v117, 0xffff0000, v22
	v_lshlrev_b32_e32 v116, 16, v22
	s_add_i32 s70, s70, 1
	v_and_b32_e32 v47, 0xffff0000, v23
	v_lshlrev_b32_e32 v46, 16, v23
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[112:113], v[112:113], v[116:117]
	s_cmp_eq_u32 s70, s86
	v_pk_mul_f32 v[46:47], v[114:115], v[46:47]
	v_add_f32_e32 v32, v112, v113
	s_cselect_b64 s[40:41], -1, 0
	v_add_f32_e32 v32, v32, v46
	s_and_b64 s[42:43], s[40:41], exec
	v_add_f32_e32 v32, v32, v47
	s_cselect_b32 s70, 0, s70
	s_cmp_lg_u64 s[40:41], 0
	v_add_f32_e32 v73, v73, v32
	s_addc_u32 s76, s76, 0
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	s_cbranch_scc0 .LBB0_131
.LBB0_142:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_ge_i32 s78, s79
	s_cbranch_scc1 .LBB0_146
.LBB0_143:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v32, v49, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v73, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_145
; %bb.144:                              ;   in Loop: Header=BB0_87 Depth=2
	s_mul_i32 s63, s63, s85
	s_lshl2_add_u32 s40, s63, s66
	s_lshl2_add_u32 s40, s87, s40
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s40
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_145:                              ; %Flow399
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
.LBB0_146:                              ;   in Loop: Header=BB0_87 Depth=2
	v_cmp_gt_i32_e32 vcc, s85, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execz .LBB0_156
; %bb.147:                              ;   in Loop: Header=BB0_87 Depth=2
	s_bfe_u32 s63, s84, 0x30006
	s_cmpk_gt_u32 s84, 0x1ff
	s_cselect_b64 s[40:41], -1, 0
	s_and_b32 s62, s62, 0x3f8
	s_cmp_lg_u32 s63, 0
	s_cselect_b64 s[42:43], -1, 0
	s_lshl_b32 s70, s85, 2
	s_lshl_b32 s71, s84, 2
	s_mov_b64 s[76:77], 0
	v_mov_b32_e32 v32, v72
	v_mov_b32_e32 v46, v0
	s_waitcnt vmcnt(0)
	s_branch .LBB0_149
.LBB0_148:                              ;   in Loop: Header=BB0_149 Depth=3
	v_mul_f32_e32 v47, v35, v47
	v_bfe_u32 v73, v47, 16, 1
	v_add_u32_e32 v112, s53, v46
	v_add3_u32 v73, v73, v47, s97
	v_or_b32_e32 v114, 0x400000, v47
	v_cmp_u_f32_e32 vcc, v47, v47
	v_add_u32_e32 v46, s84, v46
	v_ashrrev_i32_e32 v113, 31, v112
	v_cndmask_b32_e32 v47, v73, v114, vcc
	v_cmp_le_i32_e32 vcc, s85, v46
	v_lshl_add_u64 v[112:113], v[112:113], 1, s[6:7]
	v_lshrrev_b32_e32 v47, 16, v47
	s_or_b64 s[76:77], vcc, s[76:77]
	v_add_u32_e32 v32, s71, v32
	global_store_short v[112:113], v47, off sc0 sc1
	s_andn2_b64 exec, exec, s[76:77]
	s_cbranch_execz .LBB0_156
.LBB0_149:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_151 Depth 4
                                        ;         Child Loop BB0_155 Depth 4
	s_and_b64 s[44:45], s[40:41], exec
	s_cselect_b32 s44, 1, 0
	s_cmp_lg_u32 s44, 1
	s_cbranch_scc1 .LBB0_153
; %bb.150:                              ; %.preheader40
                                        ;   in Loop: Header=BB0_149 Depth=3
	v_lshl_add_u32 v73, v46, 2, s66
	s_mov_b32 s78, 0
	v_mov_b32_e32 v47, 0
.LBB0_151:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ;       Parent Loop BB0_149 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	s_mul_i32 s44, s78, s85
	v_lshl_add_u32 v112, s44, 2, v73
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	s_add_i32 s78, s78, 8
	s_cmp_lg_u32 s78, s62
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v113
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v113
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v113
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v113
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v113
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v113
	ds_read_b32 v113, v112
	v_add_u32_e32 v112, s70, v112
	ds_read_b32 v112, v112
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v47, v47, v113
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v112
	s_cbranch_scc1 .LBB0_151
; %bb.152:                              ;   in Loop: Header=BB0_149 Depth=3
	s_mov_b32 s86, s62
	s_mov_b64 s[78:79], s[42:43]
	s_and_b64 vcc, exec, s[78:79]
	s_cbranch_vccz .LBB0_148
	s_branch .LBB0_154
.LBB0_153:                              ;   in Loop: Header=BB0_149 Depth=3
	s_mov_b32 s86, 0
	v_mov_b32_e32 v47, 0
	s_cbranch_execz .LBB0_148
.LBB0_154:                              ;   in Loop: Header=BB0_149 Depth=3
	s_mul_i32 s44, s70, s86
	v_add_u32_e32 v73, s44, v32
	s_mov_b32 s78, s63
.LBB0_155:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ;       Parent Loop BB0_149 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ds_read_b32 v112, v73
	s_add_i32 s78, s78, -1
	v_add_u32_e32 v73, s70, v73
	s_cmp_lg_u32 s78, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v112
	s_cbranch_scc1 .LBB0_155
	s_branch .LBB0_148
.LBB0_156:                              ; %Flow398
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_barrier
	s_branch .LBB0_86
.LBB0_157:                              ;   in Loop: Header=BB0_87 Depth=2
	s_load_dword s26, s[56:57], 0xc
	s_sub_i32 s63, s83, s53
	v_readfirstlane_b32 s42, v0
	s_waitcnt lgkmcnt(0)
	s_bfe_u32 s76, s26, 0xa0006
	s_mul_i32 s43, s76, s63
	s_and_b32 s62, s26, 0xffff
	v_cmp_gt_i32_e32 vcc, s43, v0
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execz .LBB0_160
; %bb.158:                              ; %.preheader61
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_lshl_b32 s70, s62, 2
	s_mov_b64 s[40:41], 0
	v_mov_b32_e32 v18, v72
	v_mov_b32_e32 v19, v0
.LBB0_159:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	v_add_u32_e32 v19, s62, v19
	v_cmp_le_i32_e32 vcc, s43, v19
	ds_write_b32 v18, v33
	s_or_b64 s[40:41], vcc, s[40:41]
	v_add_u32_e32 v18, s70, v18
	s_andn2_b64 exec, exec, s[40:41]
	s_cbranch_execnz .LBB0_159
.LBB0_160:                              ; %Flow448
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_cvt_f32_u32_e32 v18, s76
	s_lshr_b32 s26, s67, 23
	s_add_i32 s26, s52, s26
	s_ashr_i32 s83, s26, 9
	v_rcp_f32_e32 v18, v18
	s_lshr_b32 s77, s42, 6
	s_mul_i32 s26, s63, s83
	s_sub_i32 s41, 0, s76
	v_mul_f32_e32 v18, 0x4f7ffffe, v18
	v_cvt_u32_f32_e32 v18, v18
	s_add_i32 s27, s26, s76
	s_add_i32 s27, s27, -1
	s_ashr_i32 s40, s27, 31
	v_readfirstlane_b32 s42, v18
	s_mul_i32 s41, s41, s42
	s_mul_hi_u32 s41, s42, s41
	s_abs_i32 s27, s27
	s_add_i32 s42, s42, s41
	s_mul_hi_u32 s41, s27, s42
	s_mul_i32 s42, s41, s76
	s_sub_i32 s27, s27, s42
	s_add_i32 s42, s41, 1
	s_sub_i32 s43, s27, s76
	s_cmp_ge_u32 s27, s76
	s_cselect_b32 s41, s42, s41
	s_cselect_b32 s27, s43, s27
	s_add_i32 s42, s41, 1
	s_cmp_ge_u32 s27, s76
	s_cselect_b32 s27, s42, s41
	s_xor_b32 s27, s27, s40
	s_sub_i32 s27, s27, s40
	s_mul_i32 s78, s27, s77
	s_add_i32 s27, s78, s27
	s_min_i32 s79, s26, s27
	s_lshl_b64 s[24:25], s[24:25], 1
	s_add_u32 s24, s80, s24
	s_addc_u32 s25, s81, s25
	s_abs_i32 s26, s83
	v_cvt_f32_u32_e32 v18, s26
	s_sub_i32 s41, 0, s26
	s_abs_i32 s40, s78
	s_xor_b32 s27, s78, s83
	v_rcp_f32_e32 v18, v18
	s_ashr_i32 s27, s27, 31
	v_mov_b32_e32 v20, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v18, 0x4f7ffffe, v18
	v_cvt_u32_f32_e32 v18, v18
	s_barrier
	v_readfirstlane_b32 s42, v18
	s_mul_i32 s41, s41, s42
	s_mul_hi_u32 s41, s42, s41
	s_add_i32 s42, s42, s41
	s_mul_hi_u32 s41, s40, s42
	s_mul_i32 s42, s41, s26
	s_sub_i32 s40, s40, s42
	s_add_i32 s42, s41, 1
	s_sub_i32 s43, s40, s26
	s_cmp_ge_u32 s40, s26
	s_cselect_b32 s41, s42, s41
	s_cselect_b32 s40, s43, s40
	s_add_i32 s42, s41, 1
	s_cmp_ge_u32 s40, s26
	s_cselect_b32 s26, s42, s41
	s_xor_b32 s26, s26, s27
	s_sub_i32 s84, s26, s27
	s_mul_i32 s26, s84, s83
	s_sub_i32 s43, s78, s26
	s_add_i32 s26, s78, 2
	s_cmp_le_i32 s26, s79
	s_cbranch_scc0 .LBB0_172
; %bb.161:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshlrev_b32_e32 v32, 4, v36
	s_mul_i32 s26, s77, s63
	v_lshl_add_u64 v[18:19], s[24:25], 0, v[32:33]
	s_lshl2_add_u32 s70, s26, s66
	v_mov_b32_e32 v20, 0
	s_mov_b32 s26, s78
	s_mov_b32 s42, s84
	s_branch .LBB0_164
.LBB0_162:                              ; %Flow440
                                        ;   in Loop: Header=BB0_164 Depth=3
	s_or_b64 exec, exec, s[42:43]
	v_mov_b32_e32 v10, 0
	s_mov_b32 s42, s27
.LBB0_163:                              ;   in Loop: Header=BB0_164 Depth=3
	s_and_b64 s[40:41], s[40:41], exec
	s_cselect_b32 s40, 0, s71
	v_lshl_or_b32 v11, s40, 11, v50
	ds_read_b128 v[20:23], v11
	ds_read_b128 v[112:115], v11 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v117, 0xffff0000, v14
	v_lshlrev_b32_e32 v116, 16, v14
	v_and_b32_e32 v47, 0xffff0000, v15
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[20:21], v[20:21], v[116:117]
	v_lshlrev_b32_e32 v46, 16, v15
	v_add_f32_e32 v11, 0, v20
	v_pk_mul_f32 v[22:23], v[22:23], v[46:47]
	v_add_f32_e32 v11, v11, v21
	v_and_b32_e32 v25, 0xffff0000, v16
	v_lshlrev_b32_e32 v24, 16, v16
	v_add_f32_e32 v11, v11, v22
	s_add_i32 s43, s40, 1
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[112:113], v[24:25]
	v_add_f32_e32 v11, v11, v23
	s_cmp_eq_u32 s43, s83
	v_and_b32_e32 v13, 0xffff0000, v17
	v_lshlrev_b32_e32 v12, 16, v17
	v_add_f32_e32 v11, v11, v24
	s_cselect_b64 s[40:41], -1, 0
	v_pk_mul_f32 v[12:13], v[114:115], v[12:13]
	v_add_f32_e32 v11, v11, v25
	s_and_b64 s[44:45], s[40:41], exec
	v_add_f32_e32 v11, v11, v12
	s_cselect_b32 s43, 0, s43
	s_cmp_lg_u64 s[40:41], 0
	v_add_f32_e32 v11, v11, v13
	s_addc_u32 s84, s27, 0
	s_add_i32 s40, s26, 2
	s_add_i32 s26, s26, 4
	v_add_f32_e32 v20, v10, v11
	s_cmp_le_i32 s26, s79
	s_mov_b32 s26, s40
	s_cbranch_scc0 .LBB0_173
.LBB0_164:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[40:41], s[26:27], 10
	v_lshl_add_u64 v[10:11], v[18:19], 0, s[40:41]
	s_add_i32 s40, s26, 1
	s_ashr_i32 s41, s40, 31
	s_lshl_b64 s[40:41], s[40:41], 10
	v_lshl_add_u64 v[14:15], v[18:19], 0, s[40:41]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_nop 0
	global_load_dwordx4 v[14:17], v[14:15], off nt
	s_cmp_eq_u32 s84, s42
	s_cbranch_scc1 .LBB0_168
; %bb.165:                              ;   in Loop: Header=BB0_164 Depth=3
	ds_bpermute_b32 v21, v49, v20
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v21
	ds_swizzle_b32 v21, v20 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v21
	v_mov_b32_e32 v21, 0
	s_nop 0
	v_add_f32_dpp v20, v20, v20 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v20, v20, v20 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v20, v20, v20 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v21, v20 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[40:41], s[4:5]
	s_cbranch_execz .LBB0_167
; %bb.166:                              ;   in Loop: Header=BB0_164 Depth=3
	s_lshl2_add_u32 s27, s42, s70
	v_add_f32_e32 v20, v20, v21
	v_mov_b32_e32 v21, s27
	ds_read_b32 v22, v21
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v22
	ds_write_b32 v21, v20
.LBB0_167:                              ; %Flow441
                                        ;   in Loop: Header=BB0_164 Depth=3
	s_or_b64 exec, exec, s[40:41]
	v_mov_b32_e32 v20, 0
.LBB0_168:                              ;   in Loop: Header=BB0_164 Depth=3
	v_lshl_or_b32 v21, s43, 11, v50
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v47, 0xffff0000, v13
	v_lshlrev_b32_e32 v46, 16, v13
	v_and_b32_e32 v113, 0xffff0000, v12
	v_lshlrev_b32_e32 v112, 16, v12
	v_and_b32_e32 v115, 0xffff0000, v11
	v_lshlrev_b32_e32 v114, 16, v11
	v_and_b32_e32 v117, 0xffff0000, v10
	v_lshlrev_b32_e32 v116, 16, v10
	ds_read_b128 v[10:13], v21
	ds_read_b128 v[22:25], v21 offset:16
	s_add_i32 s71, s43, 1
	s_cmp_eq_u32 s71, s83
	s_cselect_b64 s[40:41], -1, 0
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[116:117]
	v_pk_mul_f32 v[12:13], v[12:13], v[114:115]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[112:113]
	v_add_f32_e32 v10, v10, v13
	v_add_f32_e32 v10, v10, v22
	v_pk_mul_f32 v[24:25], v[24:25], v[46:47]
	v_add_f32_e32 v10, v10, v23
	v_add_f32_e32 v10, v10, v24
	v_add_f32_e32 v10, v10, v25
	s_addc_u32 s27, s84, 0
	v_add_f32_e32 v10, v20, v10
	s_cmp_lg_u32 s71, s83
	s_cbranch_scc1 .LBB0_171
; %bb.169:                              ;   in Loop: Header=BB0_164 Depth=3
	ds_bpermute_b32 v11, v49, v10
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[42:43], s[4:5]
	s_cbranch_execz .LBB0_162
; %bb.170:                              ;   in Loop: Header=BB0_164 Depth=3
	s_lshl2_add_u32 s44, s84, s70
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s44
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
	s_branch .LBB0_162
.LBB0_171:                              ;   in Loop: Header=BB0_164 Depth=3
	s_mov_b32 s42, s84
	s_branch .LBB0_163
.LBB0_172:                              ;   in Loop: Header=BB0_87 Depth=2
	s_mov_b32 s40, s78
	s_mov_b32 s42, s84
.LBB0_173:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_ge_i32 s40, s79
	s_cbranch_scc1 .LBB0_186
; %bb.174:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshlrev_b32_e32 v32, 4, v36
	s_ashr_i32 s41, s40, 31
	v_lshl_add_u64 v[18:19], s[24:25], 0, v[32:33]
	s_lshl_b64 s[24:25], s[40:41], 10
	v_lshl_add_u64 v[10:11], v[18:19], 0, s[24:25]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_add_i32 s26, s40, 1
	s_cmp_lt_i32 s26, s79
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_ge_i32 s26, s79
	s_cbranch_scc1 .LBB0_176
; %bb.175:                              ;   in Loop: Header=BB0_87 Depth=2
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 10
	v_lshl_add_u64 v[14:15], v[18:19], 0, s[26:27]
	global_load_dwordx4 v[14:17], v[14:15], off nt
.LBB0_176:                              ;   in Loop: Header=BB0_87 Depth=2
	s_mul_i32 s26, s77, s63
	s_lshl2_add_u32 s40, s26, s66
	s_cmp_eq_u32 s84, s42
	s_cbranch_scc1 .LBB0_180
; %bb.177:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v18, v49, v20
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v20, v18
	ds_swizzle_b32 v19, v18 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v19
	v_mov_b32_e32 v19, 0
	s_nop 0
	v_add_f32_dpp v18, v18, v18 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v18, v18, v18 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v18, v18, v18 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v19, v18 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_179
; %bb.178:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl2_add_u32 s41, s42, s40
	v_add_f32_e32 v18, v18, v19
	v_mov_b32_e32 v19, s41
	ds_read_b32 v20, v19
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v20
	ds_write_b32 v19, v18
.LBB0_179:                              ; %Flow437
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v20, 0
	s_mov_b32 s42, s84
.LBB0_180:                              ;   in Loop: Header=BB0_87 Depth=2
	v_lshl_or_b32 v21, s43, 11, v50
	ds_read_b128 v[22:25], v21
	ds_read_b128 v[112:115], v21 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v119, 0xffff0000, v10
	v_lshlrev_b32_e32 v118, 16, v10
	v_and_b32_e32 v117, 0xffff0000, v11
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[22:23], v[22:23], v[118:119]
	v_lshlrev_b32_e32 v116, 16, v11
	v_add_f32_e32 v21, 0, v22
	v_pk_mul_f32 v[24:25], v[24:25], v[116:117]
	v_add_f32_e32 v21, v21, v23
	v_and_b32_e32 v47, 0xffff0000, v12
	v_lshlrev_b32_e32 v46, 16, v12
	v_add_f32_e32 v21, v21, v24
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[112:113], v[46:47]
	v_add_f32_e32 v21, v21, v25
	v_and_b32_e32 v19, 0xffff0000, v13
	v_lshlrev_b32_e32 v18, 16, v13
	v_add_f32_e32 v21, v21, v46
	v_pk_mul_f32 v[18:19], v[114:115], v[18:19]
	v_add_f32_e32 v21, v21, v47
	v_add_f32_e32 v18, v21, v18
	s_and_b64 s[24:25], s[24:25], exec
	v_add_f32_e32 v18, v18, v19
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	v_add_f32_e32 v20, v20, v18
	s_cbranch_scc1 .LBB0_186
; %bb.181:                              ;   in Loop: Header=BB0_87 Depth=2
	s_add_i32 s43, s43, 1
	s_cmp_eq_u32 s43, s83
	s_cselect_b64 s[24:25], -1, 0
	s_addc_u32 s41, s84, 0
	s_cmp_eq_u32 s41, s42
	s_cbranch_scc1 .LBB0_185
; %bb.182:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v18, v49, v20
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v20, v18
	ds_swizzle_b32 v19, v18 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v19
	v_mov_b32_e32 v19, 0
	s_nop 0
	v_add_f32_dpp v18, v18, v18 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v18, v18, v18 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v18, v18, v18 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v19, v18 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_184
; %bb.183:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl2_add_u32 s40, s42, s40
	v_add_f32_e32 v18, v18, v19
	v_mov_b32_e32 v19, s40
	ds_read_b32 v20, v19
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v20
	ds_write_b32 v19, v18
.LBB0_184:                              ; %Flow434
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v20, 0
	s_mov_b32 s42, s41
.LBB0_185:                              ;   in Loop: Header=BB0_87 Depth=2
	s_lshl_b32 s26, s43, 11
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 0, s26
	v_or_b32_e32 v21, s24, v50
	ds_read_b128 v[22:25], v21
	ds_read_b128 v[112:115], v21 offset:16
	v_and_b32_e32 v119, 0xffff0000, v14
	v_lshlrev_b32_e32 v118, 16, v14
	v_and_b32_e32 v117, 0xffff0000, v15
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[22:23], v[22:23], v[118:119]
	v_lshlrev_b32_e32 v116, 16, v15
	v_add_f32_e32 v21, 0, v22
	v_pk_mul_f32 v[24:25], v[24:25], v[116:117]
	v_add_f32_e32 v21, v21, v23
	v_and_b32_e32 v47, 0xffff0000, v16
	v_lshlrev_b32_e32 v46, 16, v16
	v_add_f32_e32 v21, v21, v24
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[112:113], v[46:47]
	v_add_f32_e32 v21, v21, v25
	v_and_b32_e32 v19, 0xffff0000, v17
	v_lshlrev_b32_e32 v18, 16, v17
	v_add_f32_e32 v21, v21, v46
	v_pk_mul_f32 v[18:19], v[114:115], v[18:19]
	v_add_f32_e32 v21, v21, v47
	v_add_f32_e32 v18, v21, v18
	v_add_f32_e32 v18, v18, v19
	v_add_f32_e32 v20, v20, v18
.LBB0_186:                              ;   in Loop: Header=BB0_87 Depth=2
	s_cmp_ge_i32 s78, s79
	s_cbranch_scc1 .LBB0_190
; %bb.187:                              ;   in Loop: Header=BB0_87 Depth=2
	ds_bpermute_b32 v18, v49, v20
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v20, v18
	ds_swizzle_b32 v19, v18 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v19
	v_mov_b32_e32 v19, 0
	s_nop 0
	v_add_f32_dpp v18, v18, v18 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v18, v18, v18 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v18, v18, v18 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v19, v18 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_189
; %bb.188:                              ;   in Loop: Header=BB0_87 Depth=2
	s_mul_i32 s77, s77, s63
	s_lshl2_add_u32 s26, s77, s66
	s_lshl2_add_u32 s26, s42, s26
	v_mov_b32_e32 v20, s26
	ds_read_b32 v21, v20
	v_add_f32_e32 v18, v18, v19
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v21
	ds_write_b32 v20, v18
.LBB0_189:                              ; %Flow433
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[24:25]
.LBB0_190:                              ;   in Loop: Header=BB0_87 Depth=2
	v_cmp_gt_i32_e32 vcc, s63, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[24:25], vcc
	s_cbranch_execz .LBB0_200
; %bb.191:                              ;   in Loop: Header=BB0_87 Depth=2
	s_bfe_u32 s70, s62, 0x30006
	s_cmpk_gt_u32 s62, 0x1ff
	s_cselect_b64 s[26:27], -1, 0
	s_and_b32 s71, s76, 0x3f8
	s_cmp_lg_u32 s70, 0
	s_cselect_b64 s[40:41], -1, 0
	s_lshl_b32 s78, s63, 2
	s_lshl_b32 s79, s62, 2
	s_mov_b64 s[42:43], 0
	v_mov_b32_e32 v18, v72
	v_mov_b32_e32 v19, v0
	s_waitcnt vmcnt(0)
	s_branch .LBB0_193
.LBB0_192:                              ;   in Loop: Header=BB0_193 Depth=3
	v_mul_f32_e32 v20, v35, v20
	v_bfe_u32 v21, v20, 16, 1
	v_add_u32_e32 v22, s53, v19
	v_add3_u32 v21, v21, v20, s97
	v_or_b32_e32 v24, 0x400000, v20
	v_cmp_u_f32_e32 vcc, v20, v20
	v_add_u32_e32 v19, s62, v19
	v_ashrrev_i32_e32 v23, 31, v22
	v_cndmask_b32_e32 v20, v21, v24, vcc
	v_cmp_le_i32_e32 vcc, s63, v19
	v_lshl_add_u64 v[22:23], v[22:23], 1, s[6:7]
	v_lshrrev_b32_e32 v20, 16, v20
	s_or_b64 s[42:43], vcc, s[42:43]
	v_add_u32_e32 v18, s79, v18
	global_store_short v[22:23], v20, off sc0 sc1
	s_andn2_b64 exec, exec, s[42:43]
	s_cbranch_execz .LBB0_200
.LBB0_193:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_195 Depth 4
                                        ;         Child Loop BB0_199 Depth 4
	s_and_b64 s[44:45], s[26:27], exec
	s_cselect_b32 s44, 1, 0
	s_cmp_lg_u32 s44, 1
	s_cbranch_scc1 .LBB0_197
; %bb.194:                              ; %.preheader38
                                        ;   in Loop: Header=BB0_193 Depth=3
	v_lshl_add_u32 v21, v19, 2, s66
	s_mov_b32 s76, 0
	v_mov_b32_e32 v20, 0
.LBB0_195:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ;       Parent Loop BB0_193 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	s_mul_i32 s44, s76, s63
	v_lshl_add_u32 v22, s44, 2, v21
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	s_add_i32 s76, s76, 8
	s_cmp_lg_u32 s76, s71
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v23
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v23
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v23
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v23
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v23
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v23
	ds_read_b32 v23, v22
	v_add_u32_e32 v22, s78, v22
	ds_read_b32 v22, v22
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v20, v20, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v22
	s_cbranch_scc1 .LBB0_195
; %bb.196:                              ;   in Loop: Header=BB0_193 Depth=3
	s_mov_b32 s83, s71
	s_mov_b64 s[76:77], s[40:41]
	s_and_b64 vcc, exec, s[76:77]
	s_cbranch_vccz .LBB0_192
	s_branch .LBB0_198
.LBB0_197:                              ;   in Loop: Header=BB0_193 Depth=3
	s_mov_b32 s83, 0
	v_mov_b32_e32 v20, 0
	s_cbranch_execz .LBB0_192
.LBB0_198:                              ;   in Loop: Header=BB0_193 Depth=3
	s_mul_i32 s44, s78, s83
	v_add_u32_e32 v21, s44, v18
	s_mov_b32 s76, s70
.LBB0_199:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_87 Depth=2
                                        ;       Parent Loop BB0_193 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ds_read_b32 v22, v21
	s_add_i32 s76, s76, -1
	v_add_u32_e32 v21, s78, v21
	s_cmp_lg_u32 s76, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v20, v20, v22
	s_cbranch_scc1 .LBB0_199
	s_branch .LBB0_192
.LBB0_200:                              ; %Flow432
                                        ;   in Loop: Header=BB0_87 Depth=2
	s_or_b64 exec, exec, s[24:25]
	s_barrier
	s_cmp_lt_i32 s82, s3
	s_mov_b32 s53, s82
	s_cbranch_scc1 .LBB0_87
.LBB0_201:                              ; %Flow471
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[6:7], 0
.LBB0_202:                              ; %Flow643
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_and_b64 s[6:7], s[6:7], exec
	s_cselect_b32 s3, 1, 0
	s_cmp_lg_u32 s3, 1
	s_cbranch_scc1 .LBB0_228
; %bb.203:                              ; %LeafBlock378
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_cmp_lg_u32 s2, 0
	s_cbranch_scc1 .LBB0_229
; %bb.204:                              ;   in Loop: Header=BB0_9 Depth=1
	s_load_dwordx2 s[6:7], s[74:75], 0x0
	s_ashr_i32 s3, s96, 31
	s_waitcnt lgkmcnt(0)
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s3
	s_load_dword s2, s[8:9], 0x9c
	s_waitcnt lgkmcnt(0)
	s_cmp_ge_i32 s99, s2
	s_cbranch_scc1 .LBB0_229
; %bb.205:                              ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s3
	s_load_dwordx2 s[40:41], s[8:9], 0x38
	s_load_dword s84, s[8:9], 0x30
	s_abs_i32 s8, s99
	s_waitcnt lgkmcnt(0)
	s_abs_i32 s2, s41
	v_cvt_f32_u32_e32 v10, s2
	s_sub_i32 s24, 0, s2
	s_xor_b32 s9, s99, s41
	s_ashr_i32 s9, s9, 31
	v_rcp_f32_e32 v10, v10
	s_nop 0
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_nop 0
	v_readfirstlane_b32 s25, v10
	s_mul_i32 s24, s24, s25
	s_mul_hi_u32 s24, s25, s24
	s_add_i32 s25, s25, s24
	s_mul_hi_u32 s24, s8, s25
	s_mul_i32 s25, s24, s2
	s_sub_i32 s8, s8, s25
	s_add_i32 s26, s24, 1
	s_sub_i32 s25, s8, s2
	s_cmp_ge_u32 s8, s2
	s_cselect_b32 s24, s26, s24
	s_cselect_b32 s8, s25, s8
	s_add_i32 s25, s24, 1
	s_cmp_ge_u32 s8, s2
	s_cselect_b32 s2, s25, s24
	s_xor_b32 s2, s2, s9
	s_sub_i32 s42, s2, s9
	s_mul_i32 s2, s42, s41
	s_sub_i32 s86, s99, s2
	s_mul_i32 s86, s86, s40
	s_add_i32 s2, s86, s40
	s_min_i32 s41, s84, s2
	s_cmp_le_i32 s41, s86
	s_cbranch_scc1 .LBB0_229
; %bb.206:                              ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s3
	s_load_dwordx2 s[76:77], s[8:9], 0x28
	s_load_dword s85, s[8:9], 0x34
	s_load_dword s2, s[8:9], 0x68
	s_load_dwordx4 s[24:27], s[8:9], 0x0
	s_nop 0
	s_load_dwordx2 s[8:9], s[8:9], 0x10
                                        ; implicit-def: $sgpr52
	s_waitcnt lgkmcnt(0)
	s_cmp_lt_i32 s2, 2
	v_writelane_b32 v126, s8, 12
	s_nop 1
	v_writelane_b32 v126, s9, 13
	s_mov_b64 s[8:9], -1
	s_cbranch_scc0 .LBB0_208
; %bb.207:                              ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s8, s6, s96
	s_addc_u32 s9, s7, s3
	s_load_dwordx2 s[8:9], s[8:9], 0x18
	s_ashr_i32 s43, s42, 31
	s_lshl_b64 s[52:53], s[42:43], 2
	s_waitcnt lgkmcnt(0)
	s_add_u32 s8, s8, s52
	s_addc_u32 s9, s9, s53
	global_load_dword v10, v33, s[8:9] sc0 sc1
	s_mov_b64 s[8:9], 0
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s52, v10
.LBB0_208:                              ; %Flow638
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b32 s43, s85, 2
	s_lshl_b32 s44, s40, 3
	s_add_i32 s87, s43, s44
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	v_writelane_b32 v126, s44, 14
	s_cbranch_scc1 .LBB0_262
; %bb.209:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[78:79], exec
	v_readlane_b32 s8, v126, 4
	v_readlane_b32 s9, v126, 5
	s_and_b64 s[8:9], s[78:79], s[8:9]
	s_mov_b64 exec, s[8:9]
	s_cbranch_execz .LBB0_261
; %bb.210:                              ;   in Loop: Header=BB0_9 Depth=1
	s_add_u32 s6, s6, s96
	s_addc_u32 s7, s7, s3
	s_load_dword s52, s[6:7], 0x6c
	s_load_dword s3, s[6:7], 0x60
	s_load_dwordx2 s[80:81], s[6:7], 0x70
	v_mov_b32_e32 v10, 0xff800000
	v_mov_b32_e32 v12, v10
	s_waitcnt lgkmcnt(0)
	v_cmp_gt_i32_e64 s[6:7], s52, v0
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execz .LBB0_212
; %bb.211:                              ;   in Loop: Header=BB0_9 Depth=1
	global_load_ushort v11, v59, s[80:81] sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v12, 16, v11
.LBB0_212:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_cmp_gt_i32_e64 s[8:9], s52, v51
	s_and_saveexec_b64 s[82:83], s[8:9]
	s_cbranch_execz .LBB0_214
; %bb.213:                              ;   in Loop: Header=BB0_9 Depth=1
	global_load_ushort v10, v59, s[80:81] offset:128 sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v10, 16, v10
.LBB0_214:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[82:83]
	v_mov_b32_e32 v16, 0
	v_mov_b32_e32 v15, v16
	s_and_saveexec_b64 s[52:53], s[6:7]
	s_xor_b64 s[80:81], exec, s[52:53]
	s_cbranch_execz .LBB0_216
; %bb.215:                              ;   in Loop: Header=BB0_9 Depth=1
	v_bfe_u32 v11, v12, 16, 15
	s_mov_b32 s44, 0x8000
	v_sub_u32_e32 v11, 0x8000, v11
	v_or_b32_sdwa v13, v12, s44 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v12
	s_nop 1
	v_cndmask_b32_e32 v11, v13, v11, vcc
	v_lshl_or_b32 v11, v11, 7, v60
	v_cmp_o_f32_e32 vcc, v12, v12
	s_nop 1
	v_cndmask_b32_e32 v11, v60, v11, vcc
	v_or_b32_e32 v11, v11, v0
	v_xor_b32_e32 v15, 0x7f, v11
.LBB0_216:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[80:81]
	s_and_saveexec_b64 s[80:81], s[8:9]
	s_cbranch_execz .LBB0_218
; %bb.217:                              ;   in Loop: Header=BB0_9 Depth=1
	v_bfe_u32 v11, v10, 16, 15
	s_mov_b32 s44, 0x8000
	v_sub_u32_e32 v11, 0x8000, v11
	v_or_b32_sdwa v13, v10, s44 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v10
	s_nop 1
	v_cndmask_b32_e32 v11, v13, v11, vcc
	v_lshl_or_b32 v11, v11, 7, v60
	v_cmp_o_f32_e32 vcc, v10, v10
	s_nop 1
	v_cndmask_b32_e32 v11, v60, v11, vcc
	v_or_b32_e32 v11, v11, v51
	v_xor_b32_e32 v16, 0x7f, v11
.LBB0_218:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[80:81]
	v_max_u32_e32 v11, v15, v16
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v11, v11, v11 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s52, v11, 63
	s_lshr_b32 s44, s52, 7
	s_bfe_u32 s45, s52, 0x100007
	s_add_i32 s53, s44, 0xffff8000
	s_sub_i32 s44, 0x8000, s44
	s_bitset1_b32 s44, 15
	s_cmpk_gt_u32 s45, 0x7fff
	s_cselect_b32 s44, s53, s44
	s_lshl_b32 s44, s44, 16
	s_cmp_lg_u32 s45, 0
	v_mov_b32_e32 v11, s44
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v61, v11, vcc
	v_mov_b32_e32 v11, 0
	v_mov_b32_e32 v13, v11
	s_and_saveexec_b64 s[80:81], s[6:7]
	s_cbranch_execz .LBB0_220
; %bb.219:                              ;   in Loop: Header=BB0_9 Depth=1
	v_sub_f32_e32 v12, v12, v14
	v_mul_f32_e32 v13, 0x3fb8aa3b, v12
	s_mov_b32 s44, 0x3fb8aa3b
	v_fma_f32 v17, v12, s44, -v13
	v_rndne_f32_e32 v18, v13
	v_fmac_f32_e32 v17, 0x32a5705f, v12
	v_sub_f32_e32 v13, v13, v18
	v_add_f32_e32 v13, v13, v17
	v_cvt_i32_f32_e32 v17, v18
	v_exp_f32_e32 v13, v13
	s_mov_b32 s44, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s44, v12
	s_mov_b32 s44, 0x42b17218
	v_ldexp_f32 v13, v13, v17
	v_cndmask_b32_e32 v13, 0, v13, vcc
	v_cmp_nlt_f32_e32 vcc, s44, v12
	s_nop 1
	v_cndmask_b32_e32 v13, v62, v13, vcc
.LBB0_220:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[80:81]
	v_mov_b32_e32 v12, 0
	s_and_saveexec_b64 s[80:81], s[8:9]
	s_cbranch_execz .LBB0_222
; %bb.221:                              ;   in Loop: Header=BB0_9 Depth=1
	v_sub_f32_e32 v10, v10, v14
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10
	s_mov_b32 s44, 0x3fb8aa3b
	v_fma_f32 v14, v10, s44, -v11
	v_rndne_f32_e32 v17, v11
	v_fmac_f32_e32 v14, 0x32a5705f, v10
	v_sub_f32_e32 v11, v11, v17
	v_add_f32_e32 v11, v11, v14
	v_cvt_i32_f32_e32 v14, v17
	v_exp_f32_e32 v11, v11
	s_mov_b32 s44, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s44, v10
	s_mov_b32 s44, 0x42b17218
	v_ldexp_f32 v11, v11, v14
	v_cndmask_b32_e32 v11, 0, v11, vcc
	v_cmp_nlt_f32_e32 vcc, s44, v10
	s_nop 1
	v_cndmask_b32_e32 v11, v62, v11, vcc
.LBB0_222:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[80:81]
	v_cmp_lt_u32_e32 vcc, v65, v64
	v_add_f32_e32 v10, v13, v11
	s_cmp_lt_i32 s3, 1
	v_cndmask_b32_e32 v14, v63, v65, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v66, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v66, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v67, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v67, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v68, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v68, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v69, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v69, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	v_cmp_lt_u32_e32 vcc, v70, v64
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_cndmask_b32_e32 v14, v63, v70, vcc
	v_lshlrev_b32_e32 v14, 2, v14
	ds_bpermute_b32 v14, v14, v10
	s_cbranch_scc1 .LBB0_254
; %bb.223:                              ;   in Loop: Header=BB0_9 Depth=1
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v14
	v_div_scale_f32 v12, s[62:63], v10, v10, 1.0
	v_rcp_f32_e32 v14, v12
	v_div_scale_f32 v17, vcc, 1.0, v10, 1.0
	v_fma_f32 v18, -v12, v14, 1.0
	v_fmac_f32_e32 v14, v18, v14
	v_mul_f32_e32 v18, v17, v14
	v_fma_f32 v19, -v12, v18, v17
	v_fmac_f32_e32 v18, v19, v14
	v_fma_f32 v12, -v12, v18, v17
	v_div_fmas_f32 v12, v12, v14, v18
	v_div_fixup_f32 v10, v12, v10, 1.0
	v_mul_f32_e32 v12, v10, v13
	v_mul_f32_e32 v11, v10, v11
	v_cndmask_b32_e64 v10, 0, v12, s[6:7]
	s_andn2_b32 s6, 0x7f, s52
	s_cmp_lg_u32 s52, 0
	s_cselect_b32 s6, s6, 0
	s_cmp_gt_u32 s6, 63
	v_cndmask_b32_e64 v11, 0, v11, s[8:9]
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v12, v10, v11, vcc
	s_cmp_eq_u32 s3, 1
	v_readlane_b32 s7, v12, s6
	s_nop 1
	v_mov_b32_e32 v12, s7
	v_cndmask_b32_e64 v13, 0, v12, s[10:11]
	v_mov_b32_e32 v12, s6
	v_cndmask_b32_e64 v14, 0, v12, s[10:11]
	v_add_f32_e64 v12, s7, 0
	s_cbranch_scc1 .LBB0_259
; %bb.224:                              ;   in Loop: Header=BB0_9 Depth=1
	v_cmp_ne_u32_e32 vcc, s52, v15
	s_add_i32 s6, s3, -1
	s_add_i32 s7, s3, -2
	v_cndmask_b32_e32 v15, 0, v15, vcc
	s_and_b32 s8, s6, 3
	v_cmp_ne_u32_e32 vcc, s52, v16
	s_cmp_lt_u32 s7, 3
	s_nop 0
	v_cndmask_b32_e32 v16, 0, v16, vcc
	s_cbranch_scc1 .LBB0_255
; %bb.225:                              ;   in Loop: Header=BB0_9 Depth=1
	s_and_b32 s7, s6, -4
	s_mov_b32 s6, 0
.LBB0_226:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_max_u32_e32 v17, v15, v16
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	v_max_u32_e32 v17, v15, v16
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v18, s9
	v_readlane_b32 s9, v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s6, v55
	v_mov_b32_e32 v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_nop 0
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	v_max_u32_e32 v17, v15, v16
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v18, s9
	v_readlane_b32 s9, v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s6, v54
	v_mov_b32_e32 v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_nop 0
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	v_max_u32_e32 v17, v15, v16
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v18, s9
	v_readlane_b32 s9, v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s6, v53
	v_mov_b32_e32 v19, s9
	v_max_u32_dpp v17, v17, v17 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_max_u32_dpp v17, v17, v17 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_nop 0
	v_max_u32_dpp v17, v17, v17 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v17, v17, v17 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s9, v17, 63
	s_andn2_b32 s44, 0x7f, s9
	s_cmp_lg_u32 s9, 0
	v_cmp_ne_u32_e32 vcc, s9, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s9, v16
	s_cselect_b32 s9, s44, 0
	s_cmp_gt_u32 s9, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v18, v10, v11, vcc
	v_mov_b32_e32 v17, s9
	v_readlane_b32 s9, v18, s9
	v_cmp_eq_u32_e32 vcc, s6, v52
	s_add_i32 s6, s6, 4
	v_mov_b32_e32 v18, s9
	v_add_f32_e32 v12, s9, v12
	v_cndmask_b32_e32 v13, v13, v18, vcc
	s_cmp_eq_u32 s7, s6
	v_cndmask_b32_e32 v14, v14, v17, vcc
	s_cbranch_scc0 .LBB0_226
; %bb.227:                              ;   in Loop: Header=BB0_9 Depth=1
	s_add_i32 s9, s6, 1
	s_cmp_lg_u32 s8, 0
	s_cselect_b64 s[6:7], -1, 0
	s_branch .LBB0_256
.LBB0_228:                              ;   in Loop: Header=BB0_9 Depth=1
	v_mov_b64_e32 v[80:81], v[16:17]
	v_mov_b64_e32 v[78:79], v[14:15]
	v_mov_b64_e32 v[76:77], v[12:13]
	v_mov_b64_e32 v[74:75], v[10:11]
	v_mov_b64_e32 v[82:83], v[90:91]
	v_mov_b64_e32 v[84:85], v[92:93]
	v_mov_b64_e32 v[86:87], v[94:95]
	v_mov_b64_e32 v[88:89], v[96:97]
.LBB0_229:                              ;   in Loop: Header=BB0_9 Depth=1
	s_and_saveexec_b64 s[6:7], s[60:61]
	s_cbranch_execz .LBB0_231
.LBB0_230:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[2:3], s[58:59], 8
	v_lshl_add_u64 v[10:11], v[38:39], 0, s[2:3]
	;;#ASMSTART
	s_memrealtime s[2:3]
	;;#ASMEND
	s_nop 0
	v_mov_b64_e32 v[12:13], s[2:3]
	global_store_dwordx2 v[10:11], v[12:13], off
.LBB0_231:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	;;#ASMSTART
	s_waitcnt vmcnt(0)
	;;#ASMEND
	s_and_saveexec_b64 s[6:7], s[60:61]
	s_cbranch_execz .LBB0_233
; %bb.232:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[8:9], s[58:59], 8
	;;#ASMSTART
	s_memrealtime s[2:3]
	;;#ASMEND
	v_lshl_add_u64 v[10:11], v[40:41], 0, s[8:9]
	v_mov_b64_e32 v[12:13], s[2:3]
	global_store_dwordx2 v[10:11], v[12:13], off offset:8
.LBB0_233:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_barrier
	s_and_saveexec_b64 s[6:7], s[50:51]
	s_cbranch_execz .LBB0_235
; %bb.234:                              ;   in Loop: Header=BB0_9 Depth=1
	s_memrealtime s[2:3]
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v24, s2
	v_mov_b32_e32 v25, s3
	global_store_dwordx4 v33, v[24:27], s[72:73] offset:16
.LBB0_235:                              ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_cmp_eq_u32 s98, 0
	s_cselect_b64 s[2:3], -1, 0
	s_and_b64 s[2:3], s[10:11], s[2:3]
	s_and_saveexec_b64 s[6:7], s[2:3]
	s_cbranch_execz .LBB0_8
; %bb.236:                              ;   in Loop: Header=BB0_9 Depth=1
	;;#ASMSTART
	s_waitcnt vmcnt(0)
	;;#ASMEND
	s_and_b64 s[2:3], s[0:1], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_mov_b64 s[8:9], 0
	s_cbranch_scc1 .LBB0_238
; %bb.237:                              ;   in Loop: Header=BB0_9 Depth=1
	;;#ASMSTART
	s_memrealtime s[8:9]
	;;#ASMEND
.LBB0_238:                              ;   in Loop: Header=BB0_9 Depth=1
	v_readlane_b32 s2, v126, 6
	v_readlane_b32 s3, v126, 7
	s_and_b64 s[2:3], s[2:3], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_cbranch_scc1 .LBB0_253
; %bb.239:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b64 s[2:3], s[58:59], 2
	s_add_u32 s2, s18, s2
	s_addc_u32 s3, s19, s3
	global_load_dwordx2 v[10:11], v33, s[2:3]
	s_mov_b32 s2, -1
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s24, v10
	v_readfirstlane_b32 s3, v11
	s_cmp_ge_i32 s24, s3
	s_cbranch_scc0 .LBB0_241
	s_branch .LBB0_245
.LBB0_240:                              ;   in Loop: Header=BB0_241 Depth=2
	s_add_i32 s24, s24, 1
	s_cmp_eq_u32 s3, s24
	s_mov_b32 s2, -1
	s_cselect_b64 s[26:27], -1, 0
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s25, 1, 0
	s_cmp_lg_u32 s25, 1
	s_cbranch_scc0 .LBB0_245
.LBB0_241:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[26:27], s[24:25], 2
	s_add_u32 s26, s36, s26
	s_addc_u32 s27, s37, s27
	global_load_dword v10, v33, s[26:27]
	s_waitcnt vmcnt(0)
	v_cmp_ne_u32_e64 s[26:27], 0, v10
	s_and_b64 vcc, exec, s[26:27]
	s_cbranch_vccnz .LBB0_243
; %bb.242:                              ;   in Loop: Header=BB0_241 Depth=2
	s_lshl_b64 s[26:27], s[24:25], 4
	s_add_u32 s26, s38, s26
	s_addc_u32 s27, s39, s27
	global_load_dwordx2 v[10:11], v33, s[26:27]
	s_waitcnt vmcnt(0)
	v_cmp_ne_u64_e64 s[26:27], 0, v[10:11]
.LBB0_243:                              ; %Flow385
                                        ;   in Loop: Header=BB0_241 Depth=2
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_mov_b64 s[26:27], -1
	s_cbranch_scc0 .LBB0_240
; %bb.244:                              ;   in Loop: Header=BB0_241 Depth=2
	s_mov_b32 s2, s24
                                        ; implicit-def: $sgpr24
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s25, 1, 0
	s_cmp_lg_u32 s25, 1
	s_cbranch_scc1 .LBB0_241
.LBB0_245:                              ;   in Loop: Header=BB0_9 Depth=1
	s_cmp_gt_i32 s2, -1
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_lt_i32 s2, 0
	s_cbranch_scc1 .LBB0_247
.LBB0_246:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b32 s26, s2, 1
	s_mov_b32 s27, s59
	s_lshl_b64 s[26:27], s[26:27], 3
	s_add_u32 s26, s38, s26
	s_addc_u32 s27, s39, s27
	;;#ASMSTART
	s_memrealtime s[40:41]
	;;#ASMEND
	s_nop 0
	v_mov_b64_e32 v[10:11], s[40:41]
	global_store_dwordx2 v33, v[10:11], s[26:27]
.LBB0_247:                              ;   in Loop: Header=BB0_9 Depth=1
	v_mov_b32_e32 v10, v33
	;;#ASMSTART
	;;#ASMEND
	v_readlane_b32 s26, v126, 0
	v_lshlrev_b32_e32 v10, 5, v10
	v_ashrrev_i32_e32 v11, 31, v10
	v_readlane_b32 s27, v126, 1
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s3, 1, 0
	v_lshl_add_u64 v[10:11], v[10:11], 2, s[26:27]
	global_atomic_sub v10, v[10:11], v71, off sc0
	s_cmp_lg_u32 s3, 1
	s_cbranch_scc1 .LBB0_249
; %bb.248:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b32 s2, s2, 1
	s_mov_b32 s3, s59
	s_lshl_b64 s[2:3], s[2:3], 3
	s_add_u32 s2, s38, s2
	s_addc_u32 s3, s39, s3
	;;#ASMSTART
	s_memrealtime s[24:25]
	;;#ASMEND
	s_nop 0
	v_mov_b64_e32 v[12:13], s[24:25]
	global_store_dwordx2 v33, v[12:13], s[2:3] offset:8
.LBB0_249:                              ;   in Loop: Header=BB0_9 Depth=1
	s_and_b64 s[2:3], s[0:1], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_mov_b64 s[24:25], 0
	s_cbranch_scc1 .LBB0_251
; %bb.250:                              ;   in Loop: Header=BB0_9 Depth=1
	;;#ASMSTART
	s_memrealtime s[24:25]
	;;#ASMEND
.LBB0_251:                              ;   in Loop: Header=BB0_9 Depth=1
	v_readlane_b32 s2, v126, 10
	s_waitcnt vmcnt(0)
	v_cmp_eq_u32_e32 vcc, 1, v10
	v_readlane_b32 s3, v126, 11
	s_and_b64 s[2:3], s[2:3], vcc
	s_and_b64 exec, exec, s[2:3]
	s_cbranch_execz .LBB0_8
; %bb.252:                              ;   in Loop: Header=BB0_9 Depth=1
	v_mov_b32_e32 v10, s8
	v_mov_b32_e32 v11, s9
	v_mov_b32_e32 v12, s24
	v_mov_b32_e32 v13, s25
	global_store_dwordx4 v33, v[10:13], s[14:15]
	s_nop 1
	v_mov_b64_e32 v[10:11], s[58:59]
	global_store_dwordx2 v33, v[10:11], s[14:15] offset:16
	s_branch .LBB0_8
.LBB0_253:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s2, -1
	s_cmp_gt_i32 s2, -1
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_lt_i32 s2, 0
	s_cbranch_scc0 .LBB0_246
	s_branch .LBB0_247
.LBB0_254:                              ;   in Loop: Header=BB0_9 Depth=1
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v14, 0
	v_mov_b32_e32 v13, 0
	s_branch .LBB0_259
.LBB0_255:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[6:7], -1
	s_mov_b32 s9, 1
.LBB0_256:                              ; %Flow632
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_and_b64 vcc, exec, s[6:7]
	s_cbranch_vccz .LBB0_259
; %bb.257:                              ;   in Loop: Header=BB0_9 Depth=1
	v_subrev_u32_e32 v17, s9, v0
.LBB0_258:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_max_u32_e32 v18, v15, v16
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v18, v18, v18 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s6, v18, 63
	s_andn2_b32 s7, 0x7f, s6
	s_cmp_lg_u32 s6, 0
	v_cmp_ne_u32_e32 vcc, s6, v15
	s_nop 1
	v_cndmask_b32_e32 v15, 0, v15, vcc
	v_cmp_ne_u32_e32 vcc, s6, v16
	s_cselect_b32 s6, s7, 0
	s_cmp_gt_u32 s6, 63
	v_cndmask_b32_e32 v16, 0, v16, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v19, v10, v11, vcc
	v_mov_b32_e32 v18, s6
	v_readlane_b32 s6, v19, s6
	s_add_i32 s8, s8, -1
	v_subrev_co_u32_e32 v17, vcc, 1, v17
	v_mov_b32_e32 v19, s6
	s_cmp_lg_u32 s8, 0
	v_add_f32_e32 v12, s6, v12
	v_cndmask_b32_e32 v13, v13, v19, vcc
	v_cndmask_b32_e32 v14, v14, v18, vcc
	s_cbranch_scc1 .LBB0_258
.LBB0_259:                              ;   in Loop: Header=BB0_9 Depth=1
	v_cmp_gt_i32_e32 vcc, s3, v0
	s_and_b64 exec, exec, vcc
	s_cbranch_execz .LBB0_261
; %bb.260:                              ;   in Loop: Header=BB0_9 Depth=1
	v_div_scale_f32 v10, s[6:7], v12, v12, v13
	v_rcp_f32_e32 v11, v10
	v_div_scale_f32 v15, vcc, v13, v12, v13
	s_cmp_eq_u32 s2, 3
	v_fma_f32 v16, -v10, v11, 1.0
	v_fmac_f32_e32 v11, v16, v11
	v_mul_f32_e32 v16, v15, v11
	v_fma_f32 v17, -v10, v16, v15
	v_fmac_f32_e32 v16, v17, v11
	v_fma_f32 v10, -v10, v16, v15
	v_div_fmas_f32 v10, v10, v11, v16
	v_div_fixup_f32 v10, v10, v12, v13
	s_cselect_b64 vcc, -1, 0
	v_lshl_add_u32 v11, v0, 2, s87
	v_cndmask_b32_e32 v10, v13, v10, vcc
	v_add_u32_e32 v11, 0x1000, v11
	ds_write2_b32 v11, v14, v10 offset1:16
.LBB0_261:                              ; %Flow636
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[78:79]
	s_lshl2_add_u32 s2, s42, s87
	v_mov_b32_e32 v10, s2
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b32 v10, v10 offset:4096
	s_waitcnt lgkmcnt(0)
	v_readfirstlane_b32 s52, v10
.LBB0_262:                              ;   in Loop: Header=BB0_9 Depth=1
	s_ashr_i32 s79, s85, 31
	s_lshr_b32 s2, s79, 29
	s_add_i32 s2, s85, s2
	s_ashr_i32 s2, s2, 3
	v_cmp_gt_i32_e32 vcc, s2, v0
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_265
; %bb.263:                              ; %.preheader75
                                        ;   in Loop: Header=BB0_9 Depth=1
	v_lshl_add_u64 v[10:11], s[26:27], 0, v[42:43]
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v12, v56
	v_mov_b32_e32 v13, v0
.LBB0_264:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	global_load_dwordx2 v[18:19], v[10:11], off offset:-8 sc0 sc1
	global_load_dwordx2 v[22:23], v[10:11], off sc0 sc1
	v_add_u32_e32 v13, s88, v13
	v_cmp_le_i32_e32 vcc, s2, v13
	v_lshl_add_u64 v[10:11], v[10:11], 0, s[68:69]
	s_or_b64 s[8:9], vcc, s[8:9]
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v15, 0xffff0000, v18
	v_lshlrev_b32_e32 v14, 16, v18
	v_and_b32_e32 v17, 0xffff0000, v19
	v_lshlrev_b32_e32 v16, 16, v19
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v19, 0xffff0000, v22
	v_lshlrev_b32_e32 v18, 16, v22
	v_and_b32_e32 v21, 0xffff0000, v23
	v_lshlrev_b32_e32 v20, 16, v23
	ds_write_b128 v12, v[14:17]
	ds_write_b128 v12, v[18:21] offset:16
	v_add_u32_e32 v12, s94, v12
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB0_264
.LBB0_265:                              ; %Flow627
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_ashr_i32 s2, s52, 31
	s_mul_hi_u32 s3, s76, s52
	s_mul_i32 s2, s76, s2
	s_add_i32 s2, s3, s2
	s_mul_i32 s3, s77, s52
	s_add_i32 s3, s2, s3
	s_mul_i32 s2, s76, s52
	s_lshl_b64 s[2:3], s[2:3], 1
	s_add_u32 s80, s24, s2
	s_addc_u32 s81, s25, s3
	s_sub_i32 s78, s41, s86
	s_and_b32 s2, s85, 0x1ff
	s_cselect_b64 s[6:7], -1, 0
	s_cmp_gt_i32 s78, 32
	s_cselect_b64 s[2:3], -1, 0
	s_or_b64 s[24:25], s[6:7], s[2:3]
	s_mov_b64 s[8:9], 0
	s_and_b64 vcc, exec, s[24:25]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cbranch_vccnz .LBB0_269
; %bb.266:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshr_b32 s2, s79, 23
	s_add_i32 s2, s85, s2
	s_ashr_i32 s8, s2, 9
	s_mul_i32 s2, s78, s8
	s_add_i32 s3, s90, s2
	s_ashr_i32 s9, s3, 31
	s_abs_i32 s3, s3
	s_mul_hi_u32 s24, s3, s91
	s_mul_i32 s25, s24, s89
	s_sub_i32 s3, s3, s25
	s_add_i32 s25, s24, 1
	s_sub_i32 s26, s3, s89
	s_cmp_ge_u32 s3, s89
	s_cselect_b32 s24, s25, s24
	s_cselect_b32 s3, s26, s3
	s_add_i32 s25, s24, 1
	s_cmp_ge_u32 s3, s89
	s_cselect_b32 s24, s25, s24
	s_abs_i32 s3, s8
	v_cvt_f32_u32_e32 v10, s3
	s_xor_b32 s24, s24, s9
	s_sub_i32 s9, s24, s9
	s_sub_i32 s25, 0, s3
	v_rcp_f32_e32 v10, v10
	s_ashr_i32 s24, s9, 31
	s_abs_i32 s26, s9
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_nop 0
	v_readfirstlane_b32 s9, v10
	s_mul_i32 s25, s25, s9
	s_mul_hi_u32 s25, s9, s25
	s_add_i32 s9, s9, s25
	s_mul_hi_u32 s25, s26, s9
	s_mul_i32 s25, s25, s3
	s_sub_i32 s25, s26, s25
	s_sub_i32 s26, s25, s3
	s_cmp_ge_u32 s25, s3
	s_cselect_b32 s25, s26, s25
	s_sub_i32 s26, s25, s3
	s_cmp_ge_u32 s25, s3
	s_cselect_b32 s25, s26, s25
	s_xor_b32 s25, s25, s24
	s_sub_i32 s26, s25, s24
	s_cmp_lg_u32 s26, 0
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_eq_u32 s26, 0
	s_cbranch_scc0 .LBB0_268
; %bb.267:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b32 s44, s78, 1
	s_mul_i32 s8, s44, s8
	s_add_i32 s8, s90, s8
	s_ashr_i32 s24, s8, 31
	s_abs_i32 s8, s8
	s_mul_hi_u32 s25, s8, s91
	s_mul_i32 s26, s25, s89
	s_sub_i32 s8, s8, s26
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s8, s89
	s_cmp_ge_u32 s8, s89
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s8, s27, s8
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s8, s89
	s_cselect_b32 s8, s26, s25
	s_xor_b32 s8, s8, s24
	s_sub_i32 s8, s8, s24
	s_ashr_i32 s24, s8, 31
	s_abs_i32 s8, s8
	s_mul_hi_u32 s9, s8, s9
	s_mul_i32 s9, s9, s3
	s_sub_i32 s9, s8, s9
	s_sub_i32 s25, s9, s3
	s_cmp_ge_u32 s9, s3
	s_cselect_b32 s9, s25, s9
	s_sub_i32 s25, s9, s3
	s_cmp_ge_u32 s9, s3
	s_cselect_b32 s3, s25, s9
	s_xor_b32 s3, s3, s24
	s_sub_i32 s3, s3, s24
	s_cmp_lg_u32 s3, 0
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_eq_u32 s3, 0
	v_writelane_b32 v126, s44, 15
	s_cbranch_scc1 .LBB0_504
.LBB0_268:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b64 s[8:9], 0
.LBB0_269:                              ; %Flow620
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_and_b64 vcc, exec, s[24:25]
                                        ; implicit-def: $vgpr90_vgpr91_vgpr92_vgpr93_vgpr94_vgpr95_vgpr96_vgpr97
                                        ; implicit-def: $vgpr22_vgpr23_vgpr24_vgpr25
                                        ; implicit-def: $vgpr116_vgpr117
                                        ; implicit-def: $vgpr114_vgpr115
                                        ; implicit-def: $vgpr112_vgpr113
                                        ; implicit-def: $vgpr18_vgpr19_vgpr20_vgpr21
                                        ; implicit-def: $sgpr2
	s_cbranch_vccz .LBB0_505
.LBB0_270:                              ;   in Loop: Header=BB0_9 Depth=1
	v_readlane_b32 s2, v126, 14
	s_lshl2_add_u32 s2, s85, s2
	v_mov_b64_e32 v[18:19], v[102:103]
	s_waitcnt vmcnt(0)
	v_add_u32_e32 v35, s2, v48
	v_mov_b64_e32 v[20:21], v[104:105]
	v_mov_b64_e32 v[112:113], v[110:111]
	v_mov_b64_e32 v[114:115], v[108:109]
	v_mov_b64_e32 v[116:117], v[106:107]
	s_mov_b32 s3, s86
	s_branch .LBB0_272
.LBB0_271:                              ;   in Loop: Header=BB0_272 Depth=2
	v_mov_b64_e32 v[116:117], v[10:11]
	v_mov_b64_e32 v[114:115], v[12:13]
	v_mov_b64_e32 v[112:113], v[14:15]
	s_cmp_lt_i32 s2, s41
	s_mov_b32 s3, s2
	s_cbranch_scc0 .LBB0_386
.LBB0_272:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_275 Depth 3
                                        ;       Child Loop BB0_280 Depth 3
                                        ;       Child Loop BB0_333 Depth 3
                                        ;         Child Loop BB0_335 Depth 4
                                        ;         Child Loop BB0_339 Depth 4
                                        ;       Child Loop BB0_344 Depth 3
                                        ;       Child Loop BB0_349 Depth 3
                                        ;       Child Loop BB0_378 Depth 3
                                        ;         Child Loop BB0_380 Depth 4
                                        ;         Child Loop BB0_384 Depth 4
	s_add_i32 s2, s3, 64
	s_min_i32 s52, s41, s2
	s_mov_b64 s[8:9], -1
	s_and_b64 vcc, exec, s[6:7]
                                        ; implicit-def: $vgpr10_vgpr11
                                        ; implicit-def: $vgpr12_vgpr13
                                        ; implicit-def: $vgpr14_vgpr15
	s_cbranch_vccz .LBB0_341
; %bb.273:                              ;   in Loop: Header=BB0_272 Depth=2
	s_sub_i32 s53, s52, s3
	s_mul_i32 s27, s53, s89
	v_readfirstlane_b32 s26, v0
	v_cmp_gt_i32_e32 vcc, s27, v0
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_276
; %bb.274:                              ; %.preheader57
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v10, v35
	v_mov_b32_e32 v11, v0
.LBB0_275:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s27, v11
	ds_write_b32 v10, v33
	s_or_b64 s[24:25], vcc, s[24:25]
	v_add_u32_e32 v10, s95, v10
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execnz .LBB0_275
.LBB0_276:                              ; %Flow567
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_lshr_b32 s8, s79, 24
	s_add_i32 s8, s85, s8
	s_ashr_i32 s67, s8, 8
	s_mul_i32 s8, s53, s67
	s_add_i32 s9, s90, s8
	s_ashr_i32 s24, s9, 31
	s_abs_i32 s9, s9
	s_mul_hi_u32 s25, s9, s91
	s_lshr_b32 s62, s26, 6
	s_mul_i32 s26, s25, s89
	s_sub_i32 s9, s9, s26
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s9, s89
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s9, s27, s9
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s9, s26, s25
	s_xor_b32 s9, s9, s24
	s_sub_i32 s9, s9, s24
	s_mul_i32 s63, s62, s9
	s_add_i32 s9, s63, s9
	s_min_i32 s66, s8, s9
	s_mul_hi_i32 s9, s3, s85
	s_mul_i32 s8, s3, s85
	s_lshl_b64 s[8:9], s[8:9], 1
	s_add_u32 s8, s80, s8
	s_addc_u32 s9, s81, s9
	s_abs_i32 s24, s67
	v_cvt_f32_u32_e32 v10, s24
	s_sub_i32 s27, 0, s24
	s_abs_i32 s26, s63
	s_xor_b32 s25, s63, s67
	v_rcp_f32_e32 v10, v10
	s_ashr_i32 s25, s25, 31
	v_mov_b32_e32 v24, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_barrier
	v_readfirstlane_b32 s44, v10
	s_mul_i32 s27, s27, s44
	s_mul_hi_u32 s27, s44, s27
	s_add_i32 s44, s44, s27
	s_mul_hi_u32 s27, s26, s44
	s_mul_i32 s44, s27, s24
	s_sub_i32 s26, s26, s44
	s_add_i32 s44, s27, 1
	s_sub_i32 s45, s26, s24
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s27, s44, s27
	s_cselect_b32 s26, s45, s26
	s_add_i32 s44, s27, 1
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s24, s44, s27
	s_xor_b32 s24, s24, s25
	s_sub_i32 s74, s24, s25
	s_mul_i32 s24, s74, s67
	s_sub_i32 s70, s63, s24
	s_add_i32 s24, s63, 4
	s_cmp_le_i32 s24, s66
	s_cbranch_scc0 .LBB0_296
; %bb.277:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshlrev_b32_e32 v32, 3, v36
	s_mul_i32 s24, s62, s53
	v_lshl_add_u64 v[16:17], s[8:9], 0, v[32:33]
	s_lshl2_add_u32 s75, s24, s87
	v_mov_b32_e32 v24, 0
	s_mov_b32 s24, s63
	s_mov_b32 s82, s74
	s_branch .LBB0_280
.LBB0_278:                              ; %Flow555
                                        ;   in Loop: Header=BB0_280 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v22, 0
	s_mov_b32 s82, s25
.LBB0_279:                              ;   in Loop: Header=BB0_280 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s26, 0, s70
	v_lshl_or_b32 v23, s26, 10, v37
	ds_read_b128 v[90:93], v23
	s_add_i32 s44, s26, 1
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v47, 0xffff0000, v10
	v_lshlrev_b32_e32 v46, 16, v10
	s_cmp_eq_u32 s44, s67
	v_and_b32_e32 v25, 0xffff0000, v11
	v_lshlrev_b32_e32 v24, 16, v11
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[90:91], v[46:47]
	s_cselect_b64 s[26:27], -1, 0
	v_pk_mul_f32 v[24:25], v[92:93], v[24:25]
	v_add_f32_e32 v23, v46, v47
	s_and_b64 s[70:71], s[26:27], exec
	v_add_f32_e32 v23, v23, v24
	s_cselect_b32 s70, 0, s44
	s_cmp_lg_u64 s[26:27], 0
	v_add_f32_e32 v23, v23, v25
	s_addc_u32 s74, s25, 0
	s_add_i32 s76, s24, 4
	s_add_i32 s24, s24, 8
	v_add_f32_e32 v24, v22, v23
	s_cmp_le_i32 s24, s66
	s_mov_b32 s24, s76
	s_cbranch_scc0 .LBB0_297
.LBB0_280:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[26:27], s[24:25], 9
	v_lshl_add_u64 v[10:11], v[16:17], 0, s[26:27]
	s_add_i32 s26, s24, 1
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[12:13], v[16:17], 0, s[26:27]
	s_add_i32 s26, s24, 2
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[46:47], v[16:17], 0, s[26:27]
	s_add_i32 s26, s24, 3
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[72:73], v[16:17], 0, s[26:27]
	global_load_dwordx2 v[22:23], v[10:11], off nt
	global_load_dwordx2 v[14:15], v[12:13], off nt
	s_nop 0
	global_load_dwordx2 v[12:13], v[46:47], off nt
	global_load_dwordx2 v[10:11], v[72:73], off nt
	s_cmp_eq_u32 s74, s82
	s_cbranch_scc1 .LBB0_284
; %bb.281:                              ;   in Loop: Header=BB0_280 Depth=3
	ds_bpermute_b32 v25, v49, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v24, v24, v25
	ds_swizzle_b32 v25, v24 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v24, v24, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v24, v24, v24 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v24, v24, v24 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v24, v24, v24 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v24 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_283
; %bb.282:                              ;   in Loop: Header=BB0_280 Depth=3
	s_lshl2_add_u32 s25, s82, s75
	v_add_f32_e32 v24, v24, v25
	v_mov_b32_e32 v25, s25
	ds_read_b32 v32, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v24, v24, v32
	ds_write_b32 v25, v24
.LBB0_283:                              ; %Flow560
                                        ;   in Loop: Header=BB0_280 Depth=3
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v24, 0
.LBB0_284:                              ;   in Loop: Header=BB0_280 Depth=3
	v_lshl_or_b32 v25, s70, 10, v37
	ds_read_b128 v[90:93], v25
	s_waitcnt vmcnt(3)
	v_and_b32_e32 v47, 0xffff0000, v23
	v_lshlrev_b32_e32 v46, 16, v23
	v_and_b32_e32 v23, 0xffff0000, v22
	v_lshlrev_b32_e32 v22, 16, v22
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[90:91], v[22:23]
	v_pk_mul_f32 v[46:47], v[92:93], v[46:47]
	v_add_f32_e32 v22, v22, v23
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v22, v22, v46
	s_cmp_eq_u32 s70, s67
	v_add_f32_e32 v22, v22, v47
	s_cselect_b64 s[26:27], -1, 0
	s_addc_u32 s25, s74, 0
	s_cmp_lg_u32 s70, s67
	v_add_f32_e32 v22, v24, v22
	s_cbranch_scc1 .LBB0_288
; %bb.285:                              ;   in Loop: Header=BB0_280 Depth=3
	ds_bpermute_b32 v23, v49, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	ds_swizzle_b32 v23, v22 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_add_f32_dpp v22, v22, v22 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v23, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_287
; %bb.286:                              ;   in Loop: Header=BB0_280 Depth=3
	s_lshl2_add_u32 s44, s74, s75
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, s44
	ds_read_b32 v24, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v24
	ds_write_b32 v23, v22
.LBB0_287:                              ; %Flow559
                                        ;   in Loop: Header=BB0_280 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v22, 0
	s_mov_b32 s74, s25
.LBB0_288:                              ;   in Loop: Header=BB0_280 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s70, 0, s70
	v_lshl_or_b32 v23, s70, 10, v37
	ds_read_b128 v[90:93], v23
	s_waitcnt vmcnt(2)
	v_and_b32_e32 v47, 0xffff0000, v14
	v_lshlrev_b32_e32 v46, 16, v14
	v_and_b32_e32 v25, 0xffff0000, v15
	v_lshlrev_b32_e32 v24, 16, v15
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[90:91], v[46:47]
	v_pk_mul_f32 v[24:25], v[92:93], v[24:25]
	v_add_f32_e32 v23, v46, v47
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v23, v23, v24
	s_cmp_eq_u32 s70, s67
	v_add_f32_e32 v23, v23, v25
	s_cselect_b64 s[26:27], -1, 0
	s_addc_u32 s25, s25, 0
	s_cmp_eq_u32 s25, s74
	v_add_f32_e32 v22, v22, v23
	s_cbranch_scc1 .LBB0_292
; %bb.289:                              ;   in Loop: Header=BB0_280 Depth=3
	ds_bpermute_b32 v23, v49, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	ds_swizzle_b32 v23, v22 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_add_f32_dpp v22, v22, v22 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v23, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_291
; %bb.290:                              ;   in Loop: Header=BB0_280 Depth=3
	s_lshl2_add_u32 s44, s74, s75
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, s44
	ds_read_b32 v24, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v24
	ds_write_b32 v23, v22
.LBB0_291:                              ; %Flow557
                                        ;   in Loop: Header=BB0_280 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v22, 0
	s_mov_b32 s74, s25
.LBB0_292:                              ;   in Loop: Header=BB0_280 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s70, 0, s70
	v_lshl_or_b32 v23, s70, 10, v37
	ds_read_b128 v[90:93], v23
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v47, 0xffff0000, v12
	v_lshlrev_b32_e32 v46, 16, v12
	v_and_b32_e32 v25, 0xffff0000, v13
	v_lshlrev_b32_e32 v24, 16, v13
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[90:91], v[46:47]
	v_pk_mul_f32 v[24:25], v[92:93], v[24:25]
	v_add_f32_e32 v23, v46, v47
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v23, v23, v24
	s_cmp_eq_u32 s70, s67
	v_add_f32_e32 v23, v23, v25
	s_cselect_b64 s[26:27], -1, 0
	s_addc_u32 s25, s25, 0
	s_cmp_eq_u32 s25, s74
	v_add_f32_e32 v22, v22, v23
	s_cbranch_scc1 .LBB0_295
; %bb.293:                              ;   in Loop: Header=BB0_280 Depth=3
	ds_bpermute_b32 v23, v49, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	ds_swizzle_b32 v23, v22 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_add_f32_dpp v22, v22, v22 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v23, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_278
; %bb.294:                              ;   in Loop: Header=BB0_280 Depth=3
	s_lshl2_add_u32 s44, s74, s75
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, s44
	ds_read_b32 v24, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v24
	ds_write_b32 v23, v22
	s_branch .LBB0_278
.LBB0_295:                              ;   in Loop: Header=BB0_280 Depth=3
	s_mov_b32 s82, s74
	s_branch .LBB0_279
.LBB0_296:                              ;   in Loop: Header=BB0_272 Depth=2
	s_mov_b32 s76, s63
	s_mov_b32 s82, s74
	v_mov_b64_e32 v[10:11], v[116:117]
	v_mov_b64_e32 v[12:13], v[114:115]
	v_mov_b64_e32 v[14:15], v[112:113]
.LBB0_297:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_ge_i32 s76, s66
	s_cbranch_scc1 .LBB0_326
; %bb.298:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshlrev_b32_e32 v32, 3, v36
	s_ashr_i32 s77, s76, 31
	v_lshl_add_u64 v[22:23], s[8:9], 0, v[32:33]
	s_lshl_b64 s[8:9], s[76:77], 9
	v_lshl_add_u64 v[16:17], v[22:23], 0, s[8:9]
	global_load_dwordx2 v[16:17], v[16:17], off nt
	s_add_i32 s8, s76, 1
	s_cmp_lt_i32 s8, s66
	s_cselect_b64 s[26:27], -1, 0
	s_cmp_ge_i32 s8, s66
	s_cbranch_scc1 .LBB0_300
; %bb.299:                              ;   in Loop: Header=BB0_272 Depth=2
	s_ashr_i32 s9, s8, 31
	s_lshl_b64 s[8:9], s[8:9], 9
	v_lshl_add_u64 v[14:15], v[22:23], 0, s[8:9]
	global_load_dwordx2 v[14:15], v[14:15], off nt
.LBB0_300:                              ;   in Loop: Header=BB0_272 Depth=2
	s_add_i32 s8, s76, 2
	s_cmp_lt_i32 s8, s66
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_ge_i32 s8, s66
	s_cbranch_scc1 .LBB0_302
; %bb.301:                              ;   in Loop: Header=BB0_272 Depth=2
	s_ashr_i32 s9, s8, 31
	s_lshl_b64 s[8:9], s[8:9], 9
	v_lshl_add_u64 v[12:13], v[22:23], 0, s[8:9]
	global_load_dwordx2 v[12:13], v[12:13], off nt
.LBB0_302:                              ;   in Loop: Header=BB0_272 Depth=2
	s_add_i32 s76, s76, 3
	s_cmp_lt_i32 s76, s66
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_ge_i32 s76, s66
	s_cbranch_scc1 .LBB0_304
; %bb.303:                              ;   in Loop: Header=BB0_272 Depth=2
	s_ashr_i32 s77, s76, 31
	s_lshl_b64 s[76:77], s[76:77], 9
	v_lshl_add_u64 v[10:11], v[22:23], 0, s[76:77]
	global_load_dwordx2 v[10:11], v[10:11], off nt
.LBB0_304:                              ;   in Loop: Header=BB0_272 Depth=2
	s_mul_i32 s44, s62, s53
	s_lshl2_add_u32 s71, s44, s87
	s_cmp_eq_u32 s74, s82
	s_cbranch_scc1 .LBB0_308
; %bb.305:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v22, v49, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v24, v22
	ds_swizzle_b32 v23, v22 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_add_f32_dpp v22, v22, v22 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v22, v22, v22 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v23, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_307
; %bb.306:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl2_add_u32 s44, s82, s71
	v_add_f32_e32 v22, v22, v23
	v_mov_b32_e32 v23, s44
	ds_read_b32 v24, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v24
	ds_write_b32 v23, v22
.LBB0_307:                              ; %Flow552
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v24, 0
	s_mov_b32 s82, s74
.LBB0_308:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshl_or_b32 v22, s70, 10, v37
	ds_read_b128 v[90:93], v22
	s_add_i32 s70, s70, 1
	s_cmp_eq_u32 s70, s67
	s_cselect_b64 s[76:77], -1, 0
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v23, 0xffff0000, v17
	v_lshlrev_b32_e32 v22, 16, v17
	v_and_b32_e32 v17, 0xffff0000, v16
	v_lshlrev_b32_e32 v16, 16, v16
	s_and_b64 vcc, s[76:77], exec
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[16:17], v[90:91], v[16:17]
	s_cselect_b32 s70, 0, s70
	s_cmp_lg_u64 s[76:77], 0
	v_pk_mul_f32 v[22:23], v[92:93], v[22:23]
	v_add_f32_e32 v16, v16, v17
	s_addc_u32 s74, s74, 0
	v_add_f32_e32 v16, v16, v22
	s_and_b64 s[26:27], s[26:27], exec
	v_add_f32_e32 v16, v16, v23
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	v_add_f32_e32 v24, v24, v16
	s_cbranch_scc1 .LBB0_320
; %bb.309:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_eq_u32 s74, s82
	s_cbranch_scc1 .LBB0_313
; %bb.310:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v16, v49, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v24, v16
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_312
; %bb.311:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl2_add_u32 s44, s82, s71
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, s44
	ds_read_b32 v22, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v22
	ds_write_b32 v17, v16
.LBB0_312:                              ; %Flow549
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v24, 0
	s_mov_b32 s82, s74
.LBB0_313:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshl_or_b32 v16, s70, 10, v37
	ds_read_b128 v[90:93], v16
	v_and_b32_e32 v23, 0xffff0000, v14
	v_lshlrev_b32_e32 v22, 16, v14
	s_add_i32 s44, s70, 1
	v_and_b32_e32 v17, 0xffff0000, v15
	v_lshlrev_b32_e32 v16, 16, v15
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[90:91], v[22:23]
	s_cmp_eq_u32 s44, s67
	v_pk_mul_f32 v[16:17], v[92:93], v[16:17]
	v_add_f32_e32 v22, v22, v23
	s_cselect_b64 s[26:27], -1, 0
	v_add_f32_e32 v16, v22, v16
	s_and_b64 s[76:77], s[26:27], exec
	v_add_f32_e32 v16, v16, v17
	s_cselect_b32 s70, 0, s44
	s_cmp_lg_u64 s[26:27], 0
	v_add_f32_e32 v24, v24, v16
	s_addc_u32 s74, s74, 0
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	s_cbranch_scc0 .LBB0_321
.LBB0_314:                              ;   in Loop: Header=BB0_272 Depth=2
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_cbranch_scc1 .LBB0_326
.LBB0_315:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_eq_u32 s74, s82
	s_cbranch_scc1 .LBB0_319
; %bb.316:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v16, v49, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v24, v16
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_318
; %bb.317:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl2_add_u32 s24, s82, s71
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, s24
	ds_read_b32 v22, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v22
	ds_write_b32 v17, v16
.LBB0_318:                              ; %Flow543
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
	v_mov_b32_e32 v24, 0
	s_mov_b32 s82, s74
.LBB0_319:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshl_or_b32 v16, s70, 10, v37
	ds_read_b128 v[90:93], v16
	v_and_b32_e32 v23, 0xffff0000, v10
	v_lshlrev_b32_e32 v22, 16, v10
	v_and_b32_e32 v17, 0xffff0000, v11
	v_lshlrev_b32_e32 v16, 16, v11
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[90:91], v[22:23]
	v_pk_mul_f32 v[16:17], v[92:93], v[16:17]
	v_add_f32_e32 v22, v22, v23
	v_add_f32_e32 v16, v22, v16
	v_add_f32_e32 v16, v16, v17
	v_add_f32_e32 v24, v24, v16
	s_cmp_ge_i32 s63, s66
	s_cbranch_scc0 .LBB0_327
	s_branch .LBB0_330
.LBB0_320:                              ;   in Loop: Header=BB0_272 Depth=2
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	s_cbranch_scc1 .LBB0_314
.LBB0_321:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_eq_u32 s74, s82
	s_cbranch_scc1 .LBB0_325
; %bb.322:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v16, v49, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v24, v16
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_324
; %bb.323:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl2_add_u32 s26, s82, s71
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, s26
	ds_read_b32 v22, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v22
	ds_write_b32 v17, v16
.LBB0_324:                              ; %Flow546
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v24, 0
	s_mov_b32 s82, s74
.LBB0_325:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshl_or_b32 v16, s70, 10, v37
	ds_read_b128 v[90:93], v16
	v_and_b32_e32 v23, 0xffff0000, v12
	v_lshlrev_b32_e32 v22, 16, v12
	s_add_i32 s70, s70, 1
	v_and_b32_e32 v17, 0xffff0000, v13
	v_lshlrev_b32_e32 v16, 16, v13
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[90:91], v[22:23]
	s_cmp_eq_u32 s70, s67
	v_pk_mul_f32 v[16:17], v[92:93], v[16:17]
	v_add_f32_e32 v22, v22, v23
	s_cselect_b64 s[24:25], -1, 0
	v_add_f32_e32 v16, v22, v16
	s_and_b64 s[26:27], s[24:25], exec
	v_add_f32_e32 v16, v16, v17
	s_cselect_b32 s70, 0, s70
	s_cmp_lg_u64 s[24:25], 0
	v_add_f32_e32 v24, v24, v16
	s_addc_u32 s74, s74, 0
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_cbranch_scc0 .LBB0_315
.LBB0_326:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_ge_i32 s63, s66
	s_cbranch_scc1 .LBB0_330
.LBB0_327:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v16, v49, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v24, v16
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_329
; %bb.328:                              ;   in Loop: Header=BB0_272 Depth=2
	s_mul_i32 s62, s62, s53
	s_lshl2_add_u32 s24, s62, s87
	s_lshl2_add_u32 s24, s82, s24
	v_mov_b32_e32 v22, s24
	ds_read_b32 v23, v22
	v_add_f32_e32 v16, v16, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v23
	ds_write_b32 v22, v16
.LBB0_329:                              ; %Flow542
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
.LBB0_330:                              ;   in Loop: Header=BB0_272 Depth=2
	v_cmp_gt_i32_e32 vcc, s53, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_340
; %bb.331:                              ;   in Loop: Header=BB0_272 Depth=2
	s_sub_i32 s24, s3, s86
	s_lshl2_add_u32 s62, s24, s43
	s_lshl_b32 s63, s53, 2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v16, v35
	v_mov_b32_e32 v17, v0
	s_branch .LBB0_333
.LBB0_332:                              ;   in Loop: Header=BB0_333 Depth=3
	v_bfe_u32 v23, v22, 16, 1
	v_add3_u32 v23, v23, v22, s97
	v_or_b32_e32 v24, 0x400000, v22
	v_cmp_u_f32_e32 vcc, v22, v22
	v_add_u32_e32 v16, s95, v16
	s_nop 0
	v_cndmask_b32_e32 v22, v23, v24, vcc
	v_lshl_add_u32 v23, v17, 2, s62
	v_add_u32_e32 v17, s88, v17
	v_cmp_le_i32_e32 vcc, s53, v17
	v_and_b32_e32 v22, 0xffff0000, v22
	s_or_b64 s[24:25], vcc, s[24:25]
	ds_write_b32 v23, v22
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execz .LBB0_340
.LBB0_333:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_335 Depth 4
                                        ;         Child Loop BB0_339 Depth 4
	s_and_b64 s[26:27], s[64:65], exec
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	s_cbranch_scc1 .LBB0_337
; %bb.334:                              ; %.preheader36
                                        ;   in Loop: Header=BB0_333 Depth=3
	v_lshl_add_u32 v23, v17, 2, s87
	s_mov_b32 s26, 0
	v_mov_b32_e32 v22, 0
.LBB0_335:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ;       Parent Loop BB0_333 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	s_mul_i32 s27, s26, s53
	v_lshl_add_u32 v24, s27, 2, v23
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	s_add_i32 s26, s26, 8
	s_cmp_lg_u32 s26, s93
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v25
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v25
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v25
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v25
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v25
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v25
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s63, v24
	ds_read_b32 v24, v24
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v22, v22, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v24
	s_cbranch_scc1 .LBB0_335
; %bb.336:                              ;   in Loop: Header=BB0_333 Depth=3
	s_mov_b32 s66, s93
	s_mov_b64 s[26:27], s[16:17]
	s_and_b64 vcc, exec, s[26:27]
	s_cbranch_vccz .LBB0_332
	s_branch .LBB0_338
.LBB0_337:                              ;   in Loop: Header=BB0_333 Depth=3
	s_mov_b32 s66, 0
	v_mov_b32_e32 v22, 0
	s_cbranch_execz .LBB0_332
.LBB0_338:                              ;   in Loop: Header=BB0_333 Depth=3
	s_mul_i32 s26, s63, s66
	v_add_u32_e32 v23, s26, v16
	s_mov_b32 s26, s92
.LBB0_339:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ;       Parent Loop BB0_333 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ds_read_b32 v24, v23
	s_add_i32 s26, s26, -1
	v_add_u32_e32 v23, s63, v23
	s_cmp_lg_u32 s26, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v24
	s_cbranch_scc1 .LBB0_339
	s_branch .LBB0_332
.LBB0_340:                              ; %Flow541
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_mov_b64 s[8:9], 0
.LBB0_341:                              ; %Flow590
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccz .LBB0_271
; %bb.342:                              ;   in Loop: Header=BB0_272 Depth=2
	s_sub_i32 s52, s52, s3
	s_mul_i32 s27, s52, s89
	v_readfirstlane_b32 s26, v0
	v_cmp_gt_i32_e32 vcc, s27, v0
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_345
; %bb.343:                              ; %.preheader53
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v10, v35
	v_mov_b32_e32 v11, v0
.LBB0_344:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s27, v11
	ds_write_b32 v10, v33
	s_or_b64 s[24:25], vcc, s[24:25]
	v_add_u32_e32 v10, s95, v10
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execnz .LBB0_344
.LBB0_345:                              ; %Flow589
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_lshr_b32 s8, s79, 23
	s_add_i32 s8, s85, s8
	s_ashr_i32 s66, s8, 9
	s_mul_i32 s8, s52, s66
	s_add_i32 s9, s90, s8
	s_ashr_i32 s24, s9, 31
	s_abs_i32 s9, s9
	s_mul_hi_u32 s25, s9, s91
	s_lshr_b32 s53, s26, 6
	s_mul_i32 s26, s25, s89
	s_sub_i32 s9, s9, s26
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s9, s89
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s9, s27, s9
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s9, s26, s25
	s_xor_b32 s9, s9, s24
	s_sub_i32 s9, s9, s24
	s_mul_i32 s62, s53, s9
	s_add_i32 s9, s62, s9
	s_min_i32 s63, s8, s9
	s_mul_hi_i32 s9, s3, s85
	s_mul_i32 s8, s3, s85
	s_lshl_b64 s[8:9], s[8:9], 1
	s_add_u32 s8, s80, s8
	s_addc_u32 s9, s81, s9
	s_abs_i32 s24, s66
	v_cvt_f32_u32_e32 v10, s24
	s_sub_i32 s27, 0, s24
	s_abs_i32 s26, s62
	s_xor_b32 s25, s62, s66
	v_rcp_f32_e32 v10, v10
	s_ashr_i32 s25, s25, 31
	v_mov_b32_e32 v16, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_barrier
	v_readfirstlane_b32 s44, v10
	s_mul_i32 s27, s27, s44
	s_mul_hi_u32 s27, s44, s27
	s_add_i32 s44, s44, s27
	s_mul_hi_u32 s27, s26, s44
	s_mul_i32 s44, s27, s24
	s_sub_i32 s26, s26, s44
	s_add_i32 s44, s27, 1
	s_sub_i32 s45, s26, s24
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s27, s44, s27
	s_cselect_b32 s26, s45, s26
	s_add_i32 s44, s27, 1
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s24, s44, s27
	s_xor_b32 s24, s24, s25
	s_sub_i32 s74, s24, s25
	s_mul_i32 s24, s74, s66
	s_sub_i32 s75, s62, s24
	s_add_i32 s24, s62, 2
	s_cmp_le_i32 s24, s63
	s_cbranch_scc0 .LBB0_357
; %bb.346:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshlrev_b32_e32 v32, 4, v36
	s_mul_i32 s24, s53, s52
	v_lshl_add_u64 v[14:15], s[8:9], 0, v[32:33]
	s_lshl2_add_u32 s70, s24, s87
	v_mov_b32_e32 v16, 0
	s_mov_b32 s24, s62
	s_mov_b32 s67, s74
	s_branch .LBB0_349
.LBB0_347:                              ; %Flow581
                                        ;   in Loop: Header=BB0_349 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v10, 0
	s_mov_b32 s67, s25
.LBB0_348:                              ;   in Loop: Header=BB0_349 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s26, 0, s71
	v_lshl_or_b32 v11, s26, 11, v50
	ds_read_b128 v[22:25], v11
	ds_read_b128 v[90:93], v11 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v73, 0xffff0000, v18
	v_lshlrev_b32_e32 v72, 16, v18
	v_and_b32_e32 v47, 0xffff0000, v19
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[22:23], v[22:23], v[72:73]
	v_lshlrev_b32_e32 v46, 16, v19
	v_add_f32_e32 v11, 0, v22
	v_pk_mul_f32 v[24:25], v[24:25], v[46:47]
	v_add_f32_e32 v11, v11, v23
	v_and_b32_e32 v17, 0xffff0000, v20
	v_lshlrev_b32_e32 v16, 16, v20
	v_add_f32_e32 v11, v11, v24
	s_add_i32 s44, s26, 1
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[16:17], v[90:91], v[16:17]
	v_add_f32_e32 v11, v11, v25
	s_cmp_eq_u32 s44, s66
	v_and_b32_e32 v13, 0xffff0000, v21
	v_lshlrev_b32_e32 v12, 16, v21
	v_add_f32_e32 v11, v11, v16
	s_cselect_b64 s[26:27], -1, 0
	v_pk_mul_f32 v[12:13], v[92:93], v[12:13]
	v_add_f32_e32 v11, v11, v17
	s_and_b64 s[74:75], s[26:27], exec
	v_add_f32_e32 v11, v11, v12
	s_cselect_b32 s75, 0, s44
	s_cmp_lg_u64 s[26:27], 0
	v_add_f32_e32 v11, v11, v13
	s_addc_u32 s74, s25, 0
	s_add_i32 s26, s24, 2
	s_add_i32 s24, s24, 4
	v_add_f32_e32 v16, v10, v11
	s_cmp_le_i32 s24, s63
	s_mov_b32 s24, s26
	s_cbranch_scc0 .LBB0_358
.LBB0_349:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[26:27], s[24:25], 10
	v_lshl_add_u64 v[10:11], v[14:15], 0, s[26:27]
	s_add_i32 s26, s24, 1
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 10
	v_lshl_add_u64 v[18:19], v[14:15], 0, s[26:27]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_nop 0
	global_load_dwordx4 v[18:21], v[18:19], off nt
	s_cmp_eq_u32 s74, s67
	s_cbranch_scc1 .LBB0_353
; %bb.350:                              ;   in Loop: Header=BB0_349 Depth=3
	ds_bpermute_b32 v17, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_352
; %bb.351:                              ;   in Loop: Header=BB0_349 Depth=3
	s_lshl2_add_u32 s25, s67, s70
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, s25
	ds_read_b32 v22, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v22
	ds_write_b32 v17, v16
.LBB0_352:                              ; %Flow582
                                        ;   in Loop: Header=BB0_349 Depth=3
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v16, 0
.LBB0_353:                              ;   in Loop: Header=BB0_349 Depth=3
	v_lshl_or_b32 v17, s75, 11, v50
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v47, 0xffff0000, v13
	v_lshlrev_b32_e32 v46, 16, v13
	v_and_b32_e32 v73, 0xffff0000, v12
	v_lshlrev_b32_e32 v72, 16, v12
	v_and_b32_e32 v91, 0xffff0000, v11
	v_lshlrev_b32_e32 v90, 16, v11
	v_and_b32_e32 v93, 0xffff0000, v10
	v_lshlrev_b32_e32 v92, 16, v10
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[22:25], v17 offset:16
	s_add_i32 s71, s75, 1
	s_cmp_eq_u32 s71, s66
	s_cselect_b64 s[26:27], -1, 0
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[92:93]
	v_pk_mul_f32 v[12:13], v[12:13], v[90:91]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[72:73]
	v_add_f32_e32 v10, v10, v13
	v_add_f32_e32 v10, v10, v22
	v_pk_mul_f32 v[24:25], v[24:25], v[46:47]
	v_add_f32_e32 v10, v10, v23
	v_add_f32_e32 v10, v10, v24
	v_add_f32_e32 v10, v10, v25
	s_addc_u32 s25, s74, 0
	v_add_f32_e32 v10, v16, v10
	s_cmp_lg_u32 s71, s66
	s_cbranch_scc1 .LBB0_356
; %bb.354:                              ;   in Loop: Header=BB0_349 Depth=3
	ds_bpermute_b32 v11, v49, v10
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_347
; %bb.355:                              ;   in Loop: Header=BB0_349 Depth=3
	s_lshl2_add_u32 s44, s74, s70
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s44
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
	s_branch .LBB0_347
.LBB0_356:                              ;   in Loop: Header=BB0_349 Depth=3
	s_mov_b32 s67, s74
	s_branch .LBB0_348
.LBB0_357:                              ;   in Loop: Header=BB0_272 Depth=2
	s_mov_b32 s26, s62
	s_mov_b32 s67, s74
.LBB0_358:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_ge_i32 s26, s63
	s_cbranch_scc1 .LBB0_371
; %bb.359:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshlrev_b32_e32 v32, 4, v36
	s_ashr_i32 s27, s26, 31
	v_lshl_add_u64 v[14:15], s[8:9], 0, v[32:33]
	s_lshl_b64 s[8:9], s[26:27], 10
	v_lshl_add_u64 v[10:11], v[14:15], 0, s[8:9]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_add_i32 s24, s26, 1
	s_cmp_lt_i32 s24, s63
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_ge_i32 s24, s63
	s_cbranch_scc1 .LBB0_361
; %bb.360:                              ;   in Loop: Header=BB0_272 Depth=2
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[24:25], s[24:25], 10
	v_lshl_add_u64 v[14:15], v[14:15], 0, s[24:25]
	global_load_dwordx4 v[18:21], v[14:15], off nt
.LBB0_361:                              ;   in Loop: Header=BB0_272 Depth=2
	s_mul_i32 s24, s53, s52
	s_lshl2_add_u32 s26, s24, s87
	s_cmp_eq_u32 s74, s67
	s_cbranch_scc1 .LBB0_365
; %bb.362:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v14, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v16, v14
	ds_swizzle_b32 v15, v14 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v14, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v14, v14, v14 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v14, v14, v14 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v14, v14, v14 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v14 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_364
; %bb.363:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl2_add_u32 s27, s67, s26
	v_add_f32_e32 v14, v14, v15
	v_mov_b32_e32 v15, s27
	ds_read_b32 v16, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v14, v16
	ds_write_b32 v15, v14
.LBB0_364:                              ; %Flow578
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v16, 0
	s_mov_b32 s67, s74
.LBB0_365:                              ;   in Loop: Header=BB0_272 Depth=2
	v_lshl_or_b32 v17, s75, 11, v50
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v15, 0xffff0000, v13
	v_lshlrev_b32_e32 v14, 16, v13
	v_and_b32_e32 v47, 0xffff0000, v12
	v_lshlrev_b32_e32 v46, 16, v12
	v_and_b32_e32 v73, 0xffff0000, v11
	v_lshlrev_b32_e32 v72, 16, v11
	v_and_b32_e32 v91, 0xffff0000, v10
	v_lshlrev_b32_e32 v90, 16, v10
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[22:25], v17 offset:16
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[90:91]
	v_pk_mul_f32 v[12:13], v[12:13], v[72:73]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[46:47]
	v_add_f32_e32 v10, v10, v13
	v_add_f32_e32 v10, v10, v22
	v_pk_mul_f32 v[14:15], v[24:25], v[14:15]
	v_add_f32_e32 v10, v10, v23
	v_add_f32_e32 v10, v10, v14
	v_add_f32_e32 v10, v10, v15
	v_add_f32_e32 v16, v16, v10
	s_cbranch_scc1 .LBB0_371
; %bb.366:                              ;   in Loop: Header=BB0_272 Depth=2
	s_add_i32 s75, s75, 1
	s_cmp_eq_u32 s75, s66
	s_cselect_b64 s[8:9], -1, 0
	s_addc_u32 s27, s74, 0
	s_cmp_eq_u32 s27, s67
	s_cbranch_scc1 .LBB0_370
; %bb.367:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v10, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v16, v10
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_369
; %bb.368:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl2_add_u32 s26, s67, s26
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s26
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
.LBB0_369:                              ; %Flow575
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v16, 0
	s_mov_b32 s67, s27
.LBB0_370:                              ;   in Loop: Header=BB0_272 Depth=2
	s_lshl_b32 s24, s75, 11
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 0, s24
	v_or_b32_e32 v17, s8, v50
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[22:25], v17 offset:16
	v_and_b32_e32 v91, 0xffff0000, v18
	v_lshlrev_b32_e32 v90, 16, v18
	v_and_b32_e32 v73, 0xffff0000, v19
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[90:91]
	v_lshlrev_b32_e32 v72, 16, v19
	v_add_f32_e32 v10, 0, v10
	v_pk_mul_f32 v[12:13], v[12:13], v[72:73]
	v_add_f32_e32 v10, v10, v11
	v_and_b32_e32 v47, 0xffff0000, v20
	v_lshlrev_b32_e32 v46, 16, v20
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[46:47]
	v_add_f32_e32 v10, v10, v13
	v_and_b32_e32 v15, 0xffff0000, v21
	v_lshlrev_b32_e32 v14, 16, v21
	v_add_f32_e32 v10, v10, v22
	v_pk_mul_f32 v[14:15], v[24:25], v[14:15]
	v_add_f32_e32 v10, v10, v23
	v_add_f32_e32 v10, v10, v14
	v_add_f32_e32 v10, v10, v15
	v_add_f32_e32 v16, v16, v10
.LBB0_371:                              ;   in Loop: Header=BB0_272 Depth=2
	s_cmp_ge_i32 s62, s63
	s_cbranch_scc1 .LBB0_375
; %bb.372:                              ;   in Loop: Header=BB0_272 Depth=2
	ds_bpermute_b32 v10, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v16, v10
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_374
; %bb.373:                              ;   in Loop: Header=BB0_272 Depth=2
	s_mul_i32 s53, s53, s52
	s_lshl2_add_u32 s24, s53, s87
	s_lshl2_add_u32 s24, s67, s24
	v_mov_b32_e32 v12, s24
	ds_read_b32 v13, v12
	v_add_f32_e32 v10, v10, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v13
	ds_write_b32 v12, v10
.LBB0_374:                              ; %Flow574
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
.LBB0_375:                              ;   in Loop: Header=BB0_272 Depth=2
	v_cmp_gt_i32_e32 vcc, s52, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_385
; %bb.376:                              ;   in Loop: Header=BB0_272 Depth=2
	s_sub_i32 s3, s3, s86
	s_lshl2_add_u32 s3, s3, s43
	s_lshl_b32 s53, s52, 2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v10, v35
	v_mov_b32_e32 v11, v0
	s_branch .LBB0_378
.LBB0_377:                              ;   in Loop: Header=BB0_378 Depth=3
	v_bfe_u32 v13, v12, 16, 1
	v_add3_u32 v13, v13, v12, s97
	v_or_b32_e32 v14, 0x400000, v12
	v_cmp_u_f32_e32 vcc, v12, v12
	v_add_u32_e32 v10, s95, v10
	s_nop 0
	v_cndmask_b32_e32 v12, v13, v14, vcc
	v_lshl_add_u32 v13, v11, 2, s3
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s52, v11
	v_and_b32_e32 v12, 0xffff0000, v12
	s_or_b64 s[24:25], vcc, s[24:25]
	ds_write_b32 v13, v12
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execz .LBB0_385
.LBB0_378:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_380 Depth 4
                                        ;         Child Loop BB0_384 Depth 4
	s_and_b64 s[26:27], s[64:65], exec
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	s_cbranch_scc1 .LBB0_382
; %bb.379:                              ; %.preheader34
                                        ;   in Loop: Header=BB0_378 Depth=3
	v_lshl_add_u32 v13, v11, 2, s87
	s_mov_b32 s26, 0
	v_mov_b32_e32 v12, 0
.LBB0_380:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ;       Parent Loop BB0_378 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	s_mul_i32 s27, s26, s52
	v_lshl_add_u32 v14, s27, 2, v13
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	s_add_i32 s26, s26, 8
	s_cmp_lg_u32 s26, s93
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s53, v14
	ds_read_b32 v14, v14
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v12, v12, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v14
	s_cbranch_scc1 .LBB0_380
; %bb.381:                              ;   in Loop: Header=BB0_378 Depth=3
	s_mov_b32 s62, s93
	s_mov_b64 s[26:27], s[16:17]
	s_and_b64 vcc, exec, s[26:27]
	s_cbranch_vccz .LBB0_377
	s_branch .LBB0_383
.LBB0_382:                              ;   in Loop: Header=BB0_378 Depth=3
	s_mov_b32 s62, 0
	v_mov_b32_e32 v12, 0
	s_cbranch_execz .LBB0_377
.LBB0_383:                              ;   in Loop: Header=BB0_378 Depth=3
	s_mul_i32 s26, s53, s62
	v_add_u32_e32 v13, s26, v10
	s_mov_b32 s26, s92
.LBB0_384:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_272 Depth=2
                                        ;       Parent Loop BB0_378 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ds_read_b32 v14, v13
	s_add_i32 s26, s26, -1
	v_add_u32_e32 v13, s53, v13
	s_cmp_lg_u32 s26, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v14
	s_cbranch_scc1 .LBB0_384
	s_branch .LBB0_377
.LBB0_385:                              ; %Flow573
                                        ;   in Loop: Header=BB0_272 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cmp_lt_i32 s2, s41
	s_mov_b32 s3, s2
	s_cbranch_scc1 .LBB0_272
.LBB0_386:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mul_hi_i32 s9, s85, s84
	s_mul_i32 s8, s85, s84
	s_ashr_i32 s2, s84, 31
	s_lshl_b64 s[8:9], s[8:9], 1
	s_add_u32 s3, s80, s8
	s_addc_u32 s52, s81, s9
	s_sub_i32 s8, s40, s86
	s_lshl2_add_u32 s53, s8, s43
	v_mov_b64_e32 v[22:23], v[98:99]
	v_mov_b64_e32 v[24:25], v[100:101]
	s_mov_b32 s67, s86
	v_mov_b64_e32 v[96:97], v[8:9]
	v_mov_b64_e32 v[94:95], v[6:7]
	v_mov_b64_e32 v[92:93], v[4:5]
	v_mov_b64_e32 v[90:91], v[2:3]
	s_branch .LBB0_388
.LBB0_387:                              ;   in Loop: Header=BB0_388 Depth=2
	v_mov_b64_e32 v[96:97], v[16:17]
	v_mov_b64_e32 v[94:95], v[14:15]
	v_mov_b64_e32 v[92:93], v[12:13]
	v_mov_b64_e32 v[90:91], v[10:11]
	s_cmp_lt_i32 s66, s41
	s_mov_b32 s67, s66
	s_cbranch_scc0 .LBB0_502
.LBB0_388:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_391 Depth 3
                                        ;       Child Loop BB0_396 Depth 3
                                        ;       Child Loop BB0_449 Depth 3
                                        ;         Child Loop BB0_451 Depth 4
                                        ;         Child Loop BB0_455 Depth 4
                                        ;       Child Loop BB0_460 Depth 3
                                        ;       Child Loop BB0_465 Depth 3
                                        ;       Child Loop BB0_494 Depth 3
                                        ;         Child Loop BB0_496 Depth 4
                                        ;         Child Loop BB0_500 Depth 4
	s_add_i32 s66, s67, 64
	s_min_i32 s82, s41, s66
	s_mov_b64 s[8:9], -1
	s_and_b64 vcc, exec, s[6:7]
                                        ; implicit-def: $vgpr10_vgpr11_vgpr12_vgpr13_vgpr14_vgpr15_vgpr16_vgpr17
	s_cbranch_vccz .LBB0_457
; %bb.389:                              ;   in Loop: Header=BB0_388 Depth=2
	s_sub_i32 s83, s82, s67
	s_mul_i32 s27, s83, s89
	v_readfirstlane_b32 s26, v0
	v_cmp_gt_i32_e32 vcc, s27, v0
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_392
; %bb.390:                              ; %.preheader49
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v10, v35
	v_mov_b32_e32 v11, v0
.LBB0_391:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s27, v11
	ds_write_b32 v10, v33
	s_or_b64 s[24:25], vcc, s[24:25]
	v_add_u32_e32 v10, s95, v10
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execnz .LBB0_391
.LBB0_392:                              ; %Flow508
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_lshr_b32 s8, s79, 24
	s_add_i32 s8, s85, s8
	s_ashr_i32 vcc_lo, s8, 8
	s_mul_i32 s8, s83, vcc_lo
	s_add_i32 s9, s90, s8
	s_ashr_i32 s24, s9, 31
	s_abs_i32 s9, s9
	s_mul_hi_u32 s25, s9, s91
	s_lshr_b32 s62, s26, 6
	s_mul_i32 s26, s25, s89
	s_sub_i32 s9, s9, s26
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s9, s89
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s9, s27, s9
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s9, s26, s25
	s_xor_b32 s9, s9, s24
	s_sub_i32 s9, s9, s24
	s_mul_i32 s63, s62, s9
	s_add_i32 s9, s63, s9
	s_min_i32 s96, s8, s9
	s_mul_hi_i32 s9, s67, s85
	s_mul_i32 s8, s67, s85
	s_lshl_b64 s[8:9], s[8:9], 1
	s_add_u32 s8, s3, s8
	s_addc_u32 s9, s52, s9
	s_abs_i32 s24, vcc_lo
	v_cvt_f32_u32_e32 v10, s24
	s_sub_i32 s27, 0, s24
	s_abs_i32 s26, s63
	s_xor_b32 s25, s63, vcc_lo
	v_rcp_f32_e32 v10, v10
	s_ashr_i32 s25, s25, 31
	v_mov_b32_e32 v72, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_barrier
	v_readfirstlane_b32 s44, v10
	s_mul_i32 s27, s27, s44
	s_mul_hi_u32 s27, s44, s27
	s_add_i32 s44, s44, s27
	s_mul_hi_u32 s27, s26, s44
	s_mul_i32 s44, s27, s24
	s_sub_i32 s26, s26, s44
	s_add_i32 s44, s27, 1
	s_sub_i32 s45, s26, s24
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s27, s44, s27
	s_cselect_b32 s26, s45, s26
	s_add_i32 s44, s27, 1
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s24, s44, s27
	s_xor_b32 s24, s24, s25
	s_sub_i32 vcc_hi, s24, s25
	s_mul_i32 s24, vcc_hi, vcc_lo
	s_sub_i32 s99, s63, s24
	s_add_i32 s24, s63, 4
	s_cmp_le_i32 s24, s96
	s_cbranch_scc0 .LBB0_412
; %bb.393:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshlrev_b32_e32 v32, 3, v36
	s_mul_i32 s24, s62, s83
	v_lshl_add_u64 v[10:11], s[8:9], 0, v[32:33]
	s_lshl2_add_u32 s75, s24, s87
	v_mov_b32_e32 v72, 0
	s_mov_b32 s24, s63
	s_mov_b32 s74, vcc_hi
	s_branch .LBB0_396
.LBB0_394:                              ; %Flow496
                                        ;   in Loop: Header=BB0_396 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v32, 0
	s_mov_b32 s74, s25
.LBB0_395:                              ;   in Loop: Header=BB0_396 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s26, 0, s70
	v_lshl_or_b32 v46, s26, 10, v37
	ds_read_b128 v[118:121], v46
	s_add_i32 s70, s26, 1
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v73, 0xffff0000, v16
	v_lshlrev_b32_e32 v72, 16, v16
	s_cmp_eq_u32 s70, vcc_lo
	v_and_b32_e32 v47, 0xffff0000, v17
	v_lshlrev_b32_e32 v46, 16, v17
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[72:73], v[118:119], v[72:73]
	s_cselect_b64 s[26:27], -1, 0
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v72, v72, v73
	s_and_b64 s[44:45], s[26:27], exec
	v_add_f32_e32 v46, v72, v46
	s_cselect_b32 s99, 0, s70
	s_cmp_lg_u64 s[26:27], 0
	v_add_f32_e32 v46, v46, v47
	s_addc_u32 vcc_hi, s25, 0
	s_add_i32 s76, s24, 4
	s_add_i32 s24, s24, 8
	v_add_f32_e32 v72, v32, v46
	s_cmp_le_i32 s24, s96
	s_mov_b32 s24, s76
	s_cbranch_scc0 .LBB0_413
.LBB0_396:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[26:27], s[24:25], 9
	v_lshl_add_u64 v[12:13], v[10:11], 0, s[26:27]
	s_add_i32 s26, s24, 1
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	global_load_dwordx2 v[46:47], v[12:13], off nt
	v_lshl_add_u64 v[12:13], v[10:11], 0, s[26:27]
	s_add_i32 s26, s24, 2
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[14:15], v[10:11], 0, s[26:27]
	s_add_i32 s26, s24, 3
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[16:17], v[10:11], 0, s[26:27]
	global_load_dwordx2 v[12:13], v[12:13], off nt
	s_cmp_eq_u32 vcc_hi, s74
	global_load_dwordx2 v[14:15], v[14:15], off nt
	s_nop 0
	global_load_dwordx2 v[16:17], v[16:17], off nt
	s_cbranch_scc1 .LBB0_400
; %bb.397:                              ;   in Loop: Header=BB0_396 Depth=3
	ds_bpermute_b32 v32, v49, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v72, v32
	ds_swizzle_b32 v72, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v72
	v_mov_b32_e32 v72, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v72, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_399
; %bb.398:                              ;   in Loop: Header=BB0_396 Depth=3
	s_lshl2_add_u32 s25, s74, s75
	v_add_f32_e32 v32, v32, v72
	v_mov_b32_e32 v72, s25
	ds_read_b32 v73, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v73
	ds_write_b32 v72, v32
.LBB0_399:                              ; %Flow501
                                        ;   in Loop: Header=BB0_396 Depth=3
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v72, 0
.LBB0_400:                              ;   in Loop: Header=BB0_396 Depth=3
	v_lshl_or_b32 v32, s99, 10, v37
	ds_read_b128 v[118:121], v32
	s_waitcnt vmcnt(3)
	v_and_b32_e32 v123, 0xffff0000, v47
	v_lshlrev_b32_e32 v122, 16, v47
	v_and_b32_e32 v47, 0xffff0000, v46
	v_lshlrev_b32_e32 v46, 16, v46
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[118:119], v[46:47]
	v_pk_mul_f32 v[120:121], v[120:121], v[122:123]
	v_add_f32_e32 v32, v46, v47
	s_add_i32 s70, s99, 1
	v_add_f32_e32 v32, v32, v120
	s_cmp_eq_u32 s70, vcc_lo
	v_add_f32_e32 v32, v32, v121
	s_cselect_b64 s[26:27], -1, 0
	s_addc_u32 s25, vcc_hi, 0
	s_cmp_lg_u32 s70, vcc_lo
	v_add_f32_e32 v32, v72, v32
	s_cbranch_scc1 .LBB0_404
; %bb.401:                              ;   in Loop: Header=BB0_396 Depth=3
	ds_bpermute_b32 v46, v49, v32
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_403
; %bb.402:                              ;   in Loop: Header=BB0_396 Depth=3
	s_lshl2_add_u32 s44, vcc_hi, s75
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_403:                              ; %Flow500
                                        ;   in Loop: Header=BB0_396 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v32, 0
	s_mov_b32 vcc_hi, s25
.LBB0_404:                              ;   in Loop: Header=BB0_396 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s70, 0, s70
	v_lshl_or_b32 v46, s70, 10, v37
	ds_read_b128 v[118:121], v46
	s_waitcnt vmcnt(2)
	v_and_b32_e32 v73, 0xffff0000, v12
	v_lshlrev_b32_e32 v72, 16, v12
	v_and_b32_e32 v47, 0xffff0000, v13
	v_lshlrev_b32_e32 v46, 16, v13
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[72:73], v[118:119], v[72:73]
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v72, v72, v73
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v46, v72, v46
	s_cmp_eq_u32 s70, vcc_lo
	v_add_f32_e32 v46, v46, v47
	s_cselect_b64 s[26:27], -1, 0
	s_addc_u32 s25, s25, 0
	s_cmp_eq_u32 s25, vcc_hi
	v_add_f32_e32 v32, v32, v46
	s_cbranch_scc1 .LBB0_408
; %bb.405:                              ;   in Loop: Header=BB0_396 Depth=3
	ds_bpermute_b32 v46, v49, v32
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_407
; %bb.406:                              ;   in Loop: Header=BB0_396 Depth=3
	s_lshl2_add_u32 s44, vcc_hi, s75
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_407:                              ; %Flow498
                                        ;   in Loop: Header=BB0_396 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v32, 0
	s_mov_b32 vcc_hi, s25
.LBB0_408:                              ;   in Loop: Header=BB0_396 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s70, 0, s70
	v_lshl_or_b32 v46, s70, 10, v37
	ds_read_b128 v[118:121], v46
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v73, 0xffff0000, v14
	v_lshlrev_b32_e32 v72, 16, v14
	v_and_b32_e32 v47, 0xffff0000, v15
	v_lshlrev_b32_e32 v46, 16, v15
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[72:73], v[118:119], v[72:73]
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v72, v72, v73
	s_add_i32 s70, s70, 1
	v_add_f32_e32 v46, v72, v46
	s_cmp_eq_u32 s70, vcc_lo
	v_add_f32_e32 v46, v46, v47
	s_cselect_b64 s[26:27], -1, 0
	s_addc_u32 s25, s25, 0
	s_cmp_eq_u32 s25, vcc_hi
	v_add_f32_e32 v32, v32, v46
	s_cbranch_scc1 .LBB0_411
; %bb.409:                              ;   in Loop: Header=BB0_396 Depth=3
	ds_bpermute_b32 v46, v49, v32
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_394
; %bb.410:                              ;   in Loop: Header=BB0_396 Depth=3
	s_lshl2_add_u32 s44, vcc_hi, s75
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
	s_branch .LBB0_394
.LBB0_411:                              ;   in Loop: Header=BB0_396 Depth=3
	s_mov_b32 s74, vcc_hi
	s_branch .LBB0_395
.LBB0_412:                              ;   in Loop: Header=BB0_388 Depth=2
	s_mov_b32 s76, s63
	v_mov_b64_e32 v[10:11], v[90:91]
	v_mov_b64_e32 v[12:13], v[92:93]
	v_mov_b64_e32 v[14:15], v[94:95]
	v_mov_b64_e32 v[16:17], v[96:97]
	s_mov_b32 s74, vcc_hi
.LBB0_413:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_ge_i32 s76, s96
	s_cbranch_scc1 .LBB0_442
; %bb.414:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshlrev_b32_e32 v32, 3, v36
	s_ashr_i32 s77, s76, 31
	v_lshl_add_u64 v[46:47], s[8:9], 0, v[32:33]
	s_lshl_b64 s[8:9], s[76:77], 9
	v_lshl_add_u64 v[10:11], v[46:47], 0, s[8:9]
	global_load_dwordx2 v[10:11], v[10:11], off nt
	s_add_i32 s8, s76, 1
	s_cmp_lt_i32 s8, s96
	s_cselect_b64 s[26:27], -1, 0
	s_cmp_ge_i32 s8, s96
	s_cbranch_scc1 .LBB0_416
; %bb.415:                              ;   in Loop: Header=BB0_388 Depth=2
	s_ashr_i32 s9, s8, 31
	s_lshl_b64 s[8:9], s[8:9], 9
	v_lshl_add_u64 v[12:13], v[46:47], 0, s[8:9]
	global_load_dwordx2 v[12:13], v[12:13], off nt
.LBB0_416:                              ;   in Loop: Header=BB0_388 Depth=2
	s_add_i32 s8, s76, 2
	s_cmp_lt_i32 s8, s96
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_ge_i32 s8, s96
	s_cbranch_scc1 .LBB0_418
; %bb.417:                              ;   in Loop: Header=BB0_388 Depth=2
	s_ashr_i32 s9, s8, 31
	s_lshl_b64 s[8:9], s[8:9], 9
	v_lshl_add_u64 v[14:15], v[46:47], 0, s[8:9]
	global_load_dwordx2 v[14:15], v[14:15], off nt
.LBB0_418:                              ;   in Loop: Header=BB0_388 Depth=2
	s_add_i32 s76, s76, 3
	s_cmp_lt_i32 s76, s96
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_ge_i32 s76, s96
	s_cbranch_scc1 .LBB0_420
; %bb.419:                              ;   in Loop: Header=BB0_388 Depth=2
	s_ashr_i32 s77, s76, 31
	s_lshl_b64 s[44:45], s[76:77], 9
	v_lshl_add_u64 v[16:17], v[46:47], 0, s[44:45]
	global_load_dwordx2 v[16:17], v[16:17], off nt
.LBB0_420:                              ;   in Loop: Header=BB0_388 Depth=2
	s_mul_i32 s44, s62, s83
	s_lshl2_add_u32 s70, s44, s87
	s_cmp_eq_u32 vcc_hi, s74
	s_cbranch_scc1 .LBB0_424
; %bb.421:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v32, v49, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v72, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_423
; %bb.422:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s44, s74, s70
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_423:                              ; %Flow493
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v72, 0
	s_mov_b32 s74, vcc_hi
.LBB0_424:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshl_or_b32 v32, s99, 10, v37
	ds_read_b128 v[118:121], v32
	s_add_i32 s99, s99, 1
	s_cmp_eq_u32 s99, vcc_lo
	s_cselect_b64 s[44:45], -1, 0
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v123, 0xffff0000, v10
	v_lshlrev_b32_e32 v122, 16, v10
	s_and_b64 s[76:77], s[44:45], exec
	v_and_b32_e32 v47, 0xffff0000, v11
	v_lshlrev_b32_e32 v46, 16, v11
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[118:119], v[118:119], v[122:123]
	s_cselect_b32 s71, 0, s99
	s_cmp_lg_u64 s[44:45], 0
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v32, v118, v119
	s_addc_u32 s75, vcc_hi, 0
	v_add_f32_e32 v32, v32, v46
	s_and_b64 s[26:27], s[26:27], exec
	v_add_f32_e32 v32, v32, v47
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	v_add_f32_e32 v72, v72, v32
	s_cbranch_scc1 .LBB0_436
; %bb.425:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_eq_u32 s75, s74
	s_cbranch_scc1 .LBB0_429
; %bb.426:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v32, v49, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v72, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_428
; %bb.427:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s44, s74, s70
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s44
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_428:                              ; %Flow490
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v72, 0
	s_mov_b32 s74, s75
.LBB0_429:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshl_or_b32 v32, s71, 10, v37
	ds_read_b128 v[118:121], v32
	v_and_b32_e32 v123, 0xffff0000, v12
	v_lshlrev_b32_e32 v122, 16, v12
	s_add_i32 s71, s71, 1
	v_and_b32_e32 v47, 0xffff0000, v13
	v_lshlrev_b32_e32 v46, 16, v13
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[118:119], v[118:119], v[122:123]
	s_cmp_eq_u32 s71, vcc_lo
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v32, v118, v119
	s_cselect_b64 s[26:27], -1, 0
	v_add_f32_e32 v32, v32, v46
	s_and_b64 s[44:45], s[26:27], exec
	v_add_f32_e32 v32, v32, v47
	s_cselect_b32 s71, 0, s71
	s_cmp_lg_u64 s[26:27], 0
	v_add_f32_e32 v72, v72, v32
	s_addc_u32 s75, s75, 0
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	s_cbranch_scc0 .LBB0_437
.LBB0_430:                              ;   in Loop: Header=BB0_388 Depth=2
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_cbranch_scc1 .LBB0_442
.LBB0_431:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_eq_u32 s75, s74
	s_cbranch_scc1 .LBB0_435
; %bb.432:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v32, v49, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v72, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_434
; %bb.433:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s24, s74, s70
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s24
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_434:                              ; %Flow484
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
	v_mov_b32_e32 v72, 0
	s_mov_b32 s74, s75
.LBB0_435:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshl_or_b32 v32, s71, 10, v37
	ds_read_b128 v[118:121], v32
	v_and_b32_e32 v123, 0xffff0000, v16
	v_lshlrev_b32_e32 v122, 16, v16
	v_and_b32_e32 v47, 0xffff0000, v17
	v_lshlrev_b32_e32 v46, 16, v17
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[118:119], v[118:119], v[122:123]
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v32, v118, v119
	v_add_f32_e32 v32, v32, v46
	v_add_f32_e32 v32, v32, v47
	v_add_f32_e32 v72, v72, v32
	s_cmp_ge_i32 s63, s96
	s_cbranch_scc0 .LBB0_443
	s_branch .LBB0_446
.LBB0_436:                              ;   in Loop: Header=BB0_388 Depth=2
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	s_cbranch_scc1 .LBB0_430
.LBB0_437:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_eq_u32 s75, s74
	s_cbranch_scc1 .LBB0_441
; %bb.438:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v32, v49, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v72, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_440
; %bb.439:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s26, s74, s70
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s26
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_440:                              ; %Flow487
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v72, 0
	s_mov_b32 s74, s75
.LBB0_441:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshl_or_b32 v32, s71, 10, v37
	ds_read_b128 v[118:121], v32
	v_and_b32_e32 v123, 0xffff0000, v14
	v_lshlrev_b32_e32 v122, 16, v14
	s_add_i32 s71, s71, 1
	v_and_b32_e32 v47, 0xffff0000, v15
	v_lshlrev_b32_e32 v46, 16, v15
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[118:119], v[118:119], v[122:123]
	s_cmp_eq_u32 s71, vcc_lo
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v32, v118, v119
	s_cselect_b64 s[24:25], -1, 0
	v_add_f32_e32 v32, v32, v46
	s_and_b64 s[26:27], s[24:25], exec
	v_add_f32_e32 v32, v32, v47
	s_cselect_b32 s71, 0, s71
	s_cmp_lg_u64 s[24:25], 0
	v_add_f32_e32 v72, v72, v32
	s_addc_u32 s75, s75, 0
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_cbranch_scc0 .LBB0_431
.LBB0_442:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_ge_i32 s63, s96
	s_cbranch_scc1 .LBB0_446
.LBB0_443:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v32, v49, v72
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v72, v32
	ds_swizzle_b32 v46, v32 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, 0
	s_nop 0
	v_add_f32_dpp v32, v32, v32 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v32, v32, v32 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v46, v32 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_445
; %bb.444:                              ;   in Loop: Header=BB0_388 Depth=2
	s_mul_i32 s62, s62, s83
	s_lshl2_add_u32 s24, s62, s87
	s_lshl2_add_u32 s24, s74, s24
	v_add_f32_e32 v32, v32, v46
	v_mov_b32_e32 v46, s24
	ds_read_b32 v47, v46
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v32, v32, v47
	ds_write_b32 v46, v32
.LBB0_445:                              ; %Flow483
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
.LBB0_446:                              ;   in Loop: Header=BB0_388 Depth=2
	v_cmp_gt_i32_e32 vcc, s83, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_456
; %bb.447:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s62, s67, s53
	s_lshl_b32 s63, s83, 2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v32, v35
	v_mov_b32_e32 v46, v0
	s_branch .LBB0_449
.LBB0_448:                              ;   in Loop: Header=BB0_449 Depth=3
	v_bfe_u32 v72, v47, 16, 1
	v_add3_u32 v72, v72, v47, s97
	v_or_b32_e32 v73, 0x400000, v47
	v_cmp_u_f32_e32 vcc, v47, v47
	v_add_u32_e32 v32, s95, v32
	s_nop 0
	v_cndmask_b32_e32 v47, v72, v73, vcc
	v_lshl_add_u32 v72, v46, 2, s62
	v_add_u32_e32 v46, s88, v46
	v_cmp_le_i32_e32 vcc, s83, v46
	v_and_b32_e32 v47, 0xffff0000, v47
	s_or_b64 s[24:25], vcc, s[24:25]
	ds_write_b32 v72, v47
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execz .LBB0_456
.LBB0_449:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_451 Depth 4
                                        ;         Child Loop BB0_455 Depth 4
	s_and_b64 s[26:27], s[64:65], exec
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	s_cbranch_scc1 .LBB0_453
; %bb.450:                              ; %.preheader32
                                        ;   in Loop: Header=BB0_449 Depth=3
	v_lshl_add_u32 v72, v46, 2, s87
	s_mov_b32 s26, 0
	v_mov_b32_e32 v47, 0
.LBB0_451:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ;       Parent Loop BB0_449 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	s_mul_i32 s27, s26, s83
	v_lshl_add_u32 v73, s27, 2, v72
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	s_add_i32 s26, s26, 8
	s_cmp_lg_u32 s26, s93
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v118
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v118
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v118
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v118
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v118
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v118
	ds_read_b32 v118, v73
	v_add_u32_e32 v73, s63, v73
	ds_read_b32 v73, v73
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v47, v47, v118
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v73
	s_cbranch_scc1 .LBB0_451
; %bb.452:                              ;   in Loop: Header=BB0_449 Depth=3
	s_mov_b32 s70, s93
	s_mov_b64 s[26:27], s[16:17]
	s_and_b64 vcc, exec, s[26:27]
	s_cbranch_vccz .LBB0_448
	s_branch .LBB0_454
.LBB0_453:                              ;   in Loop: Header=BB0_449 Depth=3
	s_mov_b32 s70, 0
	v_mov_b32_e32 v47, 0
	s_cbranch_execz .LBB0_448
.LBB0_454:                              ;   in Loop: Header=BB0_449 Depth=3
	s_mul_i32 s26, s63, s70
	v_add_u32_e32 v72, s26, v32
	s_mov_b32 s26, s92
.LBB0_455:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ;       Parent Loop BB0_449 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ds_read_b32 v73, v72
	s_add_i32 s26, s26, -1
	v_add_u32_e32 v72, s63, v72
	s_cmp_lg_u32 s26, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v47, v47, v73
	s_cbranch_scc1 .LBB0_455
	s_branch .LBB0_448
.LBB0_456:                              ; %Flow482
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_mov_b64 s[8:9], 0
.LBB0_457:                              ; %Flow532
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccz .LBB0_387
; %bb.458:                              ;   in Loop: Header=BB0_388 Depth=2
	s_sub_i32 s62, s82, s67
	s_mul_i32 s27, s62, s89
	v_readfirstlane_b32 s26, v0
	v_cmp_gt_i32_e32 vcc, s27, v0
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_461
; %bb.459:                              ; %.preheader45
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v10, v35
	v_mov_b32_e32 v11, v0
.LBB0_460:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s27, v11
	ds_write_b32 v10, v33
	s_or_b64 s[24:25], vcc, s[24:25]
	v_add_u32_e32 v10, s95, v10
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execnz .LBB0_460
.LBB0_461:                              ; %Flow530
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_lshr_b32 s8, s79, 23
	s_add_i32 s8, s85, s8
	s_ashr_i32 s96, s8, 9
	s_mul_i32 s8, s62, s96
	s_add_i32 s9, s90, s8
	s_ashr_i32 s24, s9, 31
	s_abs_i32 s9, s9
	s_mul_hi_u32 s25, s9, s91
	s_lshr_b32 s63, s26, 6
	s_mul_i32 s26, s25, s89
	s_sub_i32 s9, s9, s26
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s9, s89
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s9, s27, s9
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s9, s89
	s_cselect_b32 s9, s26, s25
	s_xor_b32 s9, s9, s24
	s_sub_i32 s9, s9, s24
	s_mul_i32 s82, s63, s9
	s_add_i32 s9, s82, s9
	s_min_i32 s83, s8, s9
	s_mul_hi_i32 s9, s67, s85
	s_mul_i32 s8, s67, s85
	s_lshl_b64 s[8:9], s[8:9], 1
	s_add_u32 s8, s3, s8
	s_addc_u32 s9, s52, s9
	s_abs_i32 s24, s96
	v_cvt_f32_u32_e32 v10, s24
	s_sub_i32 s27, 0, s24
	s_abs_i32 s26, s82
	s_xor_b32 s25, s82, s96
	v_rcp_f32_e32 v10, v10
	s_ashr_i32 s25, s25, 31
	v_mov_b32_e32 v16, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_barrier
	v_readfirstlane_b32 s44, v10
	s_mul_i32 s27, s27, s44
	s_mul_hi_u32 s27, s44, s27
	s_add_i32 s44, s44, s27
	s_mul_hi_u32 s27, s26, s44
	s_mul_i32 s44, s27, s24
	s_sub_i32 s26, s26, s44
	s_add_i32 s44, s27, 1
	s_sub_i32 s45, s26, s24
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s27, s44, s27
	s_cselect_b32 s26, s45, s26
	s_add_i32 s44, s27, 1
	s_cmp_ge_u32 s26, s24
	s_cselect_b32 s24, s44, s27
	s_xor_b32 s24, s24, s25
	s_sub_i32 s75, s24, s25
	s_mul_i32 s24, s75, s96
	s_sub_i32 s76, s82, s24
	s_add_i32 s24, s82, 2
	s_cmp_le_i32 s24, s83
	s_cbranch_scc0 .LBB0_473
; %bb.462:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshlrev_b32_e32 v32, 4, v36
	s_mul_i32 s24, s63, s62
	v_lshl_add_u64 v[14:15], s[8:9], 0, v[32:33]
	s_lshl2_add_u32 s70, s24, s87
	v_mov_b32_e32 v16, 0
	s_mov_b32 s24, s82
	s_mov_b32 s74, s75
	s_branch .LBB0_465
.LBB0_463:                              ; %Flow522
                                        ;   in Loop: Header=BB0_465 Depth=3
	s_or_b64 exec, exec, s[76:77]
	v_mov_b32_e32 v10, 0
	s_mov_b32 s74, s25
.LBB0_464:                              ;   in Loop: Header=BB0_465 Depth=3
	s_and_b64 s[26:27], s[26:27], exec
	s_cselect_b32 s26, 0, s71
	v_lshl_or_b32 v11, s26, 11, v50
	ds_read_b128 v[118:121], v11
	ds_read_b128 v[122:125], v11 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v73, 0xffff0000, v22
	v_lshlrev_b32_e32 v72, 16, v22
	v_and_b32_e32 v47, 0xffff0000, v23
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[72:73], v[118:119], v[72:73]
	v_lshlrev_b32_e32 v46, 16, v23
	v_add_f32_e32 v11, 0, v72
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v11, v11, v73
	v_and_b32_e32 v17, 0xffff0000, v24
	v_lshlrev_b32_e32 v16, 16, v24
	v_add_f32_e32 v11, v11, v46
	s_add_i32 s44, s26, 1
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[16:17], v[122:123], v[16:17]
	v_add_f32_e32 v11, v11, v47
	s_cmp_eq_u32 s44, s96
	v_and_b32_e32 v13, 0xffff0000, v25
	v_lshlrev_b32_e32 v12, 16, v25
	v_add_f32_e32 v11, v11, v16
	s_cselect_b64 s[26:27], -1, 0
	v_pk_mul_f32 v[12:13], v[124:125], v[12:13]
	v_add_f32_e32 v11, v11, v17
	s_and_b64 s[76:77], s[26:27], exec
	v_add_f32_e32 v11, v11, v12
	s_cselect_b32 s76, 0, s44
	s_cmp_lg_u64 s[26:27], 0
	v_add_f32_e32 v11, v11, v13
	s_addc_u32 s75, s25, 0
	s_add_i32 s26, s24, 2
	s_add_i32 s24, s24, 4
	v_add_f32_e32 v16, v10, v11
	s_cmp_le_i32 s24, s83
	s_mov_b32 s24, s26
	s_cbranch_scc0 .LBB0_474
.LBB0_465:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[26:27], s[24:25], 10
	v_lshl_add_u64 v[10:11], v[14:15], 0, s[26:27]
	s_add_i32 s26, s24, 1
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 10
	v_lshl_add_u64 v[22:23], v[14:15], 0, s[26:27]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_nop 0
	global_load_dwordx4 v[22:25], v[22:23], off nt
	s_cmp_eq_u32 s75, s74
	s_cbranch_scc1 .LBB0_469
; %bb.466:                              ;   in Loop: Header=BB0_465 Depth=3
	ds_bpermute_b32 v17, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_468
; %bb.467:                              ;   in Loop: Header=BB0_465 Depth=3
	s_lshl2_add_u32 s25, s74, s70
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, s25
	ds_read_b32 v32, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v32
	ds_write_b32 v17, v16
.LBB0_468:                              ; %Flow523
                                        ;   in Loop: Header=BB0_465 Depth=3
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v16, 0
.LBB0_469:                              ;   in Loop: Header=BB0_465 Depth=3
	v_lshl_or_b32 v17, s76, 11, v50
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v47, 0xffff0000, v13
	v_lshlrev_b32_e32 v46, 16, v13
	v_and_b32_e32 v73, 0xffff0000, v12
	v_lshlrev_b32_e32 v72, 16, v12
	v_and_b32_e32 v123, 0xffff0000, v11
	v_lshlrev_b32_e32 v122, 16, v11
	v_and_b32_e32 v125, 0xffff0000, v10
	v_lshlrev_b32_e32 v124, 16, v10
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[118:121], v17 offset:16
	s_add_i32 s71, s76, 1
	s_cmp_eq_u32 s71, s96
	s_cselect_b64 s[26:27], -1, 0
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[124:125]
	v_pk_mul_f32 v[12:13], v[12:13], v[122:123]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[72:73], v[118:119], v[72:73]
	v_add_f32_e32 v10, v10, v13
	v_add_f32_e32 v10, v10, v72
	v_pk_mul_f32 v[46:47], v[120:121], v[46:47]
	v_add_f32_e32 v10, v10, v73
	v_add_f32_e32 v10, v10, v46
	v_add_f32_e32 v10, v10, v47
	s_addc_u32 s25, s75, 0
	v_add_f32_e32 v10, v16, v10
	s_cmp_lg_u32 s71, s96
	s_cbranch_scc1 .LBB0_472
; %bb.470:                              ;   in Loop: Header=BB0_465 Depth=3
	ds_bpermute_b32 v11, v49, v10
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[76:77], s[4:5]
	s_cbranch_execz .LBB0_463
; %bb.471:                              ;   in Loop: Header=BB0_465 Depth=3
	s_lshl2_add_u32 s44, s75, s70
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s44
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
	s_branch .LBB0_463
.LBB0_472:                              ;   in Loop: Header=BB0_465 Depth=3
	s_mov_b32 s74, s75
	s_branch .LBB0_464
.LBB0_473:                              ;   in Loop: Header=BB0_388 Depth=2
	s_mov_b32 s26, s82
	s_mov_b32 s74, s75
.LBB0_474:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_ge_i32 s26, s83
	s_cbranch_scc1 .LBB0_487
; %bb.475:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshlrev_b32_e32 v32, 4, v36
	s_ashr_i32 s27, s26, 31
	v_lshl_add_u64 v[14:15], s[8:9], 0, v[32:33]
	s_lshl_b64 s[8:9], s[26:27], 10
	v_lshl_add_u64 v[10:11], v[14:15], 0, s[8:9]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_add_i32 s24, s26, 1
	s_cmp_lt_i32 s24, s83
	s_cselect_b64 s[8:9], -1, 0
	s_cmp_ge_i32 s24, s83
	s_cbranch_scc1 .LBB0_477
; %bb.476:                              ;   in Loop: Header=BB0_388 Depth=2
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[24:25], s[24:25], 10
	v_lshl_add_u64 v[14:15], v[14:15], 0, s[24:25]
	global_load_dwordx4 v[22:25], v[14:15], off nt
.LBB0_477:                              ;   in Loop: Header=BB0_388 Depth=2
	s_mul_i32 s24, s63, s62
	s_lshl2_add_u32 s26, s24, s87
	s_cmp_eq_u32 s75, s74
	s_cbranch_scc1 .LBB0_481
; %bb.478:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v14, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v16, v14
	ds_swizzle_b32 v15, v14 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v14, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v14, v14, v14 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v14, v14, v14 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v14, v14, v14 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v14 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_480
; %bb.479:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s27, s74, s26
	v_add_f32_e32 v14, v14, v15
	v_mov_b32_e32 v15, s27
	ds_read_b32 v16, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v14, v16
	ds_write_b32 v15, v14
.LBB0_480:                              ; %Flow519
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v16, 0
	s_mov_b32 s74, s75
.LBB0_481:                              ;   in Loop: Header=BB0_388 Depth=2
	v_lshl_or_b32 v17, s76, 11, v50
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v15, 0xffff0000, v13
	v_lshlrev_b32_e32 v14, 16, v13
	v_and_b32_e32 v47, 0xffff0000, v12
	v_lshlrev_b32_e32 v46, 16, v12
	v_and_b32_e32 v73, 0xffff0000, v11
	v_lshlrev_b32_e32 v72, 16, v11
	v_and_b32_e32 v123, 0xffff0000, v10
	v_lshlrev_b32_e32 v122, 16, v10
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[118:121], v17 offset:16
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 1, 0
	s_cmp_lg_u32 s8, 1
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[122:123]
	v_pk_mul_f32 v[12:13], v[12:13], v[72:73]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[118:119], v[46:47]
	v_add_f32_e32 v10, v10, v13
	v_add_f32_e32 v10, v10, v46
	v_pk_mul_f32 v[14:15], v[120:121], v[14:15]
	v_add_f32_e32 v10, v10, v47
	v_add_f32_e32 v10, v10, v14
	v_add_f32_e32 v10, v10, v15
	v_add_f32_e32 v16, v16, v10
	s_cbranch_scc1 .LBB0_487
; %bb.482:                              ;   in Loop: Header=BB0_388 Depth=2
	s_add_i32 s76, s76, 1
	s_cmp_eq_u32 s76, s96
	s_cselect_b64 s[8:9], -1, 0
	s_addc_u32 s27, s75, 0
	s_cmp_eq_u32 s27, s74
	s_cbranch_scc1 .LBB0_486
; %bb.483:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v10, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v16, v10
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_485
; %bb.484:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s26, s74, s26
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s26
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
.LBB0_485:                              ; %Flow516
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v16, 0
	s_mov_b32 s74, s27
.LBB0_486:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl_b32 s24, s76, 11
	s_and_b64 s[8:9], s[8:9], exec
	s_cselect_b32 s8, 0, s24
	v_or_b32_e32 v17, s8, v50
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[118:121], v17 offset:16
	v_and_b32_e32 v123, 0xffff0000, v22
	v_lshlrev_b32_e32 v122, 16, v22
	v_and_b32_e32 v73, 0xffff0000, v23
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[122:123]
	v_lshlrev_b32_e32 v72, 16, v23
	v_add_f32_e32 v10, 0, v10
	v_pk_mul_f32 v[12:13], v[12:13], v[72:73]
	v_add_f32_e32 v10, v10, v11
	v_and_b32_e32 v47, 0xffff0000, v24
	v_lshlrev_b32_e32 v46, 16, v24
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[46:47], v[118:119], v[46:47]
	v_add_f32_e32 v10, v10, v13
	v_and_b32_e32 v15, 0xffff0000, v25
	v_lshlrev_b32_e32 v14, 16, v25
	v_add_f32_e32 v10, v10, v46
	v_pk_mul_f32 v[14:15], v[120:121], v[14:15]
	v_add_f32_e32 v10, v10, v47
	v_add_f32_e32 v10, v10, v14
	v_add_f32_e32 v10, v10, v15
	v_add_f32_e32 v16, v16, v10
.LBB0_487:                              ;   in Loop: Header=BB0_388 Depth=2
	s_cmp_ge_i32 s82, s83
	s_cbranch_scc1 .LBB0_491
; %bb.488:                              ;   in Loop: Header=BB0_388 Depth=2
	ds_bpermute_b32 v10, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v16, v10
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_490
; %bb.489:                              ;   in Loop: Header=BB0_388 Depth=2
	s_mul_i32 s63, s63, s62
	s_lshl2_add_u32 s24, s63, s87
	s_lshl2_add_u32 s24, s74, s24
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s24
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
.LBB0_490:                              ; %Flow515
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
.LBB0_491:                              ;   in Loop: Header=BB0_388 Depth=2
	v_cmp_gt_i32_e32 vcc, s62, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB0_501
; %bb.492:                              ;   in Loop: Header=BB0_388 Depth=2
	s_lshl2_add_u32 s63, s67, s53
	s_lshl_b32 s67, s62, 2
	s_mov_b64 s[24:25], 0
	v_mov_b32_e32 v10, v35
	v_mov_b32_e32 v11, v0
	s_branch .LBB0_494
.LBB0_493:                              ;   in Loop: Header=BB0_494 Depth=3
	v_bfe_u32 v13, v12, 16, 1
	v_add3_u32 v13, v13, v12, s97
	v_or_b32_e32 v14, 0x400000, v12
	v_cmp_u_f32_e32 vcc, v12, v12
	v_add_u32_e32 v10, s95, v10
	s_nop 0
	v_cndmask_b32_e32 v12, v13, v14, vcc
	v_lshl_add_u32 v13, v11, 2, s63
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s62, v11
	v_and_b32_e32 v12, 0xffff0000, v12
	s_or_b64 s[24:25], vcc, s[24:25]
	ds_write_b32 v13, v12
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execz .LBB0_501
.LBB0_494:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_496 Depth 4
                                        ;         Child Loop BB0_500 Depth 4
	s_and_b64 s[26:27], s[64:65], exec
	s_cselect_b32 s26, 1, 0
	s_cmp_lg_u32 s26, 1
	s_cbranch_scc1 .LBB0_498
; %bb.495:                              ; %.preheader
                                        ;   in Loop: Header=BB0_494 Depth=3
	v_lshl_add_u32 v13, v11, 2, s87
	s_mov_b32 s26, 0
	v_mov_b32_e32 v12, 0
.LBB0_496:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ;       Parent Loop BB0_494 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	s_mul_i32 s27, s26, s62
	v_lshl_add_u32 v14, s27, 2, v13
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	s_add_i32 s26, s26, 8
	s_cmp_lg_u32 s26, s93
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s67, v14
	ds_read_b32 v14, v14
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v12, v12, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v14
	s_cbranch_scc1 .LBB0_496
; %bb.497:                              ;   in Loop: Header=BB0_494 Depth=3
	s_mov_b32 s70, s93
	s_mov_b64 s[26:27], s[16:17]
	s_and_b64 vcc, exec, s[26:27]
	s_cbranch_vccz .LBB0_493
	s_branch .LBB0_499
.LBB0_498:                              ;   in Loop: Header=BB0_494 Depth=3
	s_mov_b32 s70, 0
	v_mov_b32_e32 v12, 0
	s_cbranch_execz .LBB0_493
.LBB0_499:                              ;   in Loop: Header=BB0_494 Depth=3
	s_mul_i32 s26, s67, s70
	v_add_u32_e32 v13, s26, v10
	s_mov_b32 s26, s92
.LBB0_500:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_388 Depth=2
                                        ;       Parent Loop BB0_494 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	ds_read_b32 v14, v13
	s_add_i32 s26, s26, -1
	v_add_u32_e32 v13, s67, v13
	s_cmp_lg_u32 s26, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v14
	s_cbranch_scc1 .LBB0_500
	s_branch .LBB0_493
.LBB0_501:                              ; %Flow514
                                        ;   in Loop: Header=BB0_388 Depth=2
	s_or_b64 exec, exec, s[8:9]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cmp_lt_i32 s66, s41
	s_mov_b32 s67, s66
	s_cbranch_scc1 .LBB0_388
.LBB0_502:                              ; %Flow535
                                        ;   in Loop: Header=BB0_9 Depth=1
.LBB0_503:                              ;   in Loop: Header=BB0_9 Depth=1
	v_mov_b64_e32 v[2:3], v[90:91]
	v_mov_b64_e32 v[4:5], v[92:93]
	v_mov_b64_e32 v[6:7], v[94:95]
	v_mov_b64_e32 v[8:9], v[96:97]
	v_mov_b64_e32 v[100:101], v[24:25]
	v_mov_b64_e32 v[98:99], v[22:23]
	v_mov_b64_e32 v[106:107], v[116:117]
	v_mov_b64_e32 v[108:109], v[114:115]
	v_mov_b64_e32 v[110:111], v[112:113]
	v_mov_b64_e32 v[104:105], v[20:21]
	v_mov_b64_e32 v[102:103], v[18:19]
	v_add_u32_e32 v10, s86, v0
	v_cmp_gt_i32_e32 vcc, s41, v10
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execnz .LBB0_550
	s_branch .LBB0_552
.LBB0_504:                              ;   in Loop: Header=BB0_9 Depth=1
	v_cvt_f32_u32_e32 v10, s8
	s_sub_i32 s9, 0, s8
	s_ashr_i32 s3, s2, 31
	s_abs_i32 s2, s2
	v_rcp_f32_e32 v10, v10
	s_nop 0
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_nop 0
	v_readfirstlane_b32 s24, v10
	s_mul_i32 s9, s9, s24
	s_mul_hi_u32 s9, s24, s9
	s_add_i32 s24, s24, s9
	s_mul_hi_u32 s9, s2, s24
	s_mul_i32 s9, s9, s8
	s_sub_i32 s2, s2, s9
	s_sub_i32 s9, s2, s8
	s_cmp_ge_u32 s2, s8
	s_cselect_b32 s2, s9, s2
	s_sub_i32 s9, s2, s8
	s_cmp_ge_u32 s2, s8
	s_cselect_b32 s2, s9, s2
	s_xor_b32 s2, s2, s3
	s_sub_i32 s2, s2, s3
	s_cmp_lg_u32 s2, 0
	s_mov_b64 s[8:9], -1
	s_cselect_b64 s[24:25], -1, 0
	s_and_b64 vcc, exec, s[24:25]
                                        ; implicit-def: $vgpr90_vgpr91_vgpr92_vgpr93_vgpr94_vgpr95_vgpr96_vgpr97
                                        ; implicit-def: $vgpr22_vgpr23_vgpr24_vgpr25
                                        ; implicit-def: $vgpr116_vgpr117
                                        ; implicit-def: $vgpr114_vgpr115
                                        ; implicit-def: $vgpr112_vgpr113
                                        ; implicit-def: $vgpr18_vgpr19_vgpr20_vgpr21
                                        ; implicit-def: $sgpr2
	s_cbranch_vccnz .LBB0_270
.LBB0_505:                              ; %Flow623
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_and_b64 vcc, exec, s[8:9]
	s_cbranch_vccz .LBB0_503
; %bb.506:                              ;   in Loop: Header=BB0_9 Depth=1
	v_readlane_b32 s2, v126, 15
	s_add_i32 s2, s2, s86
	s_sub_i32 s2, s2, s86
	s_mul_i32 s24, s2, s89
	v_readfirstlane_b32 s3, v0
	v_cmp_gt_i32_e32 vcc, s24, v0
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_509
; %bb.507:                              ; %.preheader72
                                        ;   in Loop: Header=BB0_9 Depth=1
	v_readlane_b32 s8, v126, 14
	s_lshl2_add_u32 s8, s85, s8
	v_mov_b32_e32 v11, v0
	v_add_u32_e32 v10, s8, v48
	s_mov_b64 s[8:9], 0
.LBB0_508:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v11, s88, v11
	v_cmp_le_i32_e32 vcc, s24, v11
	ds_write_b32 v10, v33
	s_or_b64 s[8:9], vcc, s[8:9]
	v_add_u32_e32 v10, s95, v10
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB0_508
.LBB0_509:                              ; %Flow615
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_sub_i32 s6, s84, s78
	s_mul_i32 s8, s6, s85
	s_mul_hi_i32 s9, s6, s85
	s_lshr_b32 s6, s79, 23
	s_add_i32 s6, s85, s6
	s_ashr_i32 s62, s6, 9
	s_mul_i32 s6, s2, s62
	s_add_i32 s7, s90, s6
	s_ashr_i32 s24, s7, 31
	s_abs_i32 s7, s7
	s_mul_hi_u32 s25, s7, s91
	s_mul_i32 s26, s25, s89
	s_sub_i32 s7, s7, s26
	s_lshr_b32 s3, s3, 6
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s7, s89
	s_cmp_ge_u32 s7, s89
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s7, s27, s7
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s7, s89
	s_cselect_b32 s7, s26, s25
	s_xor_b32 s7, s7, s24
	s_sub_i32 s7, s7, s24
	s_mul_i32 s52, s3, s7
	s_add_i32 s7, s52, s7
	s_min_i32 s53, s6, s7
	s_mul_hi_i32 s7, s86, s85
	s_mul_i32 s6, s86, s85
	s_lshl_b64 s[6:7], s[6:7], 1
	s_add_u32 s24, s80, s6
	s_addc_u32 s25, s81, s7
	s_mul_i32 s6, s62, s78
	s_cmp_ge_i32 s52, s6
	s_cselect_b32 s7, s9, 0
	s_cselect_b32 s6, s8, 0
	s_lshl_b64 s[6:7], s[6:7], 1
	s_add_u32 s6, s24, s6
	s_addc_u32 s7, s25, s7
	s_abs_i32 s8, s62
	v_cvt_f32_u32_e32 v10, s8
	s_sub_i32 s25, 0, s8
	s_abs_i32 s24, s52
	s_xor_b32 s9, s52, s62
	v_rcp_f32_e32 v10, v10
	s_ashr_i32 s9, s9, 31
	v_mov_b32_e32 v16, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v10, 0x4f7ffffe, v10
	v_cvt_u32_f32_e32 v10, v10
	s_barrier
	v_readfirstlane_b32 s26, v10
	s_mul_i32 s25, s25, s26
	s_mul_hi_u32 s25, s26, s25
	s_add_i32 s26, s26, s25
	s_mul_hi_u32 s25, s24, s26
	s_mul_i32 s26, s25, s8
	s_sub_i32 s24, s24, s26
	s_add_i32 s26, s25, 1
	s_sub_i32 s27, s24, s8
	s_cmp_ge_u32 s24, s8
	s_cselect_b32 s25, s26, s25
	s_cselect_b32 s24, s27, s24
	s_add_i32 s26, s25, 1
	s_cmp_ge_u32 s24, s8
	s_cselect_b32 s8, s26, s25
	s_xor_b32 s8, s8, s9
	s_sub_i32 s63, s8, s9
	s_mul_i32 s8, s63, s62
	s_sub_i32 s27, s52, s8
	s_add_i32 s8, s52, 2
	s_cmp_le_i32 s8, s53
	s_cbranch_scc0 .LBB0_521
; %bb.510:                              ;   in Loop: Header=BB0_9 Depth=1
	v_lshlrev_b32_e32 v32, 4, v36
	s_mul_i32 s8, s3, s2
	v_lshl_add_u64 v[14:15], s[6:7], 0, v[32:33]
	s_lshl2_add_u32 s66, s8, s87
	v_mov_b32_e32 v16, 0
	s_mov_b32 s8, s52
	s_mov_b32 s26, s63
	s_branch .LBB0_513
.LBB0_511:                              ; %Flow607
                                        ;   in Loop: Header=BB0_513 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v10, 0
	s_mov_b32 s26, s9
.LBB0_512:                              ;   in Loop: Header=BB0_513 Depth=2
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 0, s67
	v_lshl_or_b32 v11, s24, 11, v50
	ds_read_b128 v[16:19], v11
	ds_read_b128 v[20:23], v11 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v73, 0xffff0000, v28
	v_lshlrev_b32_e32 v72, 16, v28
	v_and_b32_e32 v47, 0xffff0000, v29
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[16:17], v[16:17], v[72:73]
	v_lshlrev_b32_e32 v46, 16, v29
	v_add_f32_e32 v11, 0, v16
	v_pk_mul_f32 v[18:19], v[18:19], v[46:47]
	v_add_f32_e32 v11, v11, v17
	v_and_b32_e32 v25, 0xffff0000, v30
	v_lshlrev_b32_e32 v24, 16, v30
	v_add_f32_e32 v11, v11, v18
	s_add_i32 s27, s24, 1
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[20:21], v[24:25]
	v_add_f32_e32 v11, v11, v19
	s_cmp_eq_u32 s27, s62
	v_and_b32_e32 v13, 0xffff0000, v31
	v_lshlrev_b32_e32 v12, 16, v31
	v_add_f32_e32 v11, v11, v20
	s_cselect_b64 s[24:25], -1, 0
	v_pk_mul_f32 v[12:13], v[22:23], v[12:13]
	v_add_f32_e32 v11, v11, v21
	s_and_b64 s[70:71], s[24:25], exec
	v_add_f32_e32 v11, v11, v12
	s_cselect_b32 s27, 0, s27
	s_cmp_lg_u64 s[24:25], 0
	v_add_f32_e32 v11, v11, v13
	s_addc_u32 s63, s9, 0
	s_add_i32 s24, s8, 2
	s_add_i32 s8, s8, 4
	v_add_f32_e32 v16, v10, v11
	s_cmp_le_i32 s8, s53
	s_mov_b32 s8, s24
	s_cbranch_scc0 .LBB0_522
.LBB0_513:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	s_ashr_i32 s9, s8, 31
	s_lshl_b64 s[24:25], s[8:9], 10
	v_lshl_add_u64 v[10:11], v[14:15], 0, s[24:25]
	s_add_i32 s24, s8, 1
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[24:25], s[24:25], 10
	v_lshl_add_u64 v[18:19], v[14:15], 0, s[24:25]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_nop 0
	global_load_dwordx4 v[28:31], v[18:19], off nt
	s_cmp_eq_u32 s63, s26
	s_cbranch_scc1 .LBB0_517
; %bb.514:                              ;   in Loop: Header=BB0_513 Depth=2
	ds_bpermute_b32 v17, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	ds_swizzle_b32 v17, v16 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, 0
	s_nop 0
	v_add_f32_dpp v16, v16, v16 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v16, v16, v16 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v17, v16 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB0_516
; %bb.515:                              ;   in Loop: Header=BB0_513 Depth=2
	s_lshl2_add_u32 s9, s26, s66
	v_add_f32_e32 v16, v16, v17
	v_mov_b32_e32 v17, s9
	ds_read_b32 v18, v17
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v16, v16, v18
	ds_write_b32 v17, v16
.LBB0_516:                              ; %Flow608
                                        ;   in Loop: Header=BB0_513 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v16, 0
.LBB0_517:                              ;   in Loop: Header=BB0_513 Depth=2
	v_lshl_or_b32 v17, s27, 11, v50
	ds_read_b128 v[18:21], v17
	ds_read_b128 v[22:25], v17 offset:16
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v73, 0xffff0000, v11
	v_lshlrev_b32_e32 v72, 16, v11
	v_and_b32_e32 v11, 0xffff0000, v10
	v_lshlrev_b32_e32 v10, 16, v10
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[18:19], v[10:11]
	v_pk_mul_f32 v[20:21], v[20:21], v[72:73]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_and_b32_e32 v47, 0xffff0000, v13
	v_lshlrev_b32_e32 v46, 16, v13
	v_and_b32_e32 v13, 0xffff0000, v12
	v_lshlrev_b32_e32 v12, 16, v12
	v_add_f32_e32 v10, v10, v20
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[12:13], v[22:23], v[12:13]
	v_add_f32_e32 v10, v10, v21
	v_add_f32_e32 v10, v10, v12
	v_pk_mul_f32 v[24:25], v[24:25], v[46:47]
	v_add_f32_e32 v10, v10, v13
	s_add_i32 s67, s27, 1
	v_add_f32_e32 v10, v10, v24
	s_cmp_eq_u32 s67, s62
	v_add_f32_e32 v10, v10, v25
	s_cselect_b64 s[24:25], -1, 0
	s_addc_u32 s9, s63, 0
	s_cmp_lg_u32 s67, s62
	v_add_f32_e32 v10, v16, v10
	s_cbranch_scc1 .LBB0_520
; %bb.518:                              ;   in Loop: Header=BB0_513 Depth=2
	ds_bpermute_b32 v11, v49, v10
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB0_511
; %bb.519:                              ;   in Loop: Header=BB0_513 Depth=2
	s_lshl2_add_u32 s44, s63, s66
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, s44
	ds_read_b32 v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	ds_write_b32 v11, v10
	s_branch .LBB0_511
.LBB0_520:                              ;   in Loop: Header=BB0_513 Depth=2
	s_mov_b32 s26, s63
	s_branch .LBB0_512
.LBB0_521:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mov_b32 s24, s52
	s_mov_b32 s26, s63
.LBB0_522:                              ;   in Loop: Header=BB0_9 Depth=1
	s_cmp_ge_i32 s24, s53
	s_cbranch_scc1 .LBB0_535
; %bb.523:                              ;   in Loop: Header=BB0_9 Depth=1
	v_lshlrev_b32_e32 v32, 4, v36
	s_ashr_i32 s25, s24, 31
	v_lshl_add_u64 v[14:15], s[6:7], 0, v[32:33]
	s_lshl_b64 s[6:7], s[24:25], 10
	v_lshl_add_u64 v[10:11], v[14:15], 0, s[6:7]
	global_load_dwordx4 v[10:13], v[10:11], off nt
	s_add_i32 s8, s24, 1
	s_cmp_lt_i32 s8, s53
	s_cselect_b64 s[6:7], -1, 0
	s_cmp_ge_i32 s8, s53
	s_cbranch_scc1 .LBB0_525
; %bb.524:                              ;   in Loop: Header=BB0_9 Depth=1
	s_ashr_i32 s9, s8, 31
	s_lshl_b64 s[8:9], s[8:9], 10
	v_lshl_add_u64 v[14:15], v[14:15], 0, s[8:9]
	global_load_dwordx4 v[28:31], v[14:15], off nt
.LBB0_525:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mul_i32 s8, s3, s2
	s_lshl2_add_u32 s24, s8, s87
	s_cmp_eq_u32 s63, s26
	s_cbranch_scc1 .LBB0_529
; %bb.526:                              ;   in Loop: Header=BB0_9 Depth=1
	ds_bpermute_b32 v14, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v16, v14
	ds_swizzle_b32 v15, v14 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v14, v15
	v_mov_b32_e32 v15, v33
	s_nop 0
	v_add_f32_dpp v14, v14, v14 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v14, v14, v14 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v14, v14, v14 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v14 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_528
; %bb.527:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl2_add_u32 s25, s26, s24
	v_mov_b32_e32 v16, s25
	ds_read_b32 v17, v16
	v_add_f32_e32 v14, v14, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v14, v14, v17
	ds_write_b32 v16, v14
.LBB0_528:                              ; %Flow604
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mov_b32_e32 v16, 0
	s_mov_b32 s26, s63
.LBB0_529:                              ;   in Loop: Header=BB0_9 Depth=1
	v_lshl_or_b32 v17, s27, 11, v50
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v23, 0xffff0000, v13
	v_lshlrev_b32_e32 v22, 16, v13
	v_and_b32_e32 v25, 0xffff0000, v12
	v_lshlrev_b32_e32 v24, 16, v12
	ds_read_b128 v[12:15], v17
	ds_read_b128 v[18:21], v17 offset:16
	v_and_b32_e32 v47, 0xffff0000, v11
	v_lshlrev_b32_e32 v46, 16, v11
	v_and_b32_e32 v11, 0xffff0000, v10
	v_lshlrev_b32_e32 v10, 16, v10
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[12:13], v[10:11]
	v_pk_mul_f32 v[14:15], v[14:15], v[46:47]
	v_add_f32_e32 v10, 0, v10
	v_add_f32_e32 v10, v10, v11
	v_add_f32_e32 v10, v10, v14
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[18:19], v[24:25]
	v_add_f32_e32 v10, v10, v15
	v_add_f32_e32 v10, v10, v18
	v_pk_mul_f32 v[20:21], v[20:21], v[22:23]
	v_add_f32_e32 v10, v10, v19
	v_add_f32_e32 v10, v10, v20
	s_and_b64 s[6:7], s[6:7], exec
	v_add_f32_e32 v10, v10, v21
	s_cselect_b32 s6, 1, 0
	s_cmp_lg_u32 s6, 1
	v_add_f32_e32 v16, v16, v10
	s_cbranch_scc1 .LBB0_535
; %bb.530:                              ;   in Loop: Header=BB0_9 Depth=1
	s_add_i32 s27, s27, 1
	s_cmp_eq_u32 s27, s62
	s_cselect_b64 s[6:7], -1, 0
	s_addc_u32 s25, s63, 0
	s_cmp_eq_u32 s25, s26
	s_cbranch_scc1 .LBB0_534
; %bb.531:                              ;   in Loop: Header=BB0_9 Depth=1
	ds_bpermute_b32 v10, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v16, v10
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, v33
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[4:5]
	s_cbranch_execz .LBB0_533
; %bb.532:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl2_add_u32 s24, s26, s24
	v_mov_b32_e32 v12, s24
	ds_read_b32 v13, v12
	v_add_f32_e32 v10, v10, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v13
	ds_write_b32 v12, v10
.LBB0_533:                              ; %Flow601
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mov_b32_e32 v16, 0
	s_mov_b32 s26, s25
.LBB0_534:                              ;   in Loop: Header=BB0_9 Depth=1
	s_lshl_b32 s8, s27, 11
	s_and_b64 s[6:7], s[6:7], exec
	s_cselect_b32 s6, 0, s8
	v_or_b32_e32 v17, s6, v50
	ds_read_b128 v[10:13], v17
	ds_read_b128 v[18:21], v17 offset:16
	v_and_b32_e32 v47, 0xffff0000, v28
	v_lshlrev_b32_e32 v46, 16, v28
	v_and_b32_e32 v25, 0xffff0000, v29
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[10:11], v[10:11], v[46:47]
	v_lshlrev_b32_e32 v24, 16, v29
	v_add_f32_e32 v10, 0, v10
	v_pk_mul_f32 v[12:13], v[12:13], v[24:25]
	v_add_f32_e32 v10, v10, v11
	v_and_b32_e32 v23, 0xffff0000, v30
	v_lshlrev_b32_e32 v22, 16, v30
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[18:19], v[22:23]
	v_add_f32_e32 v10, v10, v13
	v_and_b32_e32 v15, 0xffff0000, v31
	v_lshlrev_b32_e32 v14, 16, v31
	v_add_f32_e32 v10, v10, v18
	v_pk_mul_f32 v[14:15], v[20:21], v[14:15]
	v_add_f32_e32 v10, v10, v19
	v_add_f32_e32 v10, v10, v14
	v_add_f32_e32 v10, v10, v15
	v_add_f32_e32 v16, v16, v10
.LBB0_535:                              ;   in Loop: Header=BB0_9 Depth=1
	s_cmp_ge_i32 s52, s53
	s_cbranch_scc1 .LBB0_539
; %bb.536:                              ;   in Loop: Header=BB0_9 Depth=1
	ds_bpermute_b32 v10, v49, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v16, v10
	ds_swizzle_b32 v11, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	v_mov_b32_e32 v11, v33
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[4:5]
	s_cbranch_execz .LBB0_538
; %bb.537:                              ;   in Loop: Header=BB0_9 Depth=1
	s_mul_i32 s3, s3, s2
	s_lshl2_add_u32 s3, s3, s87
	s_lshl2_add_u32 s3, s26, s3
	v_mov_b32_e32 v12, s3
	ds_read_b32 v13, v12
	v_add_f32_e32 v10, v10, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v13
	ds_write_b32 v12, v10
.LBB0_538:                              ; %Flow600
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
.LBB0_539:                              ;   in Loop: Header=BB0_9 Depth=1
	v_cmp_gt_i32_e32 vcc, s2, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_549
; %bb.540:                              ;   in Loop: Header=BB0_9 Depth=1
	v_readlane_b32 s8, v126, 14
	s_lshl2_add_u32 s8, s85, s8
	s_sub_i32 s3, s40, s78
	s_lshl_b32 s26, s2, 2
	v_add_u32_e32 v10, s8, v48
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v11, v0
	s_branch .LBB0_542
.LBB0_541:                              ;   in Loop: Header=BB0_542 Depth=2
	v_add_u32_e32 v13, s86, v11
	v_mov_b32_e32 v15, s3
	v_cmp_le_i32_e32 vcc, s41, v13
	v_subrev_u32_e32 v14, s86, v13
	v_or_b32_e32 v16, 0x400000, v12
	v_cndmask_b32_e32 v13, 0, v15, vcc
	v_bfe_u32 v15, v12, 16, 1
	v_add3_u32 v15, v15, v12, s97
	v_cmp_u_f32_e32 vcc, v12, v12
	v_add_u32_e32 v11, s88, v11
	v_lshlrev_b32_e32 v14, 2, v14
	v_cndmask_b32_e32 v12, v15, v16, vcc
	v_lshlrev_b32_e32 v13, 2, v13
	v_cmp_le_i32_e32 vcc, s2, v11
	v_and_b32_e32 v12, 0xffff0000, v12
	v_add3_u32 v13, s43, v14, v13
	s_or_b64 s[8:9], vcc, s[8:9]
	v_add_u32_e32 v10, s95, v10
	ds_write_b32 v13, v12
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB0_549
.LBB0_542:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_544 Depth 3
                                        ;       Child Loop BB0_548 Depth 3
	v_readlane_b32 s24, v126, 8
	v_readlane_b32 s25, v126, 9
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	s_cbranch_scc1 .LBB0_546
; %bb.543:                              ; %.preheader42
                                        ;   in Loop: Header=BB0_542 Depth=2
	v_lshl_add_u32 v13, v11, 2, s87
	s_mov_b32 s24, 0
	v_mov_b32_e32 v12, 0
.LBB0_544:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_542 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s25, s24, s2
	v_lshl_add_u32 v14, s25, 2, v13
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s26, v14
	v_add_u32_e32 v16, s26, v14
	ds_read_b32 v14, v14
	ds_read_b32 v17, v16
	v_add_u32_e32 v16, s26, v16
	v_add_u32_e32 v18, s26, v16
	ds_read_b32 v16, v16
	ds_read_b32 v19, v18
	v_add_u32_e32 v18, s26, v18
	v_add_u32_e32 v20, s26, v18
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v12, v12, v15
	ds_read_b32 v18, v18
	ds_read_b32 v21, v20
	v_add_u32_e32 v15, s26, v20
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v12, v12, v14
	ds_read_b32 v14, v15
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v12, v12, v17
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v12, v12, v16
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v12, v12, v19
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v12, v12, v18
	s_add_i32 s24, s24, 8
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v12, v12, v21
	s_cmp_lg_u32 s24, s93
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v14
	s_cbranch_scc1 .LBB0_544
; %bb.545:                              ;   in Loop: Header=BB0_542 Depth=2
	s_mov_b32 s27, s93
	s_mov_b64 s[24:25], s[16:17]
	s_and_b64 vcc, exec, s[24:25]
	s_cbranch_vccz .LBB0_541
	s_branch .LBB0_547
.LBB0_546:                              ;   in Loop: Header=BB0_542 Depth=2
	s_mov_b32 s27, 0
	v_mov_b32_e32 v12, 0
	s_cbranch_execz .LBB0_541
.LBB0_547:                              ;   in Loop: Header=BB0_542 Depth=2
	s_mul_i32 s24, s26, s27
	v_add_u32_e32 v13, s24, v10
	s_mov_b32 s24, s92
.LBB0_548:                              ;   Parent Loop BB0_9 Depth=1
                                        ;     Parent Loop BB0_542 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v14, v13
	s_add_i32 s24, s24, -1
	v_add_u32_e32 v13, s26, v13
	s_cmp_lg_u32 s24, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v12, v14
	s_cbranch_scc1 .LBB0_548
	s_branch .LBB0_541
.LBB0_549:                              ; %Flow599
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_ashr_i32 s2, s84, 31
	v_add_u32_e32 v10, s86, v0
	v_cmp_gt_i32_e32 vcc, s41, v10
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB0_552
.LBB0_550:                              ;   in Loop: Header=BB0_9 Depth=1
	s_ashr_i32 s3, s42, 31
	s_mul_hi_u32 s8, s84, s42
	s_mul_i32 s3, s84, s3
	s_add_i32 s3, s8, s3
	s_mul_i32 s2, s2, s42
	s_add_i32 s3, s3, s2
	s_mul_i32 s2, s84, s42
	s_lshl_b64 s[2:3], s[2:3], 1
	v_readlane_b32 s8, v126, 12
	v_readlane_b32 s9, v126, 13
	s_add_u32 s8, s8, s2
	s_addc_u32 s9, s9, s3
	s_lshl_b32 s2, s40, 2
	v_lshl_add_u32 v12, s85, 2, v48
	s_mov_b64 s[24:25], 0
.LBB0_551:                              ;   Parent Loop BB0_9 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ds_read_b32 v13, v12
	v_ashrrev_i32_e32 v11, 31, v10
	v_add_u32_e32 v16, s2, v12
	v_lshl_add_u64 v[14:15], v[10:11], 1, s[8:9]
	ds_read_b32 v11, v16
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v16, 0xbfb8aa3b, v13
	v_exp_f32_e32 v16, v16
	v_add_u32_e32 v10, s88, v10
	v_cmp_le_i32_e32 vcc, s41, v10
	s_or_b64 s[24:25], vcc, s[24:25]
	v_add_f32_e32 v16, 1.0, v16
	v_div_scale_f32 v17, s[26:27], v16, v16, v13
	v_rcp_f32_e32 v19, v17
	v_div_scale_f32 v18, vcc, v13, v16, v13
	v_add_u32_e32 v12, s95, v12
	v_fma_f32 v20, -v17, v19, 1.0
	v_fmac_f32_e32 v19, v20, v19
	v_mul_f32_e32 v20, v18, v19
	v_fma_f32 v21, -v17, v20, v18
	v_fmac_f32_e32 v20, v21, v19
	v_fma_f32 v17, -v17, v20, v18
	v_div_fmas_f32 v17, v17, v19, v20
	v_div_fixup_f32 v13, v17, v16, v13
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v11, v11, v13
	v_bfe_u32 v13, v11, 16, 1
	v_or_b32_e32 v16, 0x400000, v11
	v_add3_u32 v13, v13, v11, s97
	v_cmp_u_f32_e32 vcc, v11, v11
	s_nop 1
	v_cndmask_b32_e32 v11, v13, v16, vcc
	v_lshrrev_b32_e32 v11, 16, v11
	global_store_short v[14:15], v11, off sc0 sc1
	s_andn2_b64 exec, exec, s[24:25]
	s_cbranch_execnz .LBB0_551
.LBB0_552:                              ; %Flow474
                                        ;   in Loop: Header=BB0_9 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_and_saveexec_b64 s[6:7], s[60:61]
	s_cbranch_execnz .LBB0_230
	s_branch .LBB0_231
.LBB0_553:
	s_endpgm
.Lfunc_end0:
	.size	etx_megakernel_d0, .Lfunc_end0-etx_megakernel_d0
	.cfi_endproc
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel etx_megakernel_d0
		.amdhsa_group_segment_fixed_size 21148
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 608
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 127
		.amdhsa_next_free_sgpr 100
		.amdhsa_accum_offset 128
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
                                        ; -- End function
	.set .Letx_megakernel_d0.num_vgpr, 127
	.set .Letx_megakernel_d0.num_agpr, 0
	.set .Letx_megakernel_d0.numbered_sgpr, 100
	.set .Letx_megakernel_d0.num_named_barrier, 0
	.set .Letx_megakernel_d0.private_seg_size, 0
	.set .Letx_megakernel_d0.uses_vcc, 1
	.set .Letx_megakernel_d0.uses_flat_scratch, 0
	.set .Letx_megakernel_d0.has_dyn_sized_stack, 0
	.set .Letx_megakernel_d0.has_recursion, 0
	.set .Letx_megakernel_d0.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 29696
; TotalNumSgprs: 106
; NumVgprs: 127
; NumAgprs: 0
; TotalNumVgprs: 127
; ScratchSize: 0
; MemoryBound: 1
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 21148 bytes/workgroup (compile time only)
; SGPRBlocks: 13
; VGPRBlocks: 15
; NumSGPRsForWavesPerEU: 106
; NumVGPRsForWavesPerEU: 127
; AccumOffset: 128
; Occupancy: 4
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 31
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.protected	etx_unfused_d0          ; -- Begin function etx_unfused_d0
	.globl	etx_unfused_d0
	.p2align	8
	.type	etx_unfused_d0,@function
etx_unfused_d0:                         ; @etx_unfused_d0
	.cfi_startproc
; %bb.0:
	.cfi_escape 0x0f, 0x04, 0x30, 0x36, 0xe9, 0x02 ; CFA is 0 in private_wave aspace
	.cfi_undefined 16
	s_load_dword s3, s[0:1], 0x160
	s_load_dwordx2 s[4:5], s[0:1], 0x38
	s_waitcnt lgkmcnt(0)
	s_add_i32 s2, s3, s2
	s_mul_hi_i32 s3, s2, 20
	s_mul_i32 s2, s2, 20
	s_add_u32 s2, s4, s2
	s_addc_u32 s3, s5, s3
	s_load_dwordx2 s[6:7], s[2:3], 0x0
	s_getreg_b32 s2, hwreg(HW_REG_XCC_ID, 0, 4)
	s_waitcnt lgkmcnt(0)
	s_cmp_lt_i32 s6, 1
	s_cbranch_scc1 .LBB1_3
; %bb.1:                                ; %LeafBlock675
	s_cmp_eq_u32 s6, 1
	s_cbranch_scc0 .LBB1_4
; %bb.2:
	s_movk_i32 s35, 0xa0
	s_mov_b32 s30, 1
	s_branch .LBB1_5
.LBB1_3:
	s_mov_b64 s[4:5], -1
                                        ; implicit-def: $sgpr30
                                        ; implicit-def: $sgpr35
	s_branch .LBB1_6
.LBB1_4:
	s_mov_b32 s35, 0
	s_mov_b32 s30, -1
.LBB1_5:                                ; %Flow892
	s_mov_b64 s[4:5], 0
.LBB1_6:                                ; %Flow892
	s_load_dwordx2 s[2:3], s[0:1], 0x10
	s_and_b64 s[4:5], s[4:5], exec
	s_cselect_b32 s4, 1, 0
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc1 .LBB1_9
; %bb.7:                                ; %LeafBlock
	s_mov_b32 s30, -1
	s_cmp_lg_u32 s6, 0
	s_mov_b32 s35, 0
	s_cbranch_scc1 .LBB1_9
; %bb.8:
	s_mov_b32 s30, 0
.LBB1_9:
	s_load_dword s4, s[0:1], 0x18
	s_waitcnt lgkmcnt(0)
	s_mul_i32 s4, s6, s4
	s_ashr_i32 s5, s4, 31
	s_lshl_b64 s[4:5], s[4:5], 3
	s_add_u32 s16, s2, s4
	s_addc_u32 s17, s3, s5
	s_cmp_gt_i32 s30, 0
	s_mov_b64 s[2:3], -1
	s_cbranch_scc0 .LBB1_167
; %bb.10:
	s_load_dwordx2 s[2:3], s[16:17], 0x0
	s_ashr_i32 s26, s35, 31
	s_waitcnt lgkmcnt(0)
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s26
	s_load_dword s4, s[4:5], 0x9c
	s_waitcnt lgkmcnt(0)
	s_cmp_ge_i32 s7, s4
	s_cbranch_scc1 .LBB1_166
; %bb.11:
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s26
	s_load_dwordx2 s[8:9], s[4:5], 0x38
	s_load_dword s36, s[4:5], 0x30
	s_abs_i32 s4, s7
	s_waitcnt lgkmcnt(0)
	s_abs_i32 s6, s9
	v_cvt_f32_u32_e32 v1, s6
	s_sub_i32 s10, 0, s6
	s_xor_b32 s5, s7, s9
	s_ashr_i32 s5, s5, 31
	v_rcp_f32_e32 v1, v1
	s_nop 0
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_nop 0
	v_readfirstlane_b32 s11, v1
	s_mul_i32 s10, s10, s11
	s_mul_hi_u32 s10, s11, s10
	s_add_i32 s11, s11, s10
	s_mul_hi_u32 s10, s4, s11
	s_mul_i32 s11, s10, s6
	s_sub_i32 s4, s4, s11
	s_add_i32 s12, s10, 1
	s_sub_i32 s11, s4, s6
	s_cmp_ge_u32 s4, s6
	s_cselect_b32 s10, s12, s10
	s_cselect_b32 s4, s11, s4
	s_add_i32 s11, s10, 1
	s_cmp_ge_u32 s4, s6
	s_cselect_b32 s4, s11, s10
	s_xor_b32 s4, s4, s5
	s_sub_i32 s18, s4, s5
	s_mul_i32 s4, s18, s9
	s_sub_i32 s4, s7, s4
	s_mul_i32 s33, s4, s8
	s_add_i32 s4, s33, s8
	s_min_i32 s6, s36, s4
	s_cmp_ge_i32 s33, s6
	s_cbranch_scc1 .LBB1_166
; %bb.12:
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s26
	s_load_dword s37, s[4:5], 0x68
	s_load_dwordx4 s[12:15], s[4:5], 0x20
	s_load_dword s31, s[4:5], 0x34
	s_load_dwordx4 s[8:11], s[4:5], 0x0
	s_load_dwordx2 s[20:21], s[4:5], 0x10
	s_waitcnt lgkmcnt(0)
	s_cmp_lt_i32 s37, 2
	s_cselect_b64 s[22:23], -1, 0
	s_and_b64 vcc, exec, s[22:23]
	s_cbranch_vccz .LBB1_14
; %bb.13:
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s26
	s_load_dwordx2 s[4:5], s[4:5], 0x18
	s_ashr_i32 s19, s18, 31
	s_lshl_b64 s[24:25], s[18:19], 2
	v_mov_b32_e32 v1, 0
	s_waitcnt lgkmcnt(0)
	s_add_u32 s4, s4, s24
	s_addc_u32 s5, s5, s25
	global_load_dword v1, v1, s[4:5] sc0 sc1
	s_mov_b64 s[4:5], 0
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s24, v1
	s_branch .LBB1_15
.LBB1_14:
	s_mov_b64 s[4:5], -1
                                        ; implicit-def: $sgpr24
.LBB1_15:                               ; %Flow734
	s_lshl_b32 s34, s31, 2
	s_and_b64 s[4:5], s[4:5], exec
	s_cselect_b32 s4, 1, 0
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc1 .LBB1_43
; %bb.16:
	v_cmp_gt_u32_e32 vcc, 64, v0
	s_and_saveexec_b64 s[24:25], vcc
	s_cbranch_execz .LBB1_42
; %bb.17:
	s_add_u32 s2, s2, s35
	s_addc_u32 s3, s3, s26
	s_load_dword s28, s[2:3], 0x6c
	s_load_dword s19, s[2:3], 0x60
	s_load_dwordx2 s[26:27], s[2:3], 0x70
	v_mov_b32_e32 v2, 0xff800000
	v_mov_b32_e32 v1, v2
	s_waitcnt lgkmcnt(0)
	v_cmp_gt_i32_e64 s[2:3], s28, v0
	s_and_saveexec_b64 s[4:5], s[2:3]
	s_cbranch_execz .LBB1_19
; %bb.18:
	v_lshlrev_b32_e32 v1, 1, v0
	global_load_ushort v1, v1, s[26:27] sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v1, 16, v1
.LBB1_19:
	s_or_b64 exec, exec, s[4:5]
	v_or_b32_e32 v3, 64, v0
	v_cmp_gt_i32_e64 s[4:5], s28, v3
	s_and_saveexec_b64 s[28:29], s[4:5]
	s_cbranch_execz .LBB1_21
; %bb.20:
	v_lshlrev_b32_e32 v2, 1, v0
	global_load_ushort v2, v2, s[26:27] offset:128 sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v2, 16, v2
.LBB1_21:
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v6, 0
	v_mov_b32_e32 v7, v6
	s_and_saveexec_b64 s[26:27], s[2:3]
	s_xor_b64 s[26:27], exec, s[26:27]
	s_cbranch_execz .LBB1_23
; %bb.22:
	v_bfe_u32 v4, v1, 16, 15
	s_mov_b32 s28, 0x8000
	v_sub_u32_e32 v4, 0x8000, v4
	v_or_b32_sdwa v5, v1, s28 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v1
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_mov_b32_e32 v5, 0x800000
	v_lshl_or_b32 v4, v4, 7, v5
	v_cmp_o_f32_e32 vcc, v1, v1
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_or_b32_e32 v4, v4, v0
	v_xor_b32_e32 v7, 0x7f, v4
.LBB1_23:
	s_or_b64 exec, exec, s[26:27]
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB1_25
; %bb.24:
	v_bfe_u32 v4, v2, 16, 15
	s_mov_b32 s28, 0x8000
	v_sub_u32_e32 v4, 0x8000, v4
	v_or_b32_sdwa v5, v2, s28 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v2
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_mov_b32_e32 v5, 0x800000
	v_lshl_or_b32 v4, v4, 7, v5
	v_cmp_o_f32_e32 vcc, v2, v2
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_or_b32_e32 v3, v4, v3
	v_xor_b32_e32 v6, 0x7f, v3
.LBB1_25:
	s_or_b64 exec, exec, s[26:27]
	v_max_u32_e32 v3, v7, v6
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s28, v3, 63
	s_lshr_b32 s26, s28, 7
	s_bfe_u32 s27, s28, 0x100007
	s_add_i32 s29, s26, 0xffff8000
	s_sub_i32 s26, 0x8000, s26
	s_bitset1_b32 s26, 15
	s_cmpk_gt_u32 s27, 0x7fff
	s_cselect_b32 s26, s29, s26
	s_lshl_b32 s26, s26, 16
	s_cmp_lg_u32 s27, 0
	v_mov_b32_e32 v3, 0x7fc00000
	v_mov_b32_e32 v4, s26
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v5, v3, v4, vcc
	v_mov_b32_e32 v3, 0
	v_mov_b32_e32 v4, v3
	s_and_saveexec_b64 s[26:27], s[2:3]
	s_cbranch_execz .LBB1_27
; %bb.26:
	v_sub_f32_e32 v1, v1, v5
	s_mov_b32 s29, 0x3fb8aa3b
	v_mul_f32_e32 v4, 0x3fb8aa3b, v1
	v_fma_f32 v8, v1, s29, -v4
	v_rndne_f32_e32 v9, v4
	v_fmamk_f32 v8, v1, 0x32a5705f, v8
	v_sub_f32_e32 v4, v4, v9
	v_add_f32_e32 v4, v4, v8
	v_exp_f32_e32 v4, v4
	v_cvt_i32_f32_e32 v8, v9
	s_mov_b32 s29, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s29, v1
	s_mov_b32 s29, 0x42b17218
	v_ldexp_f32 v4, v4, v8
	v_cndmask_b32_e32 v4, 0, v4, vcc
	v_mov_b32_e32 v8, 0x7f800000
	v_cmp_nlt_f32_e32 vcc, s29, v1
	s_nop 1
	v_cndmask_b32_e32 v4, v8, v4, vcc
.LBB1_27:
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v1, 0
	s_and_saveexec_b64 s[26:27], s[4:5]
	s_cbranch_execz .LBB1_29
; %bb.28:
	v_sub_f32_e32 v2, v2, v5
	s_mov_b32 s29, 0x3fb8aa3b
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_fma_f32 v5, v2, s29, -v3
	v_rndne_f32_e32 v8, v3
	v_fmamk_f32 v5, v2, 0x32a5705f, v5
	v_sub_f32_e32 v3, v3, v8
	v_add_f32_e32 v3, v3, v5
	v_exp_f32_e32 v3, v3
	v_cvt_i32_f32_e32 v5, v8
	s_mov_b32 s29, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s29, v2
	s_mov_b32 s29, 0x42b17218
	v_ldexp_f32 v3, v3, v5
	v_cndmask_b32_e32 v3, 0, v3, vcc
	v_mov_b32_e32 v5, 0x7f800000
	v_cmp_nlt_f32_e32 vcc, s29, v2
	s_nop 1
	v_cndmask_b32_e32 v3, v5, v3, vcc
.LBB1_29:
	s_or_b64 exec, exec, s[26:27]
	v_mbcnt_lo_u32_b32 v5, -1, 0
	v_mbcnt_hi_u32_b32 v5, -1, v5
	v_and_b32_e32 v8, 64, v5
	v_add_u32_e32 v8, 64, v8
	v_xor_b32_e32 v9, 32, v5
	v_cmp_lt_u32_e32 vcc, v9, v8
	v_add_f32_e32 v2, v4, v3
	v_xor_b32_e32 v10, 16, v5
	v_cndmask_b32_e32 v9, v5, v9, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_cmp_lt_i32 s19, 1
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 8, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 4, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 2, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 1, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v5, v5, v10, vcc
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v5, v5, v2
	s_cbranch_scc1 .LBB1_35
; %bb.30:
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v1, v2, v5
	v_div_scale_f32 v2, s[26:27], v1, v1, 1.0
	v_rcp_f32_e32 v5, v2
	v_div_scale_f32 v8, vcc, 1.0, v1, 1.0
	v_fma_f32 v9, -v2, v5, 1.0
	v_fmac_f32_e32 v5, v9, v5
	v_mul_f32_e32 v9, v8, v5
	v_fma_f32 v10, -v2, v9, v8
	v_fmac_f32_e32 v9, v10, v5
	v_fma_f32 v2, -v2, v9, v8
	v_div_fmas_f32 v2, v2, v5, v9
	v_div_fixup_f32 v1, v2, v1, 1.0
	v_mul_f32_e32 v2, v1, v4
	v_cndmask_b32_e64 v2, 0, v2, s[2:3]
	s_andn2_b32 s2, 0x7f, s28
	s_cmp_lg_u32 s28, 0
	s_cselect_b32 s2, s2, 0
	v_mul_f32_e32 v1, v1, v3
	s_cmp_gt_u32 s2, 63
	v_cndmask_b32_e64 v3, 0, v1, s[4:5]
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v1, v2, v3, vcc
	v_cmp_eq_u32_e32 vcc, 0, v0
	v_readlane_b32 s3, v1, s2
	s_cmp_eq_u32 s19, 1
	s_nop 0
	v_mov_b32_e32 v1, s3
	v_cndmask_b32_e32 v5, 0, v1, vcc
	v_mov_b32_e32 v1, s2
	v_cndmask_b32_e32 v4, 0, v1, vcc
	v_add_f32_e64 v1, s3, 0
	s_cbranch_scc1 .LBB1_40
; %bb.31:
	v_cmp_ne_u32_e32 vcc, s28, v7
	s_add_i32 s3, s19, -1
	s_add_i32 s5, s19, -2
	v_cndmask_b32_e32 v7, 0, v7, vcc
	s_and_b32 s4, s3, 3
	v_cmp_ne_u32_e32 vcc, s28, v6
	s_mov_b32 s2, 0
	s_cmp_lt_u32 s5, 3
	v_cndmask_b32_e32 v6, 0, v6, vcc
	s_cbranch_scc1 .LBB1_36
; %bb.32:
	s_and_b32 s3, s3, -4
	v_add_u32_e32 v8, -4, v0
	v_add_u32_e32 v9, -3, v0
	v_add_u32_e32 v10, -2, v0
	v_add_u32_e32 v11, -1, v0
.LBB1_33:                               ; =>This Inner Loop Header: Depth=1
	v_max_u32_e32 v12, v7, v6
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s26, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s26, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	v_max_u32_e32 v12, v7, v6
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v2, v3, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v13, s5
	v_readlane_b32 s5, v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s2, v11
	v_mov_b32_e32 v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v14, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v4, v4, v13, vcc
	s_nop 0
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s26, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s26, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	v_max_u32_e32 v12, v7, v6
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v2, v3, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v13, s5
	v_readlane_b32 s5, v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s2, v10
	v_mov_b32_e32 v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v14, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v4, v4, v13, vcc
	s_nop 0
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s26, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s26, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	v_max_u32_e32 v12, v7, v6
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v2, v3, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v13, s5
	v_readlane_b32 s5, v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s2, v9
	v_mov_b32_e32 v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v14, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v4, v4, v13, vcc
	s_nop 0
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s26, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s26, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v13, v2, v3, vcc
	v_mov_b32_e32 v12, s5
	v_readlane_b32 s5, v13, s5
	v_cmp_eq_u32_e32 vcc, s2, v8
	s_add_i32 s2, s2, 4
	v_mov_b32_e32 v13, s5
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v13, vcc
	s_cmp_eq_u32 s3, s2
	v_cndmask_b32_e32 v4, v4, v12, vcc
	s_cbranch_scc0 .LBB1_33
; %bb.34:
	s_add_i32 s5, s2, 1
	s_cmp_lg_u32 s4, 0
	s_cselect_b64 s[2:3], -1, 0
	s_branch .LBB1_37
.LBB1_35:
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v5, 0
	s_branch .LBB1_40
.LBB1_36:
	s_mov_b64 s[2:3], -1
	s_mov_b32 s5, 1
.LBB1_37:                               ; %Flow729
	s_and_b64 vcc, exec, s[2:3]
	s_cbranch_vccz .LBB1_40
; %bb.38:
	v_subrev_u32_e32 v8, s5, v0
.LBB1_39:                               ; =>This Inner Loop Header: Depth=1
	v_max_u32_e32 v9, v7, v6
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s2, v9, 63
	s_andn2_b32 s3, 0x7f, s2
	s_cmp_lg_u32 s2, 0
	v_cmp_ne_u32_e32 vcc, s2, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s2, v7
	s_cselect_b32 s2, s3, 0
	s_cmp_gt_u32 s2, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v10, v2, v3, vcc
	v_mov_b32_e32 v9, s2
	v_readlane_b32 s2, v10, s2
	s_add_i32 s4, s4, -1
	v_subrev_co_u32_e32 v8, vcc, 1, v8
	v_mov_b32_e32 v10, s2
	s_cmp_lg_u32 s4, 0
	v_add_f32_e32 v1, s2, v1
	v_cndmask_b32_e32 v5, v5, v10, vcc
	v_cndmask_b32_e32 v4, v4, v9, vcc
	s_cbranch_scc1 .LBB1_39
.LBB1_40:
	v_cmp_gt_i32_e32 vcc, s19, v0
	s_and_b64 exec, exec, vcc
	s_cbranch_execz .LBB1_42
; %bb.41:
	v_div_scale_f32 v2, s[2:3], v1, v1, v5
	v_rcp_f32_e32 v3, v2
	v_div_scale_f32 v6, vcc, v5, v1, v5
	s_cmp_eq_u32 s37, 3
	v_fma_f32 v7, -v2, v3, 1.0
	v_fmac_f32_e32 v3, v7, v3
	v_mul_f32_e32 v7, v6, v3
	v_fma_f32 v8, -v2, v7, v6
	v_fmac_f32_e32 v7, v8, v3
	v_fma_f32 v2, -v2, v7, v6
	v_div_fmas_f32 v2, v2, v3, v7
	v_div_fixup_f32 v1, v2, v1, v5
	s_cselect_b64 vcc, -1, 0
	v_lshl_add_u32 v2, v0, 2, s34
	v_cndmask_b32_e32 v1, v5, v1, vcc
	v_add_u32_e32 v2, 0x1000, v2
	ds_write2_b32 v2, v4, v1 offset1:16
.LBB1_42:                               ; %Flow733
	s_or_b64 exec, exec, s[24:25]
	s_lshl2_add_u32 s2, s18, s34
	v_mov_b32_e32 v1, s2
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b32 v1, v1 offset:4096
	s_ashr_i32 s19, s18, 31
	s_waitcnt lgkmcnt(0)
	v_readfirstlane_b32 s24, v1
.LBB1_43:
	s_ashr_i32 s28, s31, 31
	s_lshr_b32 s2, s28, 29
	s_add_i32 s2, s31, s2
	s_ashr_i32 s25, s2, 3
	v_cmp_gt_i32_e32 vcc, s25, v0
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB1_46
; %bb.44:
	s_load_dword s4, s[0:1], 0x174
	s_mul_hi_u32 s5, s18, s31
	s_mul_i32 s26, s18, s28
	s_add_i32 s5, s5, s26
	v_mov_b32_e32 v1, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s26, s4, 0xffff
	s_mul_i32 s4, s19, s31
	s_add_i32 s5, s5, s4
	s_mul_i32 s4, s18, s31
	s_lshl_b32 s27, s26, 5
	s_lshl_b64 s[4:5], s[4:5], 1
	s_add_u32 s4, s10, s4
	s_addc_u32 s5, s11, s5
	v_lshl_add_u64 v[2:3], v[0:1], 4, s[4:5]
	v_lshlrev_b32_e32 v4, 5, v0
	v_lshl_add_u64 v[2:3], v[2:3], 0, 8
	s_lshl_b32 s4, s26, 4
	s_mov_b32 s5, 0
	s_mov_b64 s[10:11], 0
	v_mov_b32_e32 v1, v0
.LBB1_45:                               ; =>This Inner Loop Header: Depth=1
	global_load_dwordx2 v[10:11], v[2:3], off offset:-8 sc0 sc1
	global_load_dwordx2 v[14:15], v[2:3], off sc0 sc1
	v_add_u32_e32 v1, s26, v1
	v_cmp_le_i32_e32 vcc, s25, v1
	v_lshl_add_u64 v[2:3], v[2:3], 0, s[4:5]
	s_or_b64 s[10:11], vcc, s[10:11]
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v7, 0xffff0000, v10
	v_lshlrev_b32_e32 v6, 16, v10
	v_and_b32_e32 v9, 0xffff0000, v11
	v_lshlrev_b32_e32 v8, 16, v11
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v11, 0xffff0000, v14
	v_lshlrev_b32_e32 v10, 16, v14
	v_and_b32_e32 v13, 0xffff0000, v15
	v_lshlrev_b32_e32 v12, 16, v15
	ds_write_b128 v4, v[6:9]
	ds_write_b128 v4, v[10:13] offset:16
	v_add_u32_e32 v4, s27, v4
	s_andn2_b64 exec, exec, s[10:11]
	s_cbranch_execnz .LBB1_45
.LBB1_46:                               ; %Flow724
	s_or_b64 exec, exec, s[2:3]
	s_and_b64 vcc, exec, s[22:23]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cbranch_vccz .LBB1_48
; %bb.47:
	s_lshl_b64 s[2:3], s[18:19], 2
	s_add_u32 s2, s12, s2
	s_addc_u32 s3, s13, s3
	v_mov_b32_e32 v1, 0
	global_load_dword v1, v1, s[2:3] sc0 sc1
	s_mov_b64 s[2:3], 0
	s_and_b64 s[2:3], s[2:3], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_cbranch_scc0 .LBB1_49
	s_branch .LBB1_50
.LBB1_48:
	s_mov_b64 s[2:3], -1
                                        ; implicit-def: $vgpr1
	s_and_b64 s[2:3], s[2:3], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_cbranch_scc1 .LBB1_50
.LBB1_49:
	s_lshl2_add_u32 s2, s18, s34
	s_waitcnt vmcnt(0)
	v_mov_b32_e32 v1, s2
	ds_read_b32 v1, v1 offset:4160
.LBB1_50:
	s_ashr_i32 s2, s36, 31
	s_mul_hi_u32 s3, s18, s36
	s_mul_i32 s2, s18, s2
	s_add_i32 s2, s3, s2
	s_mul_i32 s3, s19, s36
	s_add_i32 s3, s2, s3
	s_mul_i32 s2, s18, s36
	s_lshl_b64 s[2:3], s[2:3], 1
	s_add_u32 s4, s20, s2
	s_addc_u32 s5, s21, s3
	s_ashr_i32 s2, s24, 31
	s_mul_hi_u32 s3, s14, s24
	s_mul_i32 s2, s14, s2
	s_add_i32 s2, s3, s2
	s_mul_i32 s3, s15, s24
	s_add_i32 s3, s2, s3
	s_mul_i32 s2, s14, s24
	s_load_dword s12, s[0:1], 0x174
	s_lshl_b64 s[2:3], s[2:3], 1
	s_add_u32 s29, s8, s2
	s_addc_u32 s36, s9, s3
	s_and_b32 s2, s31, 0x1ff
	s_cselect_b64 s[8:9], -1, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s37, s12, 0xffff
	v_lshlrev_b32_e32 v4, 2, v0
	s_cmpk_gt_u32 s37, 0x1ff
	v_and_b32_e32 v6, 0xfc, v4
	s_cselect_b64 s[10:11], -1, 0
	s_bfe_u32 s38, s12, 0xa0006
	v_xor_b32_e32 v22, 0x80, v6
	v_cvt_f32_u32_e32 v6, s38
	s_add_i32 s39, s38, -1
	s_bfe_u32 s40, s37, 0x30006
	s_and_b32 s41, s38, 0x3f8
	v_rcp_f32_e32 v6, v6
	s_cmp_lg_u32 s40, 0
	s_cselect_b64 s[12:13], -1, 0
	s_cmp_gt_u32 s39, 6
	v_mul_f32_e32 v6, 0x4f7ffffe, v6
	v_cvt_u32_f32_e32 v6, v6
	s_cselect_b64 s[14:15], -1, 0
	s_sub_i32 s18, 0, s38
	v_and_b32_e32 v2, 63, v0
	v_readfirstlane_b32 s19, v6
	s_mul_i32 s18, s18, s19
	s_mul_hi_u32 s18, s19, s18
	s_add_i32 s42, s19, s18
	s_lshr_b32 s18, s28, 24
	s_add_i32 s18, s31, s18
	s_ashr_i32 s43, s18, 8
	s_abs_i32 s44, s43
	v_cvt_f32_u32_e32 v6, s44
	v_mov_b32_e32 v5, 0
	v_lshlrev_b32_e32 v3, 4, v2
	v_lshl_add_u32 v24, s31, 2, v4
	v_rcp_f32_e32 v8, v6
	v_mov_b32_e32 v4, v5
	v_mov_b32_e32 v6, v5
	v_mov_b32_e32 v7, v5
	v_mul_f32_e32 v8, 0x4f7ffffe, v8
	v_cvt_u32_f32_e32 v25, v8
	v_cmp_eq_u32_e64 s[2:3], 0, v2
	v_add_u32_e32 v23, v3, v3
	s_lshl_b32 s45, s37, 2
	s_movk_i32 s46, 0x7fff
	s_sub_i32 s47, 0, s44
	v_lshlrev_b32_e32 v14, 3, v2
	s_waitcnt vmcnt(0)
	v_mov_b64_e32 v[12:13], v[6:7]
	v_mov_b64_e32 v[10:11], v[4:5]
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v27, 0
	v_mov_b32_e32 v28, 0
	v_mov_b32_e32 v29, 0
	v_mov_b32_e32 v30, 0
	v_mov_b32_e32 v31, 0
	v_mov_b64_e32 v[8:9], v[2:3]
	v_mov_b64_e32 v[6:7], v[0:1]
	s_branch .LBB1_52
.LBB1_51:                               ;   in Loop: Header=BB1_52 Depth=1
	v_mov_b32_e32 v31, v9
	v_mov_b32_e32 v30, v8
	v_mov_b32_e32 v29, v17
	v_mov_b32_e32 v28, v16
	v_mov_b32_e32 v27, v7
	v_mov_b32_e32 v26, v6
	s_cmp_lt_i32 s48, s6
	s_mov_b32 s33, s48
	s_cbranch_scc0 .LBB1_166
.LBB1_52:                               ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_124 Depth 2
                                        ;     Child Loop BB1_129 Depth 2
                                        ;     Child Loop BB1_158 Depth 2
                                        ;       Child Loop BB1_160 Depth 3
                                        ;       Child Loop BB1_164 Depth 3
                                        ;     Child Loop BB1_55 Depth 2
                                        ;     Child Loop BB1_60 Depth 2
                                        ;     Child Loop BB1_114 Depth 2
                                        ;       Child Loop BB1_116 Depth 3
                                        ;       Child Loop BB1_120 Depth 3
	s_add_i32 s48, s33, 64
	s_min_i32 s49, s6, s48
	s_and_b64 vcc, exec, s[8:9]
	s_mul_hi_i32 s19, s33, s31
	s_mul_i32 s18, s33, s31
	s_cbranch_vccz .LBB1_76
; %bb.53:                               ;   in Loop: Header=BB1_52 Depth=1
	s_sub_i32 s50, s49, s33
	s_mul_i32 s25, s38, s50
	v_readfirstlane_b32 s24, v0
	v_cmp_gt_i32_e32 vcc, s25, v0
	s_and_saveexec_b64 s[20:21], vcc
	s_cbranch_execz .LBB1_56
; %bb.54:                               ; %.preheader354
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_mov_b64 s[22:23], 0
	v_mov_b32_e32 v4, v24
	v_mov_b32_e32 v6, v0
.LBB1_55:                               ;   Parent Loop BB1_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v6, s37, v6
	v_cmp_le_i32_e32 vcc, s25, v6
	ds_write_b32 v4, v5
	s_or_b64 s[22:23], vcc, s[22:23]
	v_add_u32_e32 v4, s45, v4
	s_andn2_b64 exec, exec, s[22:23]
	s_cbranch_execnz .LBB1_55
.LBB1_56:                               ; %Flow701
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
	s_mul_i32 s20, s50, s43
	s_add_i32 s21, s20, s39
	s_ashr_i32 s22, s21, 31
	s_abs_i32 s21, s21
	s_mul_hi_u32 s23, s21, s42
	s_lshr_b32 s51, s24, 6
	s_mul_i32 s24, s23, s38
	s_sub_i32 s21, s21, s24
	s_add_i32 s24, s23, 1
	s_sub_i32 s25, s21, s38
	s_cmp_ge_u32 s21, s38
	s_cselect_b32 s23, s24, s23
	s_cselect_b32 s21, s25, s21
	s_add_i32 s24, s23, 1
	s_cmp_ge_u32 s21, s38
	s_cselect_b32 s21, s24, s23
	s_xor_b32 s21, s21, s22
	s_sub_i32 s21, s21, s22
	s_mul_i32 s52, s21, s51
	s_add_i32 s21, s52, s21
	v_readfirstlane_b32 s24, v25
	s_min_i32 s53, s20, s21
	s_lshl_b64 s[20:21], s[18:19], 1
	s_mul_i32 s25, s47, s24
	s_add_u32 s20, s29, s20
	s_mul_hi_u32 s25, s24, s25
	s_addc_u32 s21, s36, s21
	s_abs_i32 s23, s52
	s_add_i32 s24, s24, s25
	s_mul_hi_u32 s24, s23, s24
	s_mul_i32 s25, s24, s44
	s_xor_b32 s22, s52, s43
	s_sub_i32 s23, s23, s25
	s_ashr_i32 s22, s22, 31
	s_add_i32 s25, s24, 1
	s_sub_i32 s26, s23, s44
	s_cmp_ge_u32 s23, s44
	s_cselect_b32 s24, s25, s24
	s_cselect_b32 s23, s26, s23
	s_add_i32 s25, s24, 1
	s_cmp_ge_u32 s23, s44
	s_cselect_b32 s23, s25, s24
	s_xor_b32 s23, s23, s22
	s_sub_i32 s55, s23, s22
	s_mul_i32 s22, s55, s43
	s_sub_i32 s56, s52, s22
	s_add_i32 s22, s52, 4
	s_cmp_le_i32 s22, s53
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cbranch_scc0 .LBB1_77
; %bb.57:                               ;   in Loop: Header=BB1_52 Depth=1
	v_mov_b32_e32 v15, v5
	s_mul_i32 s22, s51, s50
	v_lshl_add_u64 v[18:19], s[20:21], 0, v[14:15]
	s_lshl2_add_u32 s57, s22, s34
	v_mov_b32_e32 v4, 0
	s_mov_b32 s22, s52
	s_mov_b32 s54, s55
	s_branch .LBB1_60
.LBB1_58:                               ; %Flow695
                                        ;   in Loop: Header=BB1_60 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s54, s23
.LBB1_59:                               ;   in Loop: Header=BB1_60 Depth=2
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s24, 0, s56
	v_lshl_or_b32 v15, s24, 10, v3
	ds_read_b128 v[32:35], v15
	s_add_i32 s55, s24, 1
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v37, 0xffff0000, v8
	v_lshlrev_b32_e32 v36, 16, v8
	s_cmp_eq_u32 s55, s43
	v_and_b32_e32 v21, 0xffff0000, v9
	v_lshlrev_b32_e32 v20, 16, v9
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[32:33], v[32:33], v[36:37]
	s_cselect_b64 s[24:25], -1, 0
	v_pk_mul_f32 v[20:21], v[34:35], v[20:21]
	v_add_f32_e32 v15, v32, v33
	s_and_b64 s[26:27], s[24:25], exec
	v_add_f32_e32 v15, v15, v20
	s_cselect_b32 s56, 0, s55
	s_cmp_lg_u64 s[24:25], 0
	v_add_f32_e32 v15, v15, v21
	s_addc_u32 s55, s23, 0
	s_add_i32 s26, s22, 4
	s_add_i32 s22, s22, 8
	v_add_f32_e32 v4, v4, v15
	s_cmp_le_i32 s22, s53
	s_mov_b32 s22, s26
	s_cbranch_scc0 .LBB1_78
.LBB1_60:                               ;   Parent Loop BB1_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	s_ashr_i32 s23, s22, 31
	s_lshl_b64 s[24:25], s[22:23], 9
	v_lshl_add_u64 v[6:7], v[18:19], 0, s[24:25]
	s_add_i32 s24, s22, 1
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[24:25], s[24:25], 9
	v_lshl_add_u64 v[8:9], v[18:19], 0, s[24:25]
	s_add_i32 s24, s22, 2
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[24:25], s[24:25], 9
	v_lshl_add_u64 v[16:17], v[18:19], 0, s[24:25]
	s_add_i32 s24, s22, 3
	s_ashr_i32 s25, s24, 31
	s_lshl_b64 s[24:25], s[24:25], 9
	v_lshl_add_u64 v[32:33], v[18:19], 0, s[24:25]
	global_load_dwordx2 v[20:21], v[6:7], off nt
	s_nop 0
	global_load_dwordx2 v[6:7], v[8:9], off nt
	s_nop 0
	global_load_dwordx2 v[16:17], v[16:17], off nt
	s_nop 0
	global_load_dwordx2 v[8:9], v[32:33], off nt
	s_cmp_eq_u32 s55, s54
	s_cbranch_scc1 .LBB1_64
; %bb.61:                               ;   in Loop: Header=BB1_60 Depth=2
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[2:3]
	s_cbranch_execz .LBB1_63
; %bb.62:                               ;   in Loop: Header=BB1_60 Depth=2
	s_lshl2_add_u32 s23, s54, s57
	v_mov_b32_e32 v32, s23
	ds_read_b32 v33, v32
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v33
	ds_write_b32 v32, v4
.LBB1_63:                               ; %Flow698
                                        ;   in Loop: Header=BB1_60 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v4, 0
.LBB1_64:                               ;   in Loop: Header=BB1_60 Depth=2
	v_lshl_or_b32 v15, s56, 10, v3
	ds_read_b128 v[32:35], v15
	s_waitcnt vmcnt(3)
	v_and_b32_e32 v37, 0xffff0000, v21
	v_lshlrev_b32_e32 v36, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v20
	v_lshlrev_b32_e32 v20, 16, v20
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[32:33], v[20:21]
	v_pk_mul_f32 v[34:35], v[34:35], v[36:37]
	v_add_f32_e32 v15, v20, v21
	s_add_i32 s54, s56, 1
	v_add_f32_e32 v15, v15, v34
	s_cmp_eq_u32 s54, s43
	v_add_f32_e32 v15, v15, v35
	s_cselect_b64 s[24:25], -1, 0
	s_addc_u32 s23, s55, 0
	s_cmp_lg_u32 s54, s43
	v_add_f32_e32 v4, v4, v15
	s_cbranch_scc1 .LBB1_68
; %bb.65:                               ;   in Loop: Header=BB1_60 Depth=2
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[2:3]
	s_cbranch_execz .LBB1_67
; %bb.66:                               ;   in Loop: Header=BB1_60 Depth=2
	s_lshl2_add_u32 s55, s55, s57
	v_mov_b32_e32 v20, s55
	ds_read_b32 v21, v20
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v21
	ds_write_b32 v20, v4
.LBB1_67:                               ; %Flow697
                                        ;   in Loop: Header=BB1_60 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s55, s23
.LBB1_68:                               ;   in Loop: Header=BB1_60 Depth=2
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s54, 0, s54
	v_lshl_or_b32 v15, s54, 10, v3
	ds_read_b128 v[32:35], v15
	s_waitcnt vmcnt(2)
	v_and_b32_e32 v37, 0xffff0000, v6
	v_lshlrev_b32_e32 v36, 16, v6
	v_and_b32_e32 v21, 0xffff0000, v7
	v_lshlrev_b32_e32 v20, 16, v7
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[32:33], v[32:33], v[36:37]
	v_pk_mul_f32 v[20:21], v[34:35], v[20:21]
	v_add_f32_e32 v15, v32, v33
	s_add_i32 s54, s54, 1
	v_add_f32_e32 v15, v15, v20
	s_cmp_eq_u32 s54, s43
	v_add_f32_e32 v15, v15, v21
	s_cselect_b64 s[24:25], -1, 0
	s_addc_u32 s23, s23, 0
	s_cmp_eq_u32 s23, s55
	v_add_f32_e32 v4, v4, v15
	s_cbranch_scc1 .LBB1_72
; %bb.69:                               ;   in Loop: Header=BB1_60 Depth=2
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[2:3]
	s_cbranch_execz .LBB1_71
; %bb.70:                               ;   in Loop: Header=BB1_60 Depth=2
	s_lshl2_add_u32 s55, s55, s57
	v_mov_b32_e32 v20, s55
	ds_read_b32 v21, v20
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v21
	ds_write_b32 v20, v4
.LBB1_71:                               ; %Flow696
                                        ;   in Loop: Header=BB1_60 Depth=2
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s55, s23
.LBB1_72:                               ;   in Loop: Header=BB1_60 Depth=2
	s_and_b64 s[24:25], s[24:25], exec
	s_cselect_b32 s56, 0, s54
	v_lshl_or_b32 v15, s56, 10, v3
	ds_read_b128 v[32:35], v15
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v37, 0xffff0000, v16
	v_lshlrev_b32_e32 v36, 16, v16
	v_and_b32_e32 v21, 0xffff0000, v17
	v_lshlrev_b32_e32 v20, 16, v17
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[32:33], v[32:33], v[36:37]
	v_pk_mul_f32 v[20:21], v[34:35], v[20:21]
	v_add_f32_e32 v15, v32, v33
	s_add_i32 s56, s56, 1
	v_add_f32_e32 v15, v15, v20
	s_cmp_eq_u32 s56, s43
	v_add_f32_e32 v15, v15, v21
	s_cselect_b64 s[24:25], -1, 0
	s_addc_u32 s23, s23, 0
	s_cmp_eq_u32 s23, s55
	v_add_f32_e32 v4, v4, v15
	s_cbranch_scc1 .LBB1_75
; %bb.73:                               ;   in Loop: Header=BB1_60 Depth=2
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[2:3]
	s_cbranch_execz .LBB1_58
; %bb.74:                               ;   in Loop: Header=BB1_60 Depth=2
	s_lshl2_add_u32 s54, s55, s57
	v_mov_b32_e32 v20, s54
	ds_read_b32 v21, v20
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v21
	ds_write_b32 v20, v4
	s_branch .LBB1_58
.LBB1_75:                               ;   in Loop: Header=BB1_60 Depth=2
	s_mov_b32 s54, s55
	s_branch .LBB1_59
.LBB1_76:                               ;   in Loop: Header=BB1_52 Depth=1
                                        ; implicit-def: $vgpr9
                                        ; implicit-def: $vgpr6_vgpr7
                                        ; implicit-def: $vgpr16_vgpr17
	s_cbranch_execnz .LBB1_122
	s_branch .LBB1_51
.LBB1_77:                               ;   in Loop: Header=BB1_52 Depth=1
	v_mov_b32_e32 v9, v31
	v_mov_b32_e32 v8, v30
	v_mov_b32_e32 v17, v29
	v_mov_b32_e32 v16, v28
	v_mov_b32_e32 v7, v27
	v_mov_b32_e32 v6, v26
	s_mov_b32 s26, s52
	s_mov_b32 s54, s55
.LBB1_78:                               ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_ge_i32 s26, s53
	s_cbranch_scc1 .LBB1_107
; %bb.79:                               ;   in Loop: Header=BB1_52 Depth=1
	v_mov_b32_e32 v15, v5
	s_ashr_i32 s27, s26, 31
	v_lshl_add_u64 v[20:21], s[20:21], 0, v[14:15]
	s_lshl_b64 s[20:21], s[26:27], 9
	v_lshl_add_u64 v[18:19], v[20:21], 0, s[20:21]
	global_load_dwordx2 v[18:19], v[18:19], off nt
	s_add_i32 s20, s26, 1
	s_cmp_lt_i32 s20, s53
	s_cselect_b64 s[24:25], -1, 0
	s_cmp_ge_i32 s20, s53
	s_cbranch_scc1 .LBB1_81
; %bb.80:                               ;   in Loop: Header=BB1_52 Depth=1
	s_ashr_i32 s21, s20, 31
	s_lshl_b64 s[20:21], s[20:21], 9
	v_lshl_add_u64 v[6:7], v[20:21], 0, s[20:21]
	global_load_dwordx2 v[6:7], v[6:7], off nt
.LBB1_81:                               ;   in Loop: Header=BB1_52 Depth=1
	s_add_i32 s20, s26, 2
	s_cmp_lt_i32 s20, s53
	s_cselect_b64 s[22:23], -1, 0
	s_cmp_ge_i32 s20, s53
	s_cbranch_scc1 .LBB1_83
; %bb.82:                               ;   in Loop: Header=BB1_52 Depth=1
	s_ashr_i32 s21, s20, 31
	s_lshl_b64 s[20:21], s[20:21], 9
	v_lshl_add_u64 v[16:17], v[20:21], 0, s[20:21]
	global_load_dwordx2 v[16:17], v[16:17], off nt
.LBB1_83:                               ;   in Loop: Header=BB1_52 Depth=1
	s_add_i32 s26, s26, 3
	s_cmp_lt_i32 s26, s53
	s_cselect_b64 s[20:21], -1, 0
	s_cmp_ge_i32 s26, s53
	s_cbranch_scc1 .LBB1_85
; %bb.84:                               ;   in Loop: Header=BB1_52 Depth=1
	s_ashr_i32 s27, s26, 31
	s_lshl_b64 s[26:27], s[26:27], 9
	v_lshl_add_u64 v[8:9], v[20:21], 0, s[26:27]
	global_load_dwordx2 v[8:9], v[8:9], off nt
.LBB1_85:                               ;   in Loop: Header=BB1_52 Depth=1
	s_mul_i32 s26, s51, s50
	s_lshl2_add_u32 s57, s26, s34
	s_cmp_eq_u32 s55, s54
	s_cbranch_scc1 .LBB1_89
; %bb.86:                               ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[26:27], s[2:3]
	s_cbranch_execz .LBB1_88
; %bb.87:                               ;   in Loop: Header=BB1_52 Depth=1
	s_lshl2_add_u32 s54, s54, s57
	v_mov_b32_e32 v20, s54
	ds_read_b32 v21, v20
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v21
	ds_write_b32 v20, v4
.LBB1_88:                               ; %Flow693
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[26:27]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s54, s55
.LBB1_89:                               ;   in Loop: Header=BB1_52 Depth=1
	v_lshl_or_b32 v15, s56, 10, v3
	ds_read_b128 v[32:35], v15
	s_add_i32 s56, s56, 1
	s_cmp_eq_u32 s56, s43
	s_cselect_b64 s[58:59], -1, 0
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v21, 0xffff0000, v19
	v_lshlrev_b32_e32 v20, 16, v19
	v_and_b32_e32 v19, 0xffff0000, v18
	v_lshlrev_b32_e32 v18, 16, v18
	s_and_b64 s[26:27], s[58:59], exec
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[32:33], v[18:19]
	s_cselect_b32 s26, 0, s56
	s_cmp_lg_u64 s[58:59], 0
	v_pk_mul_f32 v[20:21], v[34:35], v[20:21]
	v_add_f32_e32 v15, v18, v19
	s_addc_u32 s27, s55, 0
	v_add_f32_e32 v15, v15, v20
	s_and_b64 s[24:25], s[24:25], exec
	v_add_f32_e32 v15, v15, v21
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	v_add_f32_e32 v4, v4, v15
	s_cbranch_scc1 .LBB1_101
; %bb.90:                               ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_eq_u32 s27, s54
	s_cbranch_scc1 .LBB1_94
; %bb.91:                               ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[2:3]
	s_cbranch_execz .LBB1_93
; %bb.92:                               ;   in Loop: Header=BB1_52 Depth=1
	s_lshl2_add_u32 s54, s54, s57
	v_mov_b32_e32 v18, s54
	ds_read_b32 v19, v18
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v19
	ds_write_b32 v18, v4
.LBB1_93:                               ; %Flow691
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s54, s27
.LBB1_94:                               ;   in Loop: Header=BB1_52 Depth=1
	v_lshl_or_b32 v15, s26, 10, v3
	ds_read_b128 v[18:21], v15
	v_and_b32_e32 v35, 0xffff0000, v6
	v_lshlrev_b32_e32 v34, 16, v6
	s_add_i32 s26, s26, 1
	v_and_b32_e32 v33, 0xffff0000, v7
	v_lshlrev_b32_e32 v32, 16, v7
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[18:19], v[34:35]
	s_cmp_eq_u32 s26, s43
	v_pk_mul_f32 v[20:21], v[20:21], v[32:33]
	v_add_f32_e32 v15, v18, v19
	s_cselect_b64 s[24:25], -1, 0
	v_add_f32_e32 v15, v15, v20
	s_and_b64 s[58:59], s[24:25], exec
	v_add_f32_e32 v15, v15, v21
	s_cselect_b32 s26, 0, s26
	s_cmp_lg_u64 s[24:25], 0
	v_add_f32_e32 v4, v4, v15
	s_addc_u32 s27, s27, 0
	s_and_b64 s[22:23], s[22:23], exec
	s_cselect_b32 s22, 1, 0
	s_cmp_lg_u32 s22, 1
	s_cbranch_scc0 .LBB1_102
.LBB1_95:                               ;   in Loop: Header=BB1_52 Depth=1
	s_and_b64 s[20:21], s[20:21], exec
	s_cselect_b32 s20, 1, 0
	s_cmp_lg_u32 s20, 1
	s_cbranch_scc1 .LBB1_107
.LBB1_96:                               ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_eq_u32 s27, s54
	s_cbranch_scc1 .LBB1_100
; %bb.97:                               ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[20:21], s[2:3]
	s_cbranch_execz .LBB1_99
; %bb.98:                               ;   in Loop: Header=BB1_52 Depth=1
	s_lshl2_add_u32 s22, s54, s57
	v_mov_b32_e32 v18, s22
	ds_read_b32 v19, v18
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v19
	ds_write_b32 v18, v4
.LBB1_99:                               ; %Flow687
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s54, s27
.LBB1_100:                              ;   in Loop: Header=BB1_52 Depth=1
	v_lshl_or_b32 v15, s26, 10, v3
	ds_read_b128 v[18:21], v15
	v_and_b32_e32 v35, 0xffff0000, v8
	v_lshlrev_b32_e32 v34, 16, v8
	v_and_b32_e32 v33, 0xffff0000, v9
	v_lshlrev_b32_e32 v32, 16, v9
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[18:19], v[34:35]
	v_pk_mul_f32 v[20:21], v[20:21], v[32:33]
	v_add_f32_e32 v15, v18, v19
	v_add_f32_e32 v15, v15, v20
	v_add_f32_e32 v15, v15, v21
	v_add_f32_e32 v4, v4, v15
	s_cmp_ge_i32 s52, s53
	s_cbranch_scc0 .LBB1_108
	s_branch .LBB1_111
.LBB1_101:                              ;   in Loop: Header=BB1_52 Depth=1
	s_and_b64 s[22:23], s[22:23], exec
	s_cselect_b32 s22, 1, 0
	s_cmp_lg_u32 s22, 1
	s_cbranch_scc1 .LBB1_95
.LBB1_102:                              ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_eq_u32 s27, s54
	s_cbranch_scc1 .LBB1_106
; %bb.103:                              ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[22:23], s[2:3]
	s_cbranch_execz .LBB1_105
; %bb.104:                              ;   in Loop: Header=BB1_52 Depth=1
	s_lshl2_add_u32 s24, s54, s57
	v_mov_b32_e32 v18, s24
	ds_read_b32 v19, v18
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v19
	ds_write_b32 v18, v4
.LBB1_105:                              ; %Flow689
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[22:23]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s54, s27
.LBB1_106:                              ;   in Loop: Header=BB1_52 Depth=1
	v_lshl_or_b32 v15, s26, 10, v3
	ds_read_b128 v[18:21], v15
	v_and_b32_e32 v35, 0xffff0000, v16
	v_lshlrev_b32_e32 v34, 16, v16
	s_add_i32 s26, s26, 1
	v_and_b32_e32 v33, 0xffff0000, v17
	v_lshlrev_b32_e32 v32, 16, v17
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[18:19], v[34:35]
	s_cmp_eq_u32 s26, s43
	v_pk_mul_f32 v[20:21], v[20:21], v[32:33]
	v_add_f32_e32 v15, v18, v19
	s_cselect_b64 s[22:23], -1, 0
	v_add_f32_e32 v15, v15, v20
	s_and_b64 s[24:25], s[22:23], exec
	v_add_f32_e32 v15, v15, v21
	s_cselect_b32 s26, 0, s26
	s_cmp_lg_u64 s[22:23], 0
	v_add_f32_e32 v4, v4, v15
	s_addc_u32 s27, s27, 0
	s_and_b64 s[20:21], s[20:21], exec
	s_cselect_b32 s20, 1, 0
	s_cmp_lg_u32 s20, 1
	s_cbranch_scc0 .LBB1_96
.LBB1_107:                              ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_ge_i32 s52, s53
	s_cbranch_scc1 .LBB1_111
.LBB1_108:                              ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v15, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[20:21], s[2:3]
	s_cbranch_execz .LBB1_110
; %bb.109:                              ;   in Loop: Header=BB1_52 Depth=1
	s_mul_i32 s51, s51, s50
	s_lshl2_add_u32 s22, s51, s34
	s_lshl2_add_u32 s22, s54, s22
	v_mov_b32_e32 v18, s22
	ds_read_b32 v19, v18
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v19
	ds_write_b32 v18, v4
.LBB1_110:                              ; %Flow686
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
.LBB1_111:                              ;   in Loop: Header=BB1_52 Depth=1
	v_cmp_gt_i32_e32 vcc, s50, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[20:21], vcc
	s_cbranch_execz .LBB1_121
; %bb.112:                              ; %.preheader351
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_lshl_b32 s26, s50, 2
	s_mov_b64 s[22:23], 0
	v_mov_b32_e32 v4, v24
	v_mov_b32_e32 v15, v0
	s_branch .LBB1_114
.LBB1_113:                              ;   in Loop: Header=BB1_114 Depth=2
	v_mul_f32_e32 v18, v1, v18
	v_bfe_u32 v19, v18, 16, 1
	v_add_u32_e32 v20, s33, v15
	v_add3_u32 v19, v19, v18, s46
	v_or_b32_e32 v32, 0x400000, v18
	v_cmp_u_f32_e32 vcc, v18, v18
	v_add_u32_e32 v15, s37, v15
	v_ashrrev_i32_e32 v21, 31, v20
	v_cndmask_b32_e32 v18, v19, v32, vcc
	v_cmp_le_i32_e32 vcc, s50, v15
	v_lshl_add_u64 v[20:21], v[20:21], 1, s[4:5]
	v_lshrrev_b32_e32 v18, 16, v18
	s_or_b64 s[22:23], vcc, s[22:23]
	v_add_u32_e32 v4, s45, v4
	global_store_short v[20:21], v18, off sc0 sc1
	s_andn2_b64 exec, exec, s[22:23]
	s_cbranch_execz .LBB1_121
.LBB1_114:                              ;   Parent Loop BB1_52 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_116 Depth 3
                                        ;       Child Loop BB1_120 Depth 3
	s_and_b64 s[24:25], s[10:11], exec
	s_cselect_b32 s24, 1, 0
	s_cmp_lg_u32 s24, 1
	s_cbranch_scc1 .LBB1_118
; %bb.115:                              ; %.preheader345
                                        ;   in Loop: Header=BB1_114 Depth=2
	v_lshl_add_u32 v19, v15, 2, s34
	s_mov_b32 s24, 0
	v_mov_b32_e32 v18, 0
.LBB1_116:                              ;   Parent Loop BB1_52 Depth=1
                                        ;     Parent Loop BB1_114 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s25, s24, s50
	v_lshl_add_u32 v20, s25, 2, v19
	v_add_u32_e32 v21, s26, v20
	ds_read_b32 v20, v20
	ds_read_b32 v32, v21
	v_add_u32_e32 v21, s26, v21
	v_add_u32_e32 v33, s26, v21
	ds_read_b32 v21, v21
	ds_read_b32 v34, v33
	v_add_u32_e32 v33, s26, v33
	v_add_u32_e32 v35, s26, v33
	ds_read_b32 v33, v33
	ds_read_b32 v36, v35
	v_add_u32_e32 v35, s26, v35
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v18, v18, v20
	v_add_u32_e32 v37, s26, v35
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v18, v18, v32
	ds_read_b32 v35, v35
	ds_read_b32 v37, v37
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v18, v18, v21
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v18, v18, v34
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v18, v18, v33
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v18, v18, v36
	s_add_i32 s24, s24, 8
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v18, v18, v35
	s_cmp_lg_u32 s24, s41
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v37
	s_cbranch_scc1 .LBB1_116
; %bb.117:                              ;   in Loop: Header=BB1_114 Depth=2
	s_mov_b32 s27, s41
	s_mov_b64 s[24:25], s[12:13]
	s_and_b64 vcc, exec, s[24:25]
	s_cbranch_vccz .LBB1_113
	s_branch .LBB1_119
.LBB1_118:                              ;   in Loop: Header=BB1_114 Depth=2
	s_mov_b32 s27, 0
	v_mov_b32_e32 v18, 0
	s_cbranch_execz .LBB1_113
.LBB1_119:                              ;   in Loop: Header=BB1_114 Depth=2
	s_mul_i32 s24, s26, s27
	v_add_u32_e32 v19, s24, v4
	s_mov_b32 s24, s40
.LBB1_120:                              ;   Parent Loop BB1_52 Depth=1
                                        ;     Parent Loop BB1_114 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v20, v19
	s_add_i32 s24, s24, -1
	v_add_u32_e32 v19, s26, v19
	s_cmp_lg_u32 s24, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v18, v18, v20
	s_cbranch_scc1 .LBB1_120
	s_branch .LBB1_113
.LBB1_121:                              ; %Flow685
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
	s_barrier
	s_branch .LBB1_51
.LBB1_122:                              ;   in Loop: Header=BB1_52 Depth=1
	s_sub_i32 s26, s49, s33
	s_mul_i32 s25, s38, s26
	v_readfirstlane_b32 s24, v0
	v_cmp_gt_i32_e32 vcc, s25, v0
	s_and_saveexec_b64 s[20:21], vcc
	s_cbranch_execz .LBB1_125
; %bb.123:                              ; %.preheader349
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_mov_b64 s[22:23], 0
	v_mov_b32_e32 v4, v24
	v_mov_b32_e32 v6, v0
.LBB1_124:                              ;   Parent Loop BB1_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v6, s37, v6
	v_cmp_le_i32_e32 vcc, s25, v6
	ds_write_b32 v4, v5
	s_or_b64 s[22:23], vcc, s[22:23]
	v_add_u32_e32 v4, s45, v4
	s_andn2_b64 exec, exec, s[22:23]
	s_cbranch_execnz .LBB1_124
.LBB1_125:                              ; %Flow717
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
	s_lshr_b32 s20, s28, 23
	s_add_i32 s20, s31, s20
	s_ashr_i32 s51, s20, 9
	s_mul_i32 s20, s26, s51
	s_add_i32 s21, s20, s39
	s_ashr_i32 s22, s21, 31
	s_abs_i32 s21, s21
	s_mul_hi_u32 s23, s21, s42
	s_lshr_b32 s27, s24, 6
	s_mul_i32 s24, s23, s38
	s_sub_i32 s21, s21, s24
	s_add_i32 s24, s23, 1
	s_sub_i32 s25, s21, s38
	s_cmp_ge_u32 s21, s38
	s_cselect_b32 s23, s24, s23
	s_cselect_b32 s21, s25, s21
	s_add_i32 s24, s23, 1
	s_cmp_ge_u32 s21, s38
	s_cselect_b32 s21, s24, s23
	s_xor_b32 s21, s21, s22
	s_sub_i32 s21, s21, s22
	s_mul_i32 s49, s21, s27
	s_add_i32 s21, s49, s21
	s_min_i32 s50, s20, s21
	s_lshl_b64 s[18:19], s[18:19], 1
	s_add_u32 s18, s29, s18
	s_addc_u32 s19, s36, s19
	s_abs_i32 s20, s51
	v_cvt_f32_u32_e32 v4, s20
	s_sub_i32 s23, 0, s20
	s_abs_i32 s22, s49
	s_xor_b32 s21, s49, s51
	v_rcp_f32_e32 v4, v4
	s_ashr_i32 s21, s21, 31
	v_mov_b32_e32 v15, 0
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v4, 0x4f7ffffe, v4
	v_cvt_u32_f32_e32 v4, v4
	s_barrier
	v_readfirstlane_b32 s24, v4
	s_mul_i32 s23, s23, s24
	s_mul_hi_u32 s23, s24, s23
	s_add_i32 s24, s24, s23
	s_mul_hi_u32 s23, s22, s24
	s_mul_i32 s24, s23, s20
	s_sub_i32 s22, s22, s24
	s_add_i32 s24, s23, 1
	s_sub_i32 s25, s22, s20
	s_cmp_ge_u32 s22, s20
	s_cselect_b32 s23, s24, s23
	s_cselect_b32 s22, s25, s22
	s_add_i32 s24, s23, 1
	s_cmp_ge_u32 s22, s20
	s_cselect_b32 s20, s24, s23
	s_xor_b32 s20, s20, s21
	s_sub_i32 s52, s20, s21
	s_mul_i32 s20, s52, s51
	s_sub_i32 s25, s49, s20
	s_add_i32 s20, s49, 2
	s_cmp_le_i32 s20, s50
	s_cbranch_scc0 .LBB1_137
; %bb.126:                              ;   in Loop: Header=BB1_52 Depth=1
	v_lshlrev_b32_e32 v4, 4, v2
	s_mul_i32 s20, s27, s26
	v_lshl_add_u64 v[16:17], s[18:19], 0, v[4:5]
	s_lshl2_add_u32 s53, s20, s34
	v_mov_b32_e32 v15, 0
	s_mov_b32 s20, s49
	s_mov_b32 s24, s52
	s_branch .LBB1_129
.LBB1_127:                              ; %Flow712
                                        ;   in Loop: Header=BB1_129 Depth=2
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v4, 0
	s_mov_b32 s24, s21
.LBB1_128:                              ;   in Loop: Header=BB1_129 Depth=2
	s_and_b64 s[22:23], s[22:23], exec
	s_cselect_b32 s22, 0, s54
	v_lshl_or_b32 v15, s22, 11, v23
	ds_read_b128 v[6:9], v15
	ds_read_b128 v[18:21], v15 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v39, 0xffff0000, v10
	v_lshlrev_b32_e32 v38, 16, v10
	v_and_b32_e32 v37, 0xffff0000, v11
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[6:7], v[38:39]
	v_lshlrev_b32_e32 v36, 16, v11
	v_add_f32_e32 v6, 0, v6
	v_pk_mul_f32 v[8:9], v[8:9], v[36:37]
	v_add_f32_e32 v6, v6, v7
	v_and_b32_e32 v35, 0xffff0000, v12
	v_lshlrev_b32_e32 v34, 16, v12
	v_add_f32_e32 v6, v6, v8
	s_add_i32 s25, s22, 1
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[18:19], v[18:19], v[34:35]
	v_add_f32_e32 v6, v6, v9
	s_cmp_eq_u32 s25, s51
	v_and_b32_e32 v33, 0xffff0000, v13
	v_lshlrev_b32_e32 v32, 16, v13
	v_add_f32_e32 v6, v6, v18
	s_cselect_b64 s[22:23], -1, 0
	v_pk_mul_f32 v[20:21], v[20:21], v[32:33]
	v_add_f32_e32 v6, v6, v19
	s_and_b64 s[54:55], s[22:23], exec
	v_add_f32_e32 v6, v6, v20
	s_cselect_b32 s25, 0, s25
	s_cmp_lg_u64 s[22:23], 0
	v_add_f32_e32 v6, v6, v21
	s_addc_u32 s52, s21, 0
	s_add_i32 s22, s20, 2
	s_add_i32 s20, s20, 4
	v_add_f32_e32 v15, v4, v6
	s_cmp_le_i32 s20, s50
	s_mov_b32 s20, s22
	s_cbranch_scc0 .LBB1_138
.LBB1_129:                              ;   Parent Loop BB1_52 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	s_ashr_i32 s21, s20, 31
	s_lshl_b64 s[22:23], s[20:21], 10
	v_lshl_add_u64 v[18:19], v[16:17], 0, s[22:23]
	s_add_i32 s22, s20, 1
	s_ashr_i32 s23, s22, 31
	s_lshl_b64 s[22:23], s[22:23], 10
	v_lshl_add_u64 v[20:21], v[16:17], 0, s[22:23]
	global_load_dwordx4 v[6:9], v[18:19], off nt
	global_load_dwordx4 v[10:13], v[20:21], off nt
	s_cmp_eq_u32 s52, s24
	s_cbranch_scc1 .LBB1_133
; %bb.130:                              ;   in Loop: Header=BB1_129 Depth=2
	ds_bpermute_b32 v4, v22, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v15, v4
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[22:23], s[2:3]
	s_cbranch_execz .LBB1_132
; %bb.131:                              ;   in Loop: Header=BB1_129 Depth=2
	s_lshl2_add_u32 s21, s24, s53
	v_mov_b32_e32 v18, s21
	ds_read_b32 v19, v18
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v19
	ds_write_b32 v18, v4
.LBB1_132:                              ; %Flow713
                                        ;   in Loop: Header=BB1_129 Depth=2
	s_or_b64 exec, exec, s[22:23]
	v_mov_b32_e32 v15, 0
.LBB1_133:                              ;   in Loop: Header=BB1_129 Depth=2
	v_lshl_or_b32 v4, s25, 11, v23
	ds_read_b128 v[18:21], v4
	ds_read_b128 v[32:35], v4 offset:16
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v39, 0xffff0000, v7
	v_lshlrev_b32_e32 v38, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[18:19], v[6:7]
	v_pk_mul_f32 v[20:21], v[20:21], v[38:39]
	v_add_f32_e32 v4, 0, v6
	v_add_f32_e32 v4, v4, v7
	v_and_b32_e32 v37, 0xffff0000, v9
	v_lshlrev_b32_e32 v36, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v4, v4, v20
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[32:33], v[8:9]
	v_add_f32_e32 v4, v4, v21
	v_add_f32_e32 v4, v4, v8
	v_pk_mul_f32 v[34:35], v[34:35], v[36:37]
	v_add_f32_e32 v4, v4, v9
	s_add_i32 s54, s25, 1
	v_add_f32_e32 v4, v4, v34
	s_cmp_eq_u32 s54, s51
	v_add_f32_e32 v4, v4, v35
	s_cselect_b64 s[22:23], -1, 0
	s_addc_u32 s21, s52, 0
	s_cmp_lg_u32 s54, s51
	v_add_f32_e32 v4, v15, v4
	s_cbranch_scc1 .LBB1_136
; %bb.134:                              ;   in Loop: Header=BB1_129 Depth=2
	ds_bpermute_b32 v6, v22, v4
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v6
	ds_swizzle_b32 v6, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v6
	v_mov_b32_e32 v6, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v6, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[24:25], s[2:3]
	s_cbranch_execz .LBB1_127
; %bb.135:                              ;   in Loop: Header=BB1_129 Depth=2
	s_lshl2_add_u32 s52, s52, s53
	v_mov_b32_e32 v7, s52
	ds_read_b32 v8, v7
	v_add_f32_e32 v4, v4, v6
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v8
	ds_write_b32 v7, v4
	s_branch .LBB1_127
.LBB1_136:                              ;   in Loop: Header=BB1_129 Depth=2
	s_mov_b32 s24, s52
	s_branch .LBB1_128
.LBB1_137:                              ;   in Loop: Header=BB1_52 Depth=1
	s_mov_b32 s22, s49
	s_mov_b32 s24, s52
.LBB1_138:                              ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_ge_i32 s22, s50
	s_cbranch_scc1 .LBB1_151
; %bb.139:                              ;   in Loop: Header=BB1_52 Depth=1
	v_lshlrev_b32_e32 v4, 4, v2
	s_ashr_i32 s23, s22, 31
	v_lshl_add_u64 v[16:17], s[18:19], 0, v[4:5]
	s_lshl_b64 s[18:19], s[22:23], 10
	v_lshl_add_u64 v[6:7], v[16:17], 0, s[18:19]
	global_load_dwordx4 v[6:9], v[6:7], off nt
	s_add_i32 s20, s22, 1
	s_cmp_lt_i32 s20, s50
	s_cselect_b64 s[18:19], -1, 0
	s_cmp_ge_i32 s20, s50
	s_cbranch_scc1 .LBB1_141
; %bb.140:                              ;   in Loop: Header=BB1_52 Depth=1
	s_ashr_i32 s21, s20, 31
	s_lshl_b64 s[20:21], s[20:21], 10
	v_lshl_add_u64 v[10:11], v[16:17], 0, s[20:21]
	global_load_dwordx4 v[10:13], v[10:11], off nt
.LBB1_141:                              ;   in Loop: Header=BB1_52 Depth=1
	s_mul_i32 s20, s27, s26
	s_lshl2_add_u32 s22, s20, s34
	s_cmp_eq_u32 s52, s24
	s_cbranch_scc1 .LBB1_145
; %bb.142:                              ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v4, v22, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v15, v4
	ds_swizzle_b32 v15, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v15
	v_mov_b32_e32 v15, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v15, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[20:21], s[2:3]
	s_cbranch_execz .LBB1_144
; %bb.143:                              ;   in Loop: Header=BB1_52 Depth=1
	s_lshl2_add_u32 s23, s24, s22
	v_mov_b32_e32 v16, s23
	ds_read_b32 v17, v16
	v_add_f32_e32 v4, v4, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v17
	ds_write_b32 v16, v4
.LBB1_144:                              ; %Flow710
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
	v_mov_b32_e32 v15, 0
	s_mov_b32 s24, s52
.LBB1_145:                              ;   in Loop: Header=BB1_52 Depth=1
	v_lshl_or_b32 v4, s25, 11, v23
	ds_read_b128 v[16:19], v4
	ds_read_b128 v[32:35], v4 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v37, 0xffff0000, v7
	v_lshlrev_b32_e32 v36, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[16:17], v[6:7]
	v_pk_mul_f32 v[18:19], v[18:19], v[36:37]
	v_add_f32_e32 v4, 0, v6
	v_add_f32_e32 v4, v4, v7
	v_and_b32_e32 v21, 0xffff0000, v9
	v_lshlrev_b32_e32 v20, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v4, v4, v18
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[32:33], v[8:9]
	v_add_f32_e32 v4, v4, v19
	v_add_f32_e32 v4, v4, v8
	v_pk_mul_f32 v[20:21], v[34:35], v[20:21]
	v_add_f32_e32 v4, v4, v9
	v_add_f32_e32 v4, v4, v20
	s_and_b64 s[18:19], s[18:19], exec
	v_add_f32_e32 v4, v4, v21
	s_cselect_b32 s18, 1, 0
	s_cmp_lg_u32 s18, 1
	v_add_f32_e32 v15, v15, v4
	s_cbranch_scc1 .LBB1_151
; %bb.146:                              ;   in Loop: Header=BB1_52 Depth=1
	s_add_i32 s25, s25, 1
	s_cmp_eq_u32 s25, s51
	s_cselect_b64 s[18:19], -1, 0
	s_addc_u32 s23, s52, 0
	s_cmp_eq_u32 s23, s24
	s_cbranch_scc1 .LBB1_150
; %bb.147:                              ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v4, v22, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v15, v4
	ds_swizzle_b32 v6, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v6
	v_mov_b32_e32 v6, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v6, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[20:21], s[2:3]
	s_cbranch_execz .LBB1_149
; %bb.148:                              ;   in Loop: Header=BB1_52 Depth=1
	s_lshl2_add_u32 s22, s24, s22
	v_mov_b32_e32 v7, s22
	ds_read_b32 v8, v7
	v_add_f32_e32 v4, v4, v6
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v8
	ds_write_b32 v7, v4
.LBB1_149:                              ; %Flow708
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[20:21]
	v_mov_b32_e32 v15, 0
	s_mov_b32 s24, s23
.LBB1_150:                              ;   in Loop: Header=BB1_52 Depth=1
	s_lshl_b32 s20, s25, 11
	s_and_b64 s[18:19], s[18:19], exec
	s_cselect_b32 s18, 0, s20
	v_or_b32_e32 v4, s18, v23
	ds_read_b128 v[6:9], v4
	ds_read_b128 v[16:19], v4 offset:16
	v_and_b32_e32 v37, 0xffff0000, v10
	v_lshlrev_b32_e32 v36, 16, v10
	v_and_b32_e32 v35, 0xffff0000, v11
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[6:7], v[36:37]
	v_lshlrev_b32_e32 v34, 16, v11
	v_add_f32_e32 v4, 0, v6
	v_pk_mul_f32 v[8:9], v[8:9], v[34:35]
	v_add_f32_e32 v4, v4, v7
	v_and_b32_e32 v33, 0xffff0000, v12
	v_lshlrev_b32_e32 v32, 16, v12
	v_add_f32_e32 v4, v4, v8
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[16:17], v[16:17], v[32:33]
	v_add_f32_e32 v4, v4, v9
	v_and_b32_e32 v21, 0xffff0000, v13
	v_lshlrev_b32_e32 v20, 16, v13
	v_add_f32_e32 v4, v4, v16
	v_pk_mul_f32 v[18:19], v[18:19], v[20:21]
	v_add_f32_e32 v4, v4, v17
	v_add_f32_e32 v4, v4, v18
	v_add_f32_e32 v4, v4, v19
	v_add_f32_e32 v15, v15, v4
.LBB1_151:                              ;   in Loop: Header=BB1_52 Depth=1
	s_cmp_ge_i32 s49, s50
	s_cbranch_scc1 .LBB1_155
; %bb.152:                              ;   in Loop: Header=BB1_52 Depth=1
	ds_bpermute_b32 v4, v22, v15
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v15, v4
	ds_swizzle_b32 v6, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v6
	v_mov_b32_e32 v6, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v6, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[18:19], s[2:3]
	s_cbranch_execz .LBB1_154
; %bb.153:                              ;   in Loop: Header=BB1_52 Depth=1
	s_mul_i32 s27, s27, s26
	s_lshl2_add_u32 s20, s27, s34
	s_lshl2_add_u32 s20, s24, s20
	v_mov_b32_e32 v7, s20
	ds_read_b32 v8, v7
	v_add_f32_e32 v4, v4, v6
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v8
	ds_write_b32 v7, v4
.LBB1_154:                              ; %Flow707
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[18:19]
.LBB1_155:                              ;   in Loop: Header=BB1_52 Depth=1
	v_cmp_gt_i32_e32 vcc, s26, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[18:19], vcc
	s_cbranch_execz .LBB1_165
; %bb.156:                              ; %.preheader346
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_lshl_b32 s24, s26, 2
	s_mov_b64 s[20:21], 0
	v_mov_b32_e32 v4, v24
	v_mov_b32_e32 v6, v0
	s_branch .LBB1_158
.LBB1_157:                              ;   in Loop: Header=BB1_158 Depth=2
	v_mul_f32_e32 v7, v1, v7
	v_bfe_u32 v15, v7, 16, 1
	v_add_u32_e32 v8, s33, v6
	v_add3_u32 v15, v15, v7, s46
	v_or_b32_e32 v16, 0x400000, v7
	v_cmp_u_f32_e32 vcc, v7, v7
	v_add_u32_e32 v6, s37, v6
	v_ashrrev_i32_e32 v9, 31, v8
	v_cndmask_b32_e32 v7, v15, v16, vcc
	v_cmp_le_i32_e32 vcc, s26, v6
	v_lshl_add_u64 v[8:9], v[8:9], 1, s[4:5]
	v_lshrrev_b32_e32 v7, 16, v7
	s_or_b64 s[20:21], vcc, s[20:21]
	v_add_u32_e32 v4, s45, v4
	global_store_short v[8:9], v7, off sc0 sc1
	s_andn2_b64 exec, exec, s[20:21]
	s_cbranch_execz .LBB1_165
.LBB1_158:                              ;   Parent Loop BB1_52 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_160 Depth 3
                                        ;       Child Loop BB1_164 Depth 3
	s_and_b64 s[22:23], s[14:15], exec
	s_cselect_b32 s22, 1, 0
	s_cmp_lg_u32 s22, 1
	s_cbranch_scc1 .LBB1_162
; %bb.159:                              ; %.preheader343
                                        ;   in Loop: Header=BB1_158 Depth=2
	v_lshl_add_u32 v8, v6, 2, s34
	s_mov_b32 s22, 0
	v_mov_b32_e32 v7, 0
.LBB1_160:                              ;   Parent Loop BB1_52 Depth=1
                                        ;     Parent Loop BB1_158 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s23, s22, s26
	v_lshl_add_u32 v9, s23, 2, v8
	v_add_u32_e32 v15, s24, v9
	ds_read_b32 v9, v9
	ds_read_b32 v16, v15
	v_add_u32_e32 v15, s24, v15
	v_add_u32_e32 v17, s24, v15
	ds_read_b32 v15, v15
	ds_read_b32 v18, v17
	v_add_u32_e32 v17, s24, v17
	v_add_u32_e32 v19, s24, v17
	ds_read_b32 v17, v17
	ds_read_b32 v20, v19
	v_add_u32_e32 v19, s24, v19
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v7, v7, v9
	v_add_u32_e32 v21, s24, v19
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v7, v7, v16
	ds_read_b32 v19, v19
	ds_read_b32 v21, v21
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v7, v7, v15
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v7, v7, v18
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v7, v7, v17
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v7, v7, v20
	s_add_i32 s22, s22, 8
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v7, v7, v19
	s_cmp_lg_u32 s22, s41
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v21
	s_cbranch_scc1 .LBB1_160
; %bb.161:                              ;   in Loop: Header=BB1_158 Depth=2
	s_mov_b32 s25, s41
	s_mov_b64 s[22:23], s[12:13]
	s_and_b64 vcc, exec, s[22:23]
	s_cbranch_vccz .LBB1_157
	s_branch .LBB1_163
.LBB1_162:                              ;   in Loop: Header=BB1_158 Depth=2
	s_mov_b32 s25, 0
	v_mov_b32_e32 v7, 0
	s_cbranch_execz .LBB1_157
.LBB1_163:                              ;   in Loop: Header=BB1_158 Depth=2
	s_mul_i32 s22, s24, s25
	v_add_u32_e32 v8, s22, v4
	s_mov_b32 s22, s40
.LBB1_164:                              ;   Parent Loop BB1_52 Depth=1
                                        ;     Parent Loop BB1_158 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v9, v8
	s_add_i32 s22, s22, -1
	v_add_u32_e32 v8, s24, v8
	s_cmp_lg_u32 s22, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v9
	s_cbranch_scc1 .LBB1_164
	s_branch .LBB1_157
.LBB1_165:                              ; %Flow706
                                        ;   in Loop: Header=BB1_52 Depth=1
	s_or_b64 exec, exec, s[18:19]
	s_barrier
	s_cmp_lt_i32 s48, s6
	s_mov_b32 s33, s48
	s_cbranch_scc1 .LBB1_52
.LBB1_166:                              ; %Flow737
	s_mov_b64 s[2:3], 0
.LBB1_167:                              ; %Flow889
	s_and_b64 s[2:3], s[2:3], exec
	s_cselect_b32 s2, 1, 0
	s_cmp_lg_u32 s2, 1
	s_cbranch_scc1 .LBB1_496
; %bb.168:                              ; %LeafBlock677
	s_cmp_lg_u32 s30, 0
	s_cbranch_scc1 .LBB1_496
; %bb.169:
	s_load_dwordx2 s[2:3], s[16:17], 0x0
	s_ashr_i32 s22, s35, 31
	s_waitcnt lgkmcnt(0)
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s22
	s_load_dword s4, s[4:5], 0x9c
	s_waitcnt lgkmcnt(0)
	s_cmp_ge_i32 s7, s4
	s_cbranch_scc1 .LBB1_496
; %bb.170:
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s22
	s_load_dwordx2 s[12:13], s[4:5], 0x38
	s_load_dword s14, s[4:5], 0x30
	s_abs_i32 s4, s7
	s_waitcnt lgkmcnt(0)
	s_abs_i32 s6, s13
	v_cvt_f32_u32_e32 v1, s6
	s_sub_i32 s8, 0, s6
	s_xor_b32 s5, s7, s13
	s_ashr_i32 s5, s5, 31
	v_rcp_f32_e32 v1, v1
	s_nop 0
	v_mul_f32_e32 v1, 0x4f7ffffe, v1
	v_cvt_u32_f32_e32 v1, v1
	s_nop 0
	v_readfirstlane_b32 s9, v1
	s_mul_i32 s8, s8, s9
	s_mul_hi_u32 s8, s9, s8
	s_add_i32 s9, s9, s8
	s_mul_hi_u32 s8, s4, s9
	s_mul_i32 s9, s8, s6
	s_sub_i32 s4, s4, s9
	s_add_i32 s10, s8, 1
	s_sub_i32 s9, s4, s6
	s_cmp_ge_u32 s4, s6
	s_cselect_b32 s8, s10, s8
	s_cselect_b32 s4, s9, s4
	s_add_i32 s9, s8, 1
	s_cmp_ge_u32 s4, s6
	s_cselect_b32 s4, s9, s8
	s_xor_b32 s4, s4, s5
	s_sub_i32 s16, s4, s5
	s_mul_i32 s4, s16, s13
	s_sub_i32 s31, s7, s4
	s_mul_i32 s31, s31, s12
	s_add_i32 s4, s31, s12
	s_min_i32 s13, s14, s4
	s_cmp_le_i32 s13, s31
	s_cbranch_scc1 .LBB1_496
; %bb.171:
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s22
	s_load_dword s30, s[4:5], 0x34
	s_load_dwordx2 s[6:7], s[4:5], 0x28
	s_load_dword s15, s[4:5], 0x68
	s_load_dwordx4 s[8:11], s[4:5], 0x0
	s_load_dwordx2 s[18:19], s[4:5], 0x10
	s_waitcnt lgkmcnt(0)
	s_lshl_b32 s33, s30, 2
	s_lshl_b32 s34, s12, 3
	s_cmp_lt_i32 s15, 2
	s_cbranch_scc0 .LBB1_173
; %bb.172:
	s_add_u32 s4, s2, s35
	s_addc_u32 s5, s3, s22
	s_load_dwordx2 s[4:5], s[4:5], 0x18
	s_ashr_i32 s17, s16, 31
	s_lshl_b64 s[20:21], s[16:17], 2
	v_mov_b32_e32 v1, 0
	s_waitcnt lgkmcnt(0)
	s_add_u32 s4, s4, s20
	s_addc_u32 s5, s5, s21
	global_load_dword v1, v1, s[4:5] sc0 sc1
	s_mov_b64 s[4:5], 0
	s_waitcnt vmcnt(0)
	v_readfirstlane_b32 s20, v1
	s_branch .LBB1_174
.LBB1_173:
	s_mov_b64 s[4:5], -1
                                        ; implicit-def: $sgpr20
.LBB1_174:                              ; %Flow884
	s_add_i32 s17, s33, s34
	s_and_b64 s[4:5], s[4:5], exec
	s_cselect_b32 s4, 1, 0
	s_cmp_lg_u32 s4, 1
	s_cbranch_scc1 .LBB1_202
; %bb.175:
	v_cmp_gt_u32_e32 vcc, 64, v0
	s_and_saveexec_b64 s[20:21], vcc
	s_cbranch_execz .LBB1_201
; %bb.176:
	s_add_u32 s2, s2, s35
	s_addc_u32 s3, s3, s22
	s_load_dword s24, s[2:3], 0x6c
	s_load_dword s26, s[2:3], 0x60
	s_load_dwordx2 s[22:23], s[2:3], 0x70
	v_mov_b32_e32 v2, 0xff800000
	v_lshlrev_b32_e32 v4, 1, v0
	s_waitcnt lgkmcnt(0)
	v_cmp_gt_i32_e64 s[2:3], s24, v0
	v_mov_b32_e32 v1, v2
	s_and_saveexec_b64 s[4:5], s[2:3]
	s_cbranch_execz .LBB1_178
; %bb.177:
	global_load_ushort v1, v4, s[22:23] sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v1, 16, v1
.LBB1_178:
	s_or_b64 exec, exec, s[4:5]
	v_or_b32_e32 v3, 64, v0
	v_cmp_gt_i32_e64 s[4:5], s24, v3
	s_and_saveexec_b64 s[24:25], s[4:5]
	s_cbranch_execz .LBB1_180
; %bb.179:
	global_load_ushort v2, v4, s[22:23] offset:128 sc0 sc1
	s_waitcnt vmcnt(0)
	v_lshlrev_b32_e32 v2, 16, v2
.LBB1_180:
	s_or_b64 exec, exec, s[24:25]
	v_mov_b32_e32 v6, 0
	v_mov_b32_e32 v7, v6
	s_and_saveexec_b64 s[22:23], s[2:3]
	s_xor_b64 s[22:23], exec, s[22:23]
	s_cbranch_execz .LBB1_182
; %bb.181:
	v_bfe_u32 v4, v1, 16, 15
	s_mov_b32 s24, 0x8000
	v_sub_u32_e32 v4, 0x8000, v4
	v_or_b32_sdwa v5, v1, s24 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v1
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_mov_b32_e32 v5, 0x800000
	v_lshl_or_b32 v4, v4, 7, v5
	v_cmp_o_f32_e32 vcc, v1, v1
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_or_b32_e32 v4, v4, v0
	v_xor_b32_e32 v7, 0x7f, v4
.LBB1_182:
	s_or_b64 exec, exec, s[22:23]
	s_and_saveexec_b64 s[22:23], s[4:5]
	s_cbranch_execz .LBB1_184
; %bb.183:
	v_bfe_u32 v4, v2, 16, 15
	s_mov_b32 s24, 0x8000
	v_sub_u32_e32 v4, 0x8000, v4
	v_or_b32_sdwa v5, v2, s24 dst_sel:DWORD dst_unused:UNUSED_PAD src0_sel:WORD_1 src1_sel:DWORD
	v_cmp_gt_f32_e32 vcc, 0, v2
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_mov_b32_e32 v5, 0x800000
	v_lshl_or_b32 v4, v4, 7, v5
	v_cmp_o_f32_e32 vcc, v2, v2
	s_nop 1
	v_cndmask_b32_e32 v4, v5, v4, vcc
	v_or_b32_e32 v3, v4, v3
	v_xor_b32_e32 v6, 0x7f, v3
.LBB1_184:
	s_or_b64 exec, exec, s[22:23]
	v_max_u32_e32 v3, v7, v6
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v3, v3, v3 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s24, v3, 63
	s_lshr_b32 s22, s24, 7
	s_bfe_u32 s23, s24, 0x100007
	s_add_i32 s25, s22, 0xffff8000
	s_sub_i32 s22, 0x8000, s22
	s_bitset1_b32 s22, 15
	s_cmpk_gt_u32 s23, 0x7fff
	s_cselect_b32 s22, s25, s22
	s_lshl_b32 s22, s22, 16
	s_cmp_lg_u32 s23, 0
	v_mov_b32_e32 v3, 0x7fc00000
	v_mov_b32_e32 v4, s22
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v5, v3, v4, vcc
	v_mov_b32_e32 v3, 0
	v_mov_b32_e32 v4, v3
	s_and_saveexec_b64 s[22:23], s[2:3]
	s_cbranch_execz .LBB1_186
; %bb.185:
	v_sub_f32_e32 v1, v1, v5
	s_mov_b32 s25, 0x3fb8aa3b
	v_mul_f32_e32 v4, 0x3fb8aa3b, v1
	v_fma_f32 v8, v1, s25, -v4
	v_rndne_f32_e32 v9, v4
	v_fmamk_f32 v8, v1, 0x32a5705f, v8
	v_sub_f32_e32 v4, v4, v9
	v_add_f32_e32 v4, v4, v8
	v_exp_f32_e32 v4, v4
	v_cvt_i32_f32_e32 v8, v9
	s_mov_b32 s25, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s25, v1
	s_mov_b32 s25, 0x42b17218
	v_ldexp_f32 v4, v4, v8
	v_cndmask_b32_e32 v4, 0, v4, vcc
	v_mov_b32_e32 v8, 0x7f800000
	v_cmp_nlt_f32_e32 vcc, s25, v1
	s_nop 1
	v_cndmask_b32_e32 v4, v8, v4, vcc
.LBB1_186:
	s_or_b64 exec, exec, s[22:23]
	v_mov_b32_e32 v1, 0
	s_and_saveexec_b64 s[22:23], s[4:5]
	s_cbranch_execz .LBB1_188
; %bb.187:
	v_sub_f32_e32 v2, v2, v5
	s_mov_b32 s25, 0x3fb8aa3b
	v_mul_f32_e32 v3, 0x3fb8aa3b, v2
	v_fma_f32 v5, v2, s25, -v3
	v_rndne_f32_e32 v8, v3
	v_fmamk_f32 v5, v2, 0x32a5705f, v5
	v_sub_f32_e32 v3, v3, v8
	v_add_f32_e32 v3, v3, v5
	v_exp_f32_e32 v3, v3
	v_cvt_i32_f32_e32 v5, v8
	s_mov_b32 s25, 0xc2ce8ed0
	v_cmp_ngt_f32_e32 vcc, s25, v2
	s_mov_b32 s25, 0x42b17218
	v_ldexp_f32 v3, v3, v5
	v_cndmask_b32_e32 v3, 0, v3, vcc
	v_mov_b32_e32 v5, 0x7f800000
	v_cmp_nlt_f32_e32 vcc, s25, v2
	s_nop 1
	v_cndmask_b32_e32 v3, v5, v3, vcc
.LBB1_188:
	s_or_b64 exec, exec, s[22:23]
	v_mbcnt_lo_u32_b32 v5, -1, 0
	v_mbcnt_hi_u32_b32 v5, -1, v5
	v_and_b32_e32 v8, 64, v5
	v_add_u32_e32 v8, 64, v8
	v_xor_b32_e32 v9, 32, v5
	v_cmp_lt_u32_e32 vcc, v9, v8
	v_add_f32_e32 v2, v4, v3
	v_xor_b32_e32 v10, 16, v5
	v_cndmask_b32_e32 v9, v5, v9, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_cmp_lt_i32 s26, 1
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 8, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 4, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 2, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v9, v5, v10, vcc
	v_lshlrev_b32_e32 v9, 2, v9
	ds_bpermute_b32 v9, v9, v2
	v_xor_b32_e32 v10, 1, v5
	v_cmp_lt_u32_e32 vcc, v10, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v9
	v_cndmask_b32_e32 v5, v5, v10, vcc
	v_lshlrev_b32_e32 v5, 2, v5
	ds_bpermute_b32 v5, v5, v2
	s_cbranch_scc1 .LBB1_194
; %bb.189:
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v1, v2, v5
	v_div_scale_f32 v2, s[22:23], v1, v1, 1.0
	v_rcp_f32_e32 v5, v2
	v_div_scale_f32 v8, vcc, 1.0, v1, 1.0
	v_fma_f32 v9, -v2, v5, 1.0
	v_fmac_f32_e32 v5, v9, v5
	v_mul_f32_e32 v9, v8, v5
	v_fma_f32 v10, -v2, v9, v8
	v_fmac_f32_e32 v9, v10, v5
	v_fma_f32 v2, -v2, v9, v8
	v_div_fmas_f32 v2, v2, v5, v9
	v_div_fixup_f32 v1, v2, v1, 1.0
	v_mul_f32_e32 v2, v1, v4
	v_cndmask_b32_e64 v2, 0, v2, s[2:3]
	s_andn2_b32 s2, 0x7f, s24
	s_cmp_lg_u32 s24, 0
	s_cselect_b32 s2, s2, 0
	v_mul_f32_e32 v1, v1, v3
	s_cmp_gt_u32 s2, 63
	v_cndmask_b32_e64 v3, 0, v1, s[4:5]
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v1, v2, v3, vcc
	v_cmp_eq_u32_e32 vcc, 0, v0
	v_readlane_b32 s3, v1, s2
	s_cmp_eq_u32 s26, 1
	s_nop 0
	v_mov_b32_e32 v1, s3
	v_cndmask_b32_e32 v5, 0, v1, vcc
	v_mov_b32_e32 v1, s2
	v_cndmask_b32_e32 v4, 0, v1, vcc
	v_add_f32_e64 v1, s3, 0
	s_cbranch_scc1 .LBB1_199
; %bb.190:
	v_cmp_ne_u32_e32 vcc, s24, v7
	s_add_i32 s3, s26, -1
	s_add_i32 s5, s26, -2
	v_cndmask_b32_e32 v7, 0, v7, vcc
	s_and_b32 s4, s3, 3
	v_cmp_ne_u32_e32 vcc, s24, v6
	s_mov_b32 s2, 0
	s_cmp_lt_u32 s5, 3
	v_cndmask_b32_e32 v6, 0, v6, vcc
	s_cbranch_scc1 .LBB1_195
; %bb.191:
	s_and_b32 s3, s3, -4
	v_add_u32_e32 v8, -4, v0
	v_add_u32_e32 v9, -3, v0
	v_add_u32_e32 v10, -2, v0
	v_add_u32_e32 v11, -1, v0
.LBB1_192:                              ; =>This Inner Loop Header: Depth=1
	v_max_u32_e32 v12, v7, v6
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s22, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s22, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	v_max_u32_e32 v12, v7, v6
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v2, v3, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v13, s5
	v_readlane_b32 s5, v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s2, v11
	v_mov_b32_e32 v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v14, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v4, v4, v13, vcc
	s_nop 0
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s22, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s22, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	v_max_u32_e32 v12, v7, v6
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v2, v3, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v13, s5
	v_readlane_b32 s5, v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s2, v10
	v_mov_b32_e32 v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v14, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v4, v4, v13, vcc
	s_nop 0
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s22, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s22, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	v_max_u32_e32 v12, v7, v6
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v14, v2, v3, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mov_b32_e32 v13, s5
	v_readlane_b32 s5, v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cmp_eq_u32_e32 vcc, s2, v9
	v_mov_b32_e32 v14, s5
	v_max_u32_dpp v12, v12, v12 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v14, vcc
	v_max_u32_dpp v12, v12, v12 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_cndmask_b32_e32 v4, v4, v13, vcc
	s_nop 0
	v_max_u32_dpp v12, v12, v12 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v12, v12, v12 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s5, v12, 63
	s_andn2_b32 s22, 0x7f, s5
	s_cmp_lg_u32 s5, 0
	v_cmp_ne_u32_e32 vcc, s5, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s5, v7
	s_cselect_b32 s5, s22, 0
	s_cmp_gt_u32 s5, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v13, v2, v3, vcc
	v_mov_b32_e32 v12, s5
	v_readlane_b32 s5, v13, s5
	v_cmp_eq_u32_e32 vcc, s2, v8
	s_add_i32 s2, s2, 4
	v_mov_b32_e32 v13, s5
	v_add_f32_e32 v1, s5, v1
	v_cndmask_b32_e32 v5, v5, v13, vcc
	s_cmp_eq_u32 s3, s2
	v_cndmask_b32_e32 v4, v4, v12, vcc
	s_cbranch_scc0 .LBB1_192
; %bb.193:
	s_add_i32 s5, s2, 1
	s_cmp_lg_u32 s4, 0
	s_cselect_b64 s[2:3], -1, 0
	s_branch .LBB1_196
.LBB1_194:
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v5, 0
	s_branch .LBB1_199
.LBB1_195:
	s_mov_b64 s[2:3], -1
	s_mov_b32 s5, 1
.LBB1_196:                              ; %Flow880
	s_and_b64 vcc, exec, s[2:3]
	s_cbranch_vccz .LBB1_199
; %bb.197:
	v_subrev_u32_e32 v8, s5, v0
.LBB1_198:                              ; =>This Inner Loop Header: Depth=1
	v_max_u32_e32 v9, v7, v6
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:1 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:2 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_shr:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_bcast:15 row_mask:0xa bank_mask:0xf
	s_nop 1
	v_max_u32_dpp v9, v9, v9 row_bcast:31 row_mask:0xc bank_mask:0xf
	s_nop 0
	v_readlane_b32 s2, v9, 63
	s_andn2_b32 s3, 0x7f, s2
	s_cmp_lg_u32 s2, 0
	v_cmp_ne_u32_e32 vcc, s2, v6
	s_nop 1
	v_cndmask_b32_e32 v6, 0, v6, vcc
	v_cmp_ne_u32_e32 vcc, s2, v7
	s_cselect_b32 s2, s3, 0
	s_cmp_gt_u32 s2, 63
	v_cndmask_b32_e32 v7, 0, v7, vcc
	s_cselect_b64 vcc, -1, 0
	v_cndmask_b32_e32 v10, v2, v3, vcc
	v_mov_b32_e32 v9, s2
	v_readlane_b32 s2, v10, s2
	s_add_i32 s4, s4, -1
	v_subrev_co_u32_e32 v8, vcc, 1, v8
	v_mov_b32_e32 v10, s2
	s_cmp_lg_u32 s4, 0
	v_add_f32_e32 v1, s2, v1
	v_cndmask_b32_e32 v5, v5, v10, vcc
	v_cndmask_b32_e32 v4, v4, v9, vcc
	s_cbranch_scc1 .LBB1_198
.LBB1_199:
	v_cmp_gt_i32_e32 vcc, s26, v0
	s_and_b64 exec, exec, vcc
	s_cbranch_execz .LBB1_201
; %bb.200:
	v_div_scale_f32 v2, s[2:3], v1, v1, v5
	v_rcp_f32_e32 v3, v2
	v_div_scale_f32 v6, vcc, v5, v1, v5
	s_cmp_eq_u32 s15, 3
	v_fma_f32 v7, -v2, v3, 1.0
	v_fmac_f32_e32 v3, v7, v3
	v_mul_f32_e32 v7, v6, v3
	v_fma_f32 v8, -v2, v7, v6
	v_fmac_f32_e32 v7, v8, v3
	v_fma_f32 v2, -v2, v7, v6
	v_div_fmas_f32 v2, v2, v3, v7
	v_div_fixup_f32 v1, v2, v1, v5
	s_cselect_b64 vcc, -1, 0
	v_lshl_add_u32 v2, v0, 2, s17
	v_cndmask_b32_e32 v1, v5, v1, vcc
	v_add_u32_e32 v2, 0x1000, v2
	ds_write2_b32 v2, v4, v1 offset1:16
.LBB1_201:                              ; %Flow883
	s_or_b64 exec, exec, s[20:21]
	s_lshl2_add_u32 s2, s16, s17
	v_mov_b32_e32 v1, s2
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b32 v1, v1 offset:4096
	s_waitcnt lgkmcnt(0)
	v_readfirstlane_b32 s20, v1
.LBB1_202:
	s_ashr_i32 s15, s30, 31
	s_lshr_b32 s2, s15, 29
	s_add_i32 s2, s30, s2
	s_ashr_i32 s21, s2, 3
	s_add_u32 s2, s0, 0x168
	v_cmp_le_i32_e32 vcc, s21, v0
	s_addc_u32 s3, s1, 0
                                        ; implicit-def: $sgpr5
                                        ; implicit-def: $sgpr4
	s_and_saveexec_b64 s[0:1], vcc
	s_xor_b64 s[0:1], exec, s[0:1]
	s_cbranch_execz .LBB1_204
; %bb.203:                              ; %._crit_edge
	s_load_dword s5, s[2:3], 0xc
	s_waitcnt lgkmcnt(0)
	s_and_b32 s4, s5, 0xffff
.LBB1_204:                              ; %Flow875
	s_or_saveexec_b64 s[0:1], s[0:1]
	v_mov_b32_e32 v4, s5
	v_mov_b32_e32 v1, s4
	s_xor_b64 exec, exec, s[0:1]
	s_cbranch_execz .LBB1_208
; %bb.205:
	s_load_dword s22, s[2:3], 0xc
	v_mov_b32_e32 v1, 0
	v_lshl_add_u64 v[2:3], v[0:1], 4, s[10:11]
	v_lshlrev_b32_e32 v4, 5, v0
	v_lshl_add_u64 v[2:3], v[2:3], 0, 8
	s_waitcnt lgkmcnt(0)
	s_and_b32 s10, s22, 0xffff
	s_lshl_b32 s11, s10, 5
	s_lshl_b32 s2, s10, 4
	s_mov_b32 s3, 0
	s_mov_b64 s[4:5], 0
	v_mov_b32_e32 v1, v0
.LBB1_206:                              ; =>This Inner Loop Header: Depth=1
	global_load_dwordx2 v[10:11], v[2:3], off offset:-8 sc0 sc1
	global_load_dwordx2 v[14:15], v[2:3], off sc0 sc1
	v_add_u32_e32 v1, s10, v1
	v_cmp_le_i32_e32 vcc, s21, v1
	v_lshl_add_u64 v[2:3], v[2:3], 0, s[2:3]
	s_or_b64 s[4:5], vcc, s[4:5]
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v7, 0xffff0000, v10
	v_lshlrev_b32_e32 v6, 16, v10
	v_and_b32_e32 v9, 0xffff0000, v11
	v_lshlrev_b32_e32 v8, 16, v11
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v11, 0xffff0000, v14
	v_lshlrev_b32_e32 v10, 16, v14
	v_and_b32_e32 v13, 0xffff0000, v15
	v_lshlrev_b32_e32 v12, 16, v15
	ds_write_b128 v4, v[6:9]
	ds_write_b128 v4, v[10:13] offset:16
	v_add_u32_e32 v4, s11, v4
	s_andn2_b64 exec, exec, s[4:5]
	s_cbranch_execnz .LBB1_206
; %bb.207:                              ; %Flow874
	s_or_b64 exec, exec, s[4:5]
	v_mov_b32_e32 v4, s22
	v_mov_b32_e32 v1, s10
.LBB1_208:                              ; %Flow876
	s_or_b64 exec, exec, s[0:1]
	v_lshrrev_b32_e32 v28, 6, v1
	s_ashr_i32 s0, s20, 31
	v_cvt_f32_u32_e32 v2, v28
	s_mul_hi_u32 s1, s6, s20
	s_mul_i32 s0, s6, s0
	s_add_i32 s0, s1, s0
	s_mul_i32 s1, s7, s20
	s_add_i32 s1, s0, s1
	s_mul_i32 s0, s6, s20
	s_lshl_b64 s[0:1], s[0:1], 1
	v_rcp_f32_e32 v2, v2
	s_add_u32 s37, s8, s0
	s_addc_u32 s38, s9, s1
	s_lshr_b32 s0, s15, 23
	s_sub_i32 s35, s13, s31
	s_add_i32 s0, s30, s0
	s_ashr_i32 s36, s0, 9
	s_lshl_b32 s39, s35, 1
	v_mul_f32_e32 v2, 0x4f7ffffe, v2
	s_mul_i32 s0, s39, s36
	v_add_u32_e32 v29, -1, v28
	v_cvt_u32_f32_e32 v2, v2
	v_add_u32_e32 v5, s0, v29
	v_sub_u32_e32 v3, 0, v5
	v_max_i32_e32 v6, v3, v5
	v_sub_u32_e32 v3, 0, v28
	v_mul_lo_u32 v3, v3, v2
	v_mul_hi_u32 v3, v2, v3
	v_add_u32_e32 v14, v2, v3
	s_and_b32 s0, s30, 0x1ff
	v_mad_u64_u32 v[2:3], s[0:1], v6, v14, 0
	s_cselect_b64 s[20:21], -1, 0
	s_cmp_gt_i32 s35, 32
	s_cselect_b64 s[0:1], -1, 0
	s_or_b64 s[0:1], s[20:21], s[0:1]
	s_mov_b64 s[22:23], 0
	s_and_b64 vcc, exec, s[0:1]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cbranch_vccnz .LBB1_214
; %bb.209:
	s_mul_i32 s10, s35, s36
	v_add_u32_e32 v2, s10, v29
	v_sub_u32_e32 v8, 0, v2
	v_ashrrev_i32_e32 v7, 31, v2
	v_max_i32_e32 v2, v8, v2
	v_mul_hi_u32 v8, v2, v14
	v_mul_lo_u32 v9, v8, v28
	v_sub_u32_e32 v2, v2, v9
	v_add_u32_e32 v9, 1, v8
	v_cmp_ge_u32_e32 vcc, v2, v28
	s_abs_i32 s4, s36
	s_sub_i32 s0, 0, s4
	v_cndmask_b32_e32 v8, v8, v9, vcc
	v_sub_u32_e32 v9, v2, v28
	v_cndmask_b32_e32 v2, v2, v9, vcc
	v_cvt_f32_u32_e32 v9, s4
	v_add_u32_e32 v10, 1, v8
	v_cmp_ge_u32_e32 vcc, v2, v28
	s_nop 1
	v_cndmask_b32_e32 v2, v8, v10, vcc
	v_rcp_f32_e32 v8, v9
	v_xor_b32_e32 v2, v2, v7
	v_sub_u32_e32 v2, v2, v7
	v_ashrrev_i32_e32 v9, 31, v2
	v_mul_f32_e32 v7, 0x4f7ffffe, v8
	v_cvt_u32_f32_e32 v7, v7
	v_sub_u32_e32 v8, 0, v2
	v_max_i32_e32 v2, v8, v2
	v_mul_lo_u32 v8, s0, v7
	v_mul_hi_u32 v8, v7, v8
	v_add_u32_e32 v7, v7, v8
	v_mul_hi_u32 v8, v2, v7
	v_mul_lo_u32 v8, v8, s4
	v_sub_u32_e32 v2, v2, v8
	v_subrev_u32_e32 v8, s4, v2
	v_cmp_le_u32_e32 vcc, s4, v2
	s_nop 1
	v_cndmask_b32_e32 v2, v2, v8, vcc
	v_subrev_u32_e32 v8, s4, v2
	v_cmp_le_u32_e32 vcc, s4, v2
	s_nop 1
	v_cndmask_b32_e32 v2, v2, v8, vcc
	v_xor_b32_e32 v2, v2, v9
	v_sub_u32_e32 v2, v2, v9
	v_cmp_ne_u32_e64 s[0:1], 0, v2
	v_cmp_eq_u32_e32 vcc, 0, v2
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB1_213
; %bb.210:
	v_ashrrev_i32_e32 v2, 31, v5
	v_mul_lo_u32 v5, v3, v28
	v_sub_u32_e32 v5, v6, v5
	v_add_u32_e32 v6, 1, v3
	v_cmp_ge_u32_e32 vcc, v5, v28
	s_mov_b64 s[6:7], 0
	s_nop 0
	v_cndmask_b32_e32 v3, v3, v6, vcc
	v_sub_u32_e32 v6, v5, v28
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_add_u32_e32 v6, 1, v3
	v_cmp_ge_u32_e32 vcc, v5, v28
	s_nop 1
	v_cndmask_b32_e32 v3, v3, v6, vcc
	v_xor_b32_e32 v3, v3, v2
	v_sub_u32_e32 v2, v3, v2
	v_sub_u32_e32 v5, 0, v2
	v_ashrrev_i32_e32 v3, 31, v2
	v_max_i32_e32 v2, v5, v2
	v_mul_hi_u32 v5, v2, v7
	v_mul_lo_u32 v5, v5, s4
	v_sub_u32_e32 v5, v2, v5
	v_subrev_u32_e32 v6, s4, v5
	v_cmp_le_u32_e32 vcc, s4, v5
	s_nop 1
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_subrev_u32_e32 v6, s4, v5
	v_cmp_le_u32_e32 vcc, s4, v5
	s_nop 1
	v_cndmask_b32_e32 v5, v5, v6, vcc
	v_xor_b32_e32 v5, v5, v3
	v_sub_u32_e32 v3, v5, v3
	v_cmp_ne_u32_e64 s[4:5], 0, v3
	v_cmp_eq_u32_e32 vcc, 0, v3
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB1_212
; %bb.211:
	v_cvt_f32_u32_e32 v3, v2
	v_sub_u32_e32 v5, 0, v2
	s_ashr_i32 s11, s10, 31
	s_abs_i32 s10, s10
	v_rcp_f32_e32 v3, v3
	s_andn2_b64 s[4:5], s[4:5], exec
	s_mov_b64 s[6:7], exec
	v_mul_f32_e32 v3, 0x4f7ffffe, v3
	v_cvt_u32_f32_e32 v3, v3
	v_mul_lo_u32 v5, v5, v3
	v_mul_hi_u32 v5, v3, v5
	v_add_u32_e32 v3, v3, v5
	v_mul_hi_u32 v3, s10, v3
	v_mul_lo_u32 v3, v3, v2
	v_sub_u32_e32 v3, s10, v3
	v_sub_u32_e32 v5, v3, v2
	v_cmp_ge_u32_e32 vcc, v3, v2
	s_nop 1
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_sub_u32_e32 v5, v3, v2
	v_cmp_ge_u32_e32 vcc, v3, v2
	s_nop 1
	v_cndmask_b32_e32 v2, v3, v5, vcc
	v_xor_b32_e32 v2, s11, v2
	v_subrev_u32_e32 v2, s11, v2
	v_cmp_ne_u32_e32 vcc, 0, v2
	s_and_b64 s[10:11], vcc, exec
	s_or_b64 s[4:5], s[4:5], s[10:11]
.LBB1_212:                              ; %Flow871
	s_or_b64 exec, exec, s[8:9]
	s_andn2_b64 s[0:1], s[0:1], exec
	s_and_b64 s[4:5], s[4:5], exec
	s_and_b64 s[22:23], s[6:7], exec
	s_or_b64 s[0:1], s[0:1], s[4:5]
.LBB1_213:                              ; %Flow870
	s_or_b64 exec, exec, s[2:3]
.LBB1_214:                              ; %Flow869
	s_and_saveexec_b64 s[24:25], s[0:1]
	s_cbranch_execz .LBB1_448
; %bb.215:
	s_lshr_b32 s2, s15, 24
	s_add_i32 s2, s30, s2
	v_lshlrev_b32_e32 v2, 2, v0
	s_ashr_i32 s40, s2, 8
	v_and_b32_e32 v3, 0xfc, v2
	s_abs_i32 s41, s40
	v_xor_b32_e32 v17, 0x80, v3
	v_cvt_f32_u32_e32 v3, s41
	s_lshl2_add_u32 s6, s30, s34
	v_add_u32_e32 v33, s6, v2
	s_sub_i32 s46, 0, s41
	v_rcp_f32_e32 v35, v3
	v_and_b32_e32 v16, 63, v0
	v_lshlrev_b32_e32 v15, 4, v16
	v_bfe_u32 v31, v1, 6, 3
	v_mul_f32_e32 v2, 0x4f7ffffe, v35
	v_cvt_u32_f32_e32 v2, v2
	s_movk_i32 s2, 0x1ff
	v_mov_b32_e32 v11, 0
	v_cmp_eq_u32_e64 s[0:1], 0, v16
	v_mul_lo_u32 v3, s46, v2
	v_mul_hi_u32 v3, v2, v3
	v_add_u32_e32 v30, v15, v15
	v_cmp_lt_u16_e64 s[2:3], s2, v4
	v_and_b32_e32 v32, 0x3f8, v28
	v_cmp_ne_u32_e64 s[4:5], 0, v31
	v_lshlrev_b32_e32 v34, 2, v1
	s_movk_i32 s15, 0x7fff
	v_add_u32_e32 v36, v2, v3
	v_lshlrev_b32_e32 v18, 3, v16
	s_mov_b32 s43, s31
                                        ; implicit-def: $vgpr2_vgpr3_vgpr4_vgpr5
                                        ; implicit-def: $vgpr42_vgpr43
                                        ; implicit-def: $vgpr44_vgpr45
                                        ; implicit-def: $vgpr46_vgpr47
	s_branch .LBB1_217
.LBB1_216:                              ; %Flow835
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cmp_lt_i32 s42, s13
	s_mov_b32 s43, s42
	s_cbranch_scc0 .LBB1_331
.LBB1_217:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_220 Depth 2
                                        ;     Child Loop BB1_225 Depth 2
                                        ;     Child Loop BB1_277 Depth 2
                                        ;       Child Loop BB1_279 Depth 3
                                        ;       Child Loop BB1_283 Depth 3
                                        ;     Child Loop BB1_289 Depth 2
                                        ;     Child Loop BB1_294 Depth 2
                                        ;     Child Loop BB1_323 Depth 2
                                        ;       Child Loop BB1_325 Depth 3
                                        ;       Child Loop BB1_329 Depth 3
	s_add_i32 s42, s43, 64
	s_min_i32 s44, s13, s42
	s_mov_b64 s[6:7], -1
	s_and_b64 vcc, exec, s[20:21]
                                        ; implicit-def: $vgpr12_vgpr13
                                        ; implicit-def: $vgpr8_vgpr9
                                        ; implicit-def: $vgpr6_vgpr7
	s_cbranch_vccz .LBB1_286
; %bb.218:                              ;   in Loop: Header=BB1_217 Depth=1
	s_sub_i32 s45, s44, s43
	v_mul_lo_u32 v6, s45, v28
	v_readfirstlane_b32 s10, v0
	v_cmp_lt_i32_e32 vcc, v0, v6
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_221
; %bb.219:                              ; %.preheader338
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v7, v33
	v_mov_b32_e32 v8, v0
.LBB1_220:                              ;   Parent Loop BB1_217 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v8, v8, v1
	v_cmp_ge_i32_e32 vcc, v8, v6
	ds_write_b32 v7, v11
	s_or_b64 s[8:9], vcc, s[8:9]
	v_add_u32_e32 v7, v7, v34
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB1_220
.LBB1_221:                              ; %Flow830
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mul_i32 s6, s45, s40
	v_add_u32_e32 v6, s6, v29
	v_sub_u32_e32 v8, 0, v6
	v_ashrrev_i32_e32 v7, 31, v6
	v_max_i32_e32 v6, v8, v6
	v_mul_hi_u32 v8, v6, v14
	v_mul_lo_u32 v9, v8, v28
	v_sub_u32_e32 v6, v6, v9
	v_add_u32_e32 v9, 1, v8
	v_cmp_ge_u32_e32 vcc, v6, v28
	s_lshr_b32 s47, s10, 6
	s_mul_hi_i32 s7, s43, s30
	v_cndmask_b32_e32 v8, v8, v9, vcc
	v_sub_u32_e32 v9, v6, v28
	v_cndmask_b32_e32 v6, v6, v9, vcc
	v_add_u32_e32 v9, 1, v8
	v_cmp_ge_u32_e32 vcc, v6, v28
	v_mov_b32_e32 v39, 0
	v_mov_b64_e32 v[12:13], v[46:47]
	v_cndmask_b32_e32 v6, v8, v9, vcc
	v_xor_b32_e32 v6, v6, v7
	v_sub_u32_e32 v6, v6, v7
	v_mul_lo_u32 v10, s47, v6
	v_sub_u32_e32 v7, 0, v10
	v_max_i32_e32 v7, v7, v10
	v_mul_hi_u32 v8, v7, v36
	v_mul_lo_u32 v9, v8, s41
	v_sub_u32_e32 v7, v7, v9
	v_add_u32_e32 v9, 1, v8
	v_cmp_le_u32_e32 vcc, s41, v7
	v_add_u32_e32 v6, v10, v6
	v_min_i32_e32 v37, s6, v6
	v_cndmask_b32_e32 v8, v8, v9, vcc
	v_subrev_u32_e32 v9, s41, v7
	v_cndmask_b32_e32 v7, v7, v9, vcc
	v_xor_b32_e32 v6, s40, v10
	v_add_u32_e32 v9, 1, v8
	v_cmp_le_u32_e32 vcc, s41, v7
	v_ashrrev_i32_e32 v6, 31, v6
	s_mul_i32 s6, s43, s30
	v_cndmask_b32_e32 v7, v8, v9, vcc
	v_xor_b32_e32 v7, v7, v6
	v_sub_u32_e32 v40, v7, v6
	s_lshl_b64 s[6:7], s[6:7], 1
	v_mul_lo_u32 v6, v40, s40
	s_add_u32 s8, s37, s6
	v_sub_u32_e32 v41, v10, v6
	v_add_u32_e32 v6, 4, v10
	s_addc_u32 s9, s38, s7
	v_cmp_le_i32_e32 vcc, v6, v37
	v_mov_b32_e32 v24, v10
	v_mov_b32_e32 v38, v40
	v_mov_b64_e32 v[8:9], v[44:45]
	v_mov_b64_e32 v[6:7], v[42:43]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_240
; %bb.222:                              ;   in Loop: Header=BB1_217 Depth=1
	v_mov_b32_e32 v19, v11
	s_mul_i32 s6, s47, s45
	v_lshl_add_u64 v[20:21], s[8:9], 0, v[18:19]
	s_lshl2_add_u32 s48, s6, s17
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v39, 0
	v_mov_b32_e32 v22, v10
	v_mov_b32_e32 v38, v40
	s_branch .LBB1_225
.LBB1_223:                              ; %Flow818
                                        ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v38, v19
.LBB1_224:                              ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_cndmask_b32_e64 v50, v24, 0, vcc
	v_lshl_or_b32 v24, v50, 10, v15
	ds_read_b128 v[24:27], v24
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v49, 0xffff0000, v12
	v_lshlrev_b32_e32 v48, 16, v12
	v_and_b32_e32 v41, 0xffff0000, v13
	v_lshlrev_b32_e32 v40, 16, v13
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[24:25], v[48:49]
	v_pk_mul_f32 v[26:27], v[26:27], v[40:41]
	v_add_f32_e32 v24, v24, v25
	v_add_f32_e32 v24, v24, v26
	v_add_f32_e32 v24, v24, v27
	v_add_f32_e32 v39, v23, v24
	v_add_u32_e32 v23, 1, v50
	v_cmp_eq_u32_e32 vcc, s40, v23
	v_add_u32_e32 v24, 4, v22
	s_nop 0
	v_cndmask_b32_e64 v41, v23, 0, vcc
	v_addc_co_u32_e32 v40, vcc, 0, v19, vcc
	v_add_u32_e32 v19, 8, v22
	v_cmp_gt_i32_e32 vcc, v19, v37
	s_or_b64 s[26:27], vcc, s[26:27]
	v_mov_b32_e32 v22, v24
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execz .LBB1_258
.LBB1_225:                              ;   Parent Loop BB1_217 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_ashrrev_i32_e32 v23, 31, v22
	v_lshlrev_b64 v[6:7], 9, v[22:23]
	v_lshl_add_u64 v[26:27], v[20:21], 0, v[6:7]
	v_add_u32_e32 v6, 1, v22
	v_ashrrev_i32_e32 v7, 31, v6
	v_lshlrev_b64 v[6:7], 9, v[6:7]
	v_lshl_add_u64 v[48:49], v[20:21], 0, v[6:7]
	v_add_u32_e32 v6, 2, v22
	v_ashrrev_i32_e32 v7, 31, v6
	v_lshlrev_b64 v[6:7], 9, v[6:7]
	v_lshl_add_u64 v[50:51], v[20:21], 0, v[6:7]
	v_add_u32_e32 v6, 3, v22
	v_ashrrev_i32_e32 v7, 31, v6
	v_lshlrev_b64 v[6:7], 9, v[6:7]
	v_lshl_add_u64 v[52:53], v[20:21], 0, v[6:7]
	global_load_dwordx2 v[24:25], v[26:27], off nt
	global_load_dwordx2 v[6:7], v[48:49], off nt
	global_load_dwordx2 v[8:9], v[50:51], off nt
	global_load_dwordx2 v[12:13], v[52:53], off nt
	v_cmp_ne_u32_e32 vcc, v40, v38
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_229
; %bb.226:                              ;   in Loop: Header=BB1_225 Depth=2
	ds_bpermute_b32 v19, v17, v39
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v39, v19
	ds_swizzle_b32 v23, v19 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v23
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_add_f32_dpp v19, v19, v19 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v23, v19 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_228
; %bb.227:                              ;   in Loop: Header=BB1_225 Depth=2
	v_lshl_add_u32 v26, v38, 2, s48
	ds_read_b32 v27, v26
	v_add_f32_e32 v19, v19, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v27
	ds_write_b32 v26, v19
.LBB1_228:                              ; %Flow823
                                        ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v39, 0
.LBB1_229:                              ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_lshl_or_b32 v19, v41, 10, v15
	ds_read_b128 v[48:51], v19
	s_waitcnt vmcnt(3)
	v_and_b32_e32 v27, 0xffff0000, v25
	v_lshlrev_b32_e32 v26, 16, v25
	v_and_b32_e32 v25, 0xffff0000, v24
	v_lshlrev_b32_e32 v24, 16, v24
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[48:49], v[24:25]
	v_pk_mul_f32 v[26:27], v[50:51], v[26:27]
	v_add_f32_e32 v19, v24, v25
	v_add_f32_e32 v19, v19, v26
	v_add_u32_e32 v24, 1, v41
	v_add_f32_e32 v19, v19, v27
	v_cmp_eq_u32_e32 vcc, s40, v24
	v_add_f32_e32 v23, v39, v19
	s_nop 0
	v_addc_co_u32_e64 v19, s[6:7], 0, v40, vcc
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_233
; %bb.230:                              ;   in Loop: Header=BB1_225 Depth=2
	ds_bpermute_b32 v25, v17, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	ds_swizzle_b32 v25, v23 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v23, v23, v23 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_232
; %bb.231:                              ;   in Loop: Header=BB1_225 Depth=2
	v_lshl_add_u32 v26, v40, 2, s48
	ds_read_b32 v27, v26
	v_add_f32_e32 v23, v23, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v27
	ds_write_b32 v26, v23
.LBB1_232:                              ; %Flow822
                                        ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v40, v19
.LBB1_233:                              ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_cndmask_b32_e64 v41, v24, 0, vcc
	v_lshl_or_b32 v24, v41, 10, v15
	ds_read_b128 v[24:27], v24
	s_waitcnt vmcnt(2)
	v_and_b32_e32 v49, 0xffff0000, v6
	v_lshlrev_b32_e32 v48, 16, v6
	v_and_b32_e32 v39, 0xffff0000, v7
	v_lshlrev_b32_e32 v38, 16, v7
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[24:25], v[48:49]
	v_pk_mul_f32 v[26:27], v[26:27], v[38:39]
	v_add_f32_e32 v24, v24, v25
	v_add_f32_e32 v24, v24, v26
	v_add_f32_e32 v24, v24, v27
	v_add_f32_e32 v23, v23, v24
	v_add_u32_e32 v24, 1, v41
	v_cmp_eq_u32_e32 vcc, s40, v24
	s_nop 1
	v_addc_co_u32_e64 v19, s[6:7], 0, v19, vcc
	v_cmp_ne_u32_e64 s[6:7], v19, v40
	s_and_saveexec_b64 s[28:29], s[6:7]
	s_cbranch_execz .LBB1_237
; %bb.234:                              ;   in Loop: Header=BB1_225 Depth=2
	ds_bpermute_b32 v25, v17, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	ds_swizzle_b32 v25, v23 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v23, v23, v23 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_236
; %bb.235:                              ;   in Loop: Header=BB1_225 Depth=2
	v_lshl_add_u32 v26, v40, 2, s48
	ds_read_b32 v27, v26
	v_add_f32_e32 v23, v23, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v27
	ds_write_b32 v26, v23
.LBB1_236:                              ; %Flow820
                                        ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v40, v19
.LBB1_237:                              ;   in Loop: Header=BB1_225 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_cndmask_b32_e64 v41, v24, 0, vcc
	v_lshl_or_b32 v24, v41, 10, v15
	ds_read_b128 v[24:27], v24
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v49, 0xffff0000, v8
	v_lshlrev_b32_e32 v48, 16, v8
	v_and_b32_e32 v39, 0xffff0000, v9
	v_lshlrev_b32_e32 v38, 16, v9
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[24:25], v[48:49]
	v_pk_mul_f32 v[26:27], v[26:27], v[38:39]
	v_add_f32_e32 v24, v24, v25
	v_add_f32_e32 v24, v24, v26
	v_add_f32_e32 v24, v24, v27
	v_add_f32_e32 v23, v23, v24
	v_add_u32_e32 v24, 1, v41
	v_cmp_eq_u32_e32 vcc, s40, v24
	v_mov_b32_e32 v38, v40
	s_nop 0
	v_addc_co_u32_e64 v19, s[6:7], 0, v19, vcc
	v_cmp_ne_u32_e64 s[6:7], v19, v40
	s_and_saveexec_b64 s[28:29], s[6:7]
	s_cbranch_execz .LBB1_224
; %bb.238:                              ;   in Loop: Header=BB1_225 Depth=2
	ds_bpermute_b32 v25, v17, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	ds_swizzle_b32 v25, v23 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v23, v23, v23 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_223
; %bb.239:                              ;   in Loop: Header=BB1_225 Depth=2
	v_lshl_add_u32 v26, v40, 2, s48
	ds_read_b32 v27, v26
	v_add_f32_e32 v23, v23, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v27
	ds_write_b32 v26, v23
	s_branch .LBB1_223
.LBB1_240:                              ; %Flow827
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v24, v37
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execz .LBB1_259
.LBB1_241:                              ;   in Loop: Header=BB1_217 Depth=1
	v_mov_b32_e32 v19, v11
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshl_add_u64 v[22:23], s[8:9], 0, v[18:19]
	v_lshlrev_b64 v[20:21], 9, v[24:25]
	v_lshl_add_u64 v[20:21], v[22:23], 0, v[20:21]
	global_load_dwordx2 v[20:21], v[20:21], off nt
	v_add_u32_e32 v26, 1, v24
	v_cmp_lt_i32_e64 s[8:9], v26, v37
	s_and_saveexec_b64 s[6:7], s[8:9]
	s_cbranch_execz .LBB1_243
; %bb.242:                              ;   in Loop: Header=BB1_217 Depth=1
	v_ashrrev_i32_e32 v27, 31, v26
	v_lshlrev_b64 v[6:7], 9, v[26:27]
	v_lshl_add_u64 v[6:7], v[22:23], 0, v[6:7]
	global_load_dwordx2 v[6:7], v[6:7], off nt
.LBB1_243:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_add_u32_e32 v26, 2, v24
	v_cmp_lt_i32_e64 s[6:7], v26, v37
	s_and_saveexec_b64 s[10:11], s[6:7]
	s_cbranch_execz .LBB1_245
; %bb.244:                              ;   in Loop: Header=BB1_217 Depth=1
	v_ashrrev_i32_e32 v27, 31, v26
	v_lshlrev_b64 v[8:9], 9, v[26:27]
	v_lshl_add_u64 v[8:9], v[22:23], 0, v[8:9]
	global_load_dwordx2 v[8:9], v[8:9], off nt
.LBB1_245:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_add_u32_e32 v24, 3, v24
	v_cmp_lt_i32_e32 vcc, v24, v37
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_247
; %bb.246:                              ;   in Loop: Header=BB1_217 Depth=1
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshlrev_b64 v[12:13], 9, v[24:25]
	v_lshl_add_u64 v[12:13], v[22:23], 0, v[12:13]
	global_load_dwordx2 v[12:13], v[12:13], off nt
.LBB1_247:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	s_mul_i32 s10, s47, s45
	s_lshl2_add_u32 s48, s10, s17
	v_cmp_ne_u32_e64 s[10:11], v40, v38
	s_and_saveexec_b64 s[28:29], s[10:11]
	s_cbranch_execz .LBB1_251
; %bb.248:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v19, v17, v39
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v39, v19
	ds_swizzle_b32 v22, v19 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v19, v19, v19 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v19 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[10:11], s[0:1]
	s_cbranch_execz .LBB1_250
; %bb.249:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshl_add_u32 v23, v38, 2, s48
	ds_read_b32 v24, v23
	v_add_f32_e32 v19, v19, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v24
	ds_write_b32 v23, v19
.LBB1_250:                              ; %Flow815
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_mov_b32_e32 v39, 0
	v_mov_b32_e32 v38, v40
.LBB1_251:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[28:29]
	v_lshl_or_b32 v19, v41, 10, v15
	ds_read_b128 v[22:25], v19
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v27, 0xffff0000, v21
	v_lshlrev_b32_e32 v26, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v20
	v_lshlrev_b32_e32 v20, 16, v20
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[22:23], v[20:21]
	v_pk_mul_f32 v[24:25], v[24:25], v[26:27]
	v_add_f32_e32 v19, v20, v21
	v_add_f32_e32 v19, v19, v24
	v_add_f32_e32 v19, v19, v25
	v_add_f32_e32 v39, v39, v19
	v_add_u32_e32 v19, 1, v41
	v_cmp_eq_u32_e64 s[10:11], s40, v19
	s_nop 1
	v_cndmask_b32_e64 v19, v19, 0, s[10:11]
	v_addc_co_u32_e64 v20, s[10:11], 0, v40, s[10:11]
	s_and_saveexec_b64 s[10:11], s[8:9]
	s_cbranch_execz .LBB1_260
; %bb.252:                              ;   in Loop: Header=BB1_217 Depth=1
	v_cmp_ne_u32_e64 s[8:9], v20, v38
	s_and_saveexec_b64 s[28:29], s[8:9]
	s_cbranch_execz .LBB1_256
; %bb.253:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v21, v17, v39
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v39, v21
	ds_swizzle_b32 v22, v21 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v21, v21, v21 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[0:1]
	s_cbranch_execz .LBB1_255
; %bb.254:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshl_add_u32 v23, v38, 2, s48
	ds_read_b32 v24, v23
	v_add_f32_e32 v21, v21, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v24
	ds_write_b32 v23, v21
.LBB1_255:                              ; %Flow812
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mov_b32_e32 v39, 0
	v_mov_b32_e32 v38, v20
.LBB1_256:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[28:29]
	v_lshl_or_b32 v21, v19, 10, v15
	ds_read_b128 v[22:25], v21
	v_and_b32_e32 v41, 0xffff0000, v6
	v_lshlrev_b32_e32 v40, 16, v6
	v_and_b32_e32 v27, 0xffff0000, v7
	v_lshlrev_b32_e32 v26, 16, v7
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[40:41]
	v_pk_mul_f32 v[24:25], v[24:25], v[26:27]
	v_add_f32_e32 v21, v22, v23
	v_add_f32_e32 v21, v21, v24
	v_add_u32_e32 v19, 1, v19
	v_add_f32_e32 v21, v21, v25
	v_cmp_eq_u32_e64 s[8:9], s40, v19
	v_add_f32_e32 v39, v39, v21
	s_nop 0
	v_cndmask_b32_e64 v19, v19, 0, s[8:9]
	v_addc_co_u32_e64 v20, s[8:9], 0, v20, s[8:9]
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execnz .LBB1_261
.LBB1_257:                              ; %Flow811
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execnz .LBB1_266
	s_branch .LBB1_271
.LBB1_258:                              ; %Flow825
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[26:27]
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v24, v37
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execnz .LBB1_241
.LBB1_259:                              ; %Flow817
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[26:27]
	v_cmp_lt_i32_e32 vcc, v10, v37
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execnz .LBB1_272
	s_branch .LBB1_274
.LBB1_260:                              ; %Flow814
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execz .LBB1_257
.LBB1_261:                              ;   in Loop: Header=BB1_217 Depth=1
	v_cmp_ne_u32_e64 s[6:7], v20, v38
	s_and_saveexec_b64 s[10:11], s[6:7]
	s_cbranch_execz .LBB1_265
; %bb.262:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v21, v17, v39
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v39, v21
	ds_swizzle_b32 v22, v21 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v21, v21, v21 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_264
; %bb.263:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshl_add_u32 v23, v38, 2, s48
	ds_read_b32 v24, v23
	v_add_f32_e32 v21, v21, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v24
	ds_write_b32 v23, v21
.LBB1_264:                              ; %Flow809
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v39, 0
	v_mov_b32_e32 v38, v20
.LBB1_265:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_lshl_or_b32 v21, v19, 10, v15
	ds_read_b128 v[22:25], v21
	v_and_b32_e32 v41, 0xffff0000, v8
	v_lshlrev_b32_e32 v40, 16, v8
	v_and_b32_e32 v27, 0xffff0000, v9
	v_lshlrev_b32_e32 v26, 16, v9
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[40:41]
	v_pk_mul_f32 v[24:25], v[24:25], v[26:27]
	v_add_f32_e32 v21, v22, v23
	v_add_f32_e32 v21, v21, v24
	v_add_u32_e32 v19, 1, v19
	v_add_f32_e32 v21, v21, v25
	v_cmp_eq_u32_e64 s[6:7], s40, v19
	v_add_f32_e32 v39, v39, v21
	s_nop 0
	v_cndmask_b32_e64 v19, v19, 0, s[6:7]
	v_addc_co_u32_e64 v20, s[6:7], 0, v20, s[6:7]
	s_or_b64 exec, exec, s[8:9]
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_271
.LBB1_266:                              ;   in Loop: Header=BB1_217 Depth=1
	v_cmp_ne_u32_e32 vcc, v20, v38
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB1_270
; %bb.267:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v21, v17, v39
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v39, v21
	ds_swizzle_b32 v22, v21 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v21, v21, v21 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[10:11], s[0:1]
	s_cbranch_execz .LBB1_269
; %bb.268:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshl_add_u32 v23, v38, 2, s48
	ds_read_b32 v24, v23
	v_add_f32_e32 v21, v21, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v24
	ds_write_b32 v23, v21
.LBB1_269:                              ; %Flow806
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_mov_b32_e32 v39, 0
	v_mov_b32_e32 v38, v20
.LBB1_270:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_lshl_or_b32 v19, v19, 10, v15
	ds_read_b128 v[20:23], v19
	v_and_b32_e32 v27, 0xffff0000, v12
	v_lshlrev_b32_e32 v26, 16, v12
	v_and_b32_e32 v25, 0xffff0000, v13
	v_lshlrev_b32_e32 v24, 16, v13
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[20:21], v[26:27]
	v_pk_mul_f32 v[22:23], v[22:23], v[24:25]
	v_add_f32_e32 v19, v20, v21
	v_add_f32_e32 v19, v19, v22
	v_add_f32_e32 v19, v19, v23
	v_add_f32_e32 v39, v39, v19
.LBB1_271:                              ; %Flow808
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_or_b64 exec, exec, s[26:27]
	v_cmp_lt_i32_e32 vcc, v10, v37
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_274
.LBB1_272:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v10, v17, v39
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v39, v10
	ds_swizzle_b32 v19, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v19
	v_mov_b32_e32 v19, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v19, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_b64 exec, exec, s[0:1]
	s_cbranch_execz .LBB1_274
; %bb.273:                              ;   in Loop: Header=BB1_217 Depth=1
	s_mul_i32 s47, s47, s45
	s_lshl2_add_u32 s8, s47, s17
	v_lshl_add_u32 v20, v38, 2, s8
	ds_read_b32 v21, v20
	v_add_f32_e32 v10, v10, v19
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v21
	ds_write_b32 v20, v10
.LBB1_274:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_cmp_gt_i32_e32 vcc, s45, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_285
; %bb.275:                              ;   in Loop: Header=BB1_217 Depth=1
	s_sub_i32 s8, s43, s31
	s_lshl2_add_u32 s28, s8, s33
	s_lshl_b32 s29, s45, 2
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v10, v33
	v_mov_b32_e32 v19, v0
	s_branch .LBB1_277
.LBB1_276:                              ; %Flow801
                                        ;   in Loop: Header=BB1_277 Depth=2
	s_or_b64 exec, exec, s[10:11]
	v_bfe_u32 v20, v22, 16, 1
	v_add3_u32 v20, v20, v22, s15
	v_or_b32_e32 v21, 0x400000, v22
	v_cmp_u_f32_e32 vcc, v22, v22
	v_add_u32_e32 v10, v10, v34
	s_nop 0
	v_cndmask_b32_e32 v20, v20, v21, vcc
	v_lshl_add_u32 v21, v19, 2, s28
	v_add_u32_e32 v19, v19, v1
	v_cmp_le_i32_e32 vcc, s45, v19
	v_and_b32_e32 v20, 0xffff0000, v20
	s_or_b64 s[8:9], vcc, s[8:9]
	ds_write_b32 v21, v20
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB1_285
.LBB1_277:                              ;   Parent Loop BB1_217 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_279 Depth 3
                                        ;       Child Loop BB1_283 Depth 3
	s_mov_b64 s[26:27], -1
	v_mov_b32_e32 v22, 0
	v_mov_b32_e32 v20, 0
	s_and_saveexec_b64 s[10:11], s[2:3]
	s_cbranch_execz .LBB1_281
; %bb.278:                              ; %.preheader331
                                        ;   in Loop: Header=BB1_277 Depth=2
	v_lshl_add_u32 v20, v19, 2, s17
	s_mov_b32 s47, 0
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v22, 0
.LBB1_279:                              ;   Parent Loop BB1_217 Depth=1
                                        ;     Parent Loop BB1_277 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s48, s47, s45
	v_lshl_add_u32 v21, s48, 2, v20
	ds_read_b32 v23, v21
	v_add_u32_e32 v21, s29, v21
	v_add_u32_e32 v24, s29, v21
	ds_read_b32 v21, v21
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s29, v24
	v_add_u32_e32 v26, s29, v24
	ds_read_b32 v24, v24
	ds_read_b32 v27, v26
	v_add_u32_e32 v26, s29, v26
	v_add_u32_e32 v37, s29, v26
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v22, v22, v23
	ds_read_b32 v26, v26
	ds_read_b32 v38, v37
	v_add_u32_e32 v23, s29, v37
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v21, v22, v21
	ds_read_b32 v22, v23
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v21, v21, v25
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v21, v21, v24
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v21, v21, v27
	s_add_i32 s47, s47, 8
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v21, v21, v26
	v_cmp_eq_u32_e32 vcc, s47, v32
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v21, v21, v38
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v21, v22
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_279
; %bb.280:                              ;   in Loop: Header=BB1_277 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_orn2_b64 s[26:27], s[4:5], exec
	v_mov_b32_e32 v20, v32
.LBB1_281:                              ; %Flow800
                                        ;   in Loop: Header=BB1_277 Depth=2
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[10:11], s[26:27]
	s_cbranch_execz .LBB1_276
; %bb.282:                              ;   in Loop: Header=BB1_277 Depth=2
	v_mad_u64_u32 v[20:21], s[26:27], s29, v20, v[10:11]
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v21, v31
.LBB1_283:                              ;   Parent Loop BB1_217 Depth=1
                                        ;     Parent Loop BB1_277 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v23, v20
	v_add_u32_e32 v21, -1, v21
	v_cmp_eq_u32_e32 vcc, 0, v21
	v_add_u32_e32 v20, s29, v20
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_283
; %bb.284:                              ; %Flow799
                                        ;   in Loop: Header=BB1_277 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_branch .LBB1_276
.LBB1_285:                              ; %Flow804
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mov_b64 s[6:7], 0
	s_waitcnt lgkmcnt(0)
	s_barrier
.LBB1_286:                              ; %Flow847
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_and_b64 vcc, exec, s[6:7]
	s_cbranch_vccz .LBB1_301
; %bb.287:                              ;   in Loop: Header=BB1_217 Depth=1
	s_sub_i32 s44, s44, s43
	v_mul_lo_u32 v6, s44, v28
	v_readfirstlane_b32 s10, v0
	v_cmp_lt_i32_e32 vcc, v0, v6
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_290
; %bb.288:                              ; %.preheader334
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v7, v33
	v_mov_b32_e32 v8, v0
.LBB1_289:                              ;   Parent Loop BB1_217 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v8, v8, v1
	v_cmp_ge_i32_e32 vcc, v8, v6
	ds_write_b32 v7, v11
	s_or_b64 s[8:9], vcc, s[8:9]
	v_add_u32_e32 v7, v7, v34
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB1_289
.LBB1_290:                              ; %Flow846
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_lshr_b32 s45, s10, 6
	s_mul_i32 s10, s44, s36
	v_add_u32_e32 v6, s10, v29
	v_sub_u32_e32 v8, 0, v6
	v_ashrrev_i32_e32 v7, 31, v6
	v_max_i32_e32 v6, v8, v6
	v_mul_hi_u32 v8, v6, v14
	v_mul_lo_u32 v9, v8, v28
	v_sub_u32_e32 v6, v6, v9
	v_add_u32_e32 v9, 1, v8
	v_cmp_ge_u32_e32 vcc, v6, v28
	s_mul_hi_i32 s7, s43, s30
	s_mul_i32 s6, s43, s30
	v_cndmask_b32_e32 v8, v8, v9, vcc
	v_sub_u32_e32 v9, v6, v28
	v_cndmask_b32_e32 v6, v6, v9, vcc
	v_add_u32_e32 v9, 1, v8
	v_cmp_ge_u32_e32 vcc, v6, v28
	s_lshl_b64 s[6:7], s[6:7], 1
	s_add_u32 s8, s37, s6
	v_cndmask_b32_e32 v6, v8, v9, vcc
	v_xor_b32_e32 v6, v6, v7
	s_addc_u32 s9, s38, s7
	s_abs_i32 s6, s36
	v_sub_u32_e32 v6, v6, v7
	v_cvt_f32_u32_e32 v7, s6
	v_mul_lo_u32 v19, s45, v6
	v_add_u32_e32 v6, v19, v6
	v_min_i32_e32 v24, s10, v6
	v_rcp_f32_e32 v6, v7
	s_sub_i32 s7, 0, s6
	v_sub_u32_e32 v8, 0, v19
	v_max_i32_e32 v8, v8, v19
	v_mul_f32_e32 v6, 0x4f7ffffe, v6
	v_cvt_u32_f32_e32 v6, v6
	v_xor_b32_e32 v7, s36, v19
	v_ashrrev_i32_e32 v7, 31, v7
	v_mov_b32_e32 v26, 0
	v_mul_lo_u32 v9, s7, v6
	v_mul_hi_u32 v9, v6, v9
	v_add_u32_e32 v6, v6, v9
	v_mul_hi_u32 v6, v8, v6
	v_mul_lo_u32 v9, v6, s6
	v_sub_u32_e32 v8, v8, v9
	v_add_u32_e32 v9, 1, v6
	v_cmp_le_u32_e32 vcc, s6, v8
	v_mov_b32_e32 v22, v19
	s_waitcnt lgkmcnt(0)
	v_cndmask_b32_e32 v6, v6, v9, vcc
	v_subrev_u32_e32 v9, s6, v8
	v_cndmask_b32_e32 v8, v8, v9, vcc
	v_add_u32_e32 v9, 1, v6
	v_cmp_le_u32_e32 vcc, s6, v8
	s_barrier
	s_nop 0
	v_cndmask_b32_e32 v6, v6, v9, vcc
	v_xor_b32_e32 v6, v6, v7
	v_sub_u32_e32 v27, v6, v7
	v_mul_lo_u32 v6, v27, s36
	v_sub_u32_e32 v37, v19, v6
	v_add_u32_e32 v6, 2, v19
	v_cmp_le_i32_e32 vcc, v6, v24
	v_mov_b32_e32 v25, v27
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_302
; %bb.291:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshlrev_b32_e32 v10, 4, v16
	s_mul_i32 s6, s45, s44
	v_lshl_add_u64 v[12:13], s[8:9], 0, v[10:11]
	s_lshl2_add_u32 s47, s6, s17
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v20, v19
	v_mov_b32_e32 v25, v27
	s_branch .LBB1_294
.LBB1_292:                              ; %Flow841
                                        ;   in Loop: Header=BB1_294 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v7, 0
	v_mov_b32_e32 v25, v6
.LBB1_293:                              ;   in Loop: Header=BB1_294 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_cndmask_b32_e64 v10, v8, 0, vcc
	v_lshl_or_b32 v21, v10, 11, v30
	ds_read_b128 v[38:41], v21
	ds_read_b128 v[48:51], v21 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v53, 0xffff0000, v2
	v_lshlrev_b32_e32 v52, 16, v2
	v_and_b32_e32 v27, 0xffff0000, v3
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[38:39], v[38:39], v[52:53]
	v_lshlrev_b32_e32 v26, 16, v3
	v_add_f32_e32 v21, 0, v38
	v_pk_mul_f32 v[26:27], v[40:41], v[26:27]
	v_add_f32_e32 v21, v21, v39
	v_and_b32_e32 v23, 0xffff0000, v4
	v_lshlrev_b32_e32 v22, 16, v4
	v_add_f32_e32 v21, v21, v26
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[48:49], v[22:23]
	v_add_f32_e32 v21, v21, v27
	v_and_b32_e32 v9, 0xffff0000, v5
	v_lshlrev_b32_e32 v8, 16, v5
	v_add_f32_e32 v21, v21, v22
	v_pk_mul_f32 v[8:9], v[50:51], v[8:9]
	v_add_f32_e32 v21, v21, v23
	v_add_f32_e32 v8, v21, v8
	v_add_f32_e32 v8, v8, v9
	v_add_f32_e32 v26, v7, v8
	v_add_u32_e32 v7, 1, v10
	v_cmp_eq_u32_e32 vcc, s36, v7
	v_add_u32_e32 v22, 2, v20
	s_nop 0
	v_cndmask_b32_e64 v37, v7, 0, vcc
	v_addc_co_u32_e32 v27, vcc, 0, v6, vcc
	v_add_u32_e32 v6, 4, v20
	v_cmp_gt_i32_e32 vcc, v6, v24
	s_or_b64 s[26:27], vcc, s[26:27]
	v_mov_b32_e32 v20, v22
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execz .LBB1_316
.LBB1_294:                              ;   Parent Loop BB1_217 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[2:3], 10, v[20:21]
	v_lshl_add_u64 v[22:23], v[12:13], 0, v[2:3]
	v_add_u32_e32 v2, 1, v20
	v_ashrrev_i32_e32 v3, 31, v2
	v_lshlrev_b64 v[2:3], 10, v[2:3]
	v_lshl_add_u64 v[38:39], v[12:13], 0, v[2:3]
	global_load_dwordx4 v[6:9], v[22:23], off nt
	global_load_dwordx4 v[2:5], v[38:39], off nt
	v_cmp_ne_u32_e32 vcc, v27, v25
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_298
; %bb.295:                              ;   in Loop: Header=BB1_294 Depth=2
	ds_bpermute_b32 v10, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v26, v10
	ds_swizzle_b32 v21, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v21
	v_mov_b32_e32 v21, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v21, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_297
; %bb.296:                              ;   in Loop: Header=BB1_294 Depth=2
	v_lshl_add_u32 v22, v25, 2, s47
	ds_read_b32 v23, v22
	v_add_f32_e32 v10, v10, v21
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v23
	ds_write_b32 v22, v10
.LBB1_297:                              ; %Flow842
                                        ;   in Loop: Header=BB1_294 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v26, 0
.LBB1_298:                              ;   in Loop: Header=BB1_294 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_lshl_or_b32 v10, v37, 11, v30
	ds_read_b128 v[38:41], v10
	ds_read_b128 v[48:51], v10 offset:16
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v53, 0xffff0000, v7
	v_lshlrev_b32_e32 v52, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[38:39], v[6:7]
	v_pk_mul_f32 v[40:41], v[40:41], v[52:53]
	v_add_f32_e32 v6, 0, v6
	v_add_f32_e32 v6, v6, v7
	v_and_b32_e32 v23, 0xffff0000, v9
	v_lshlrev_b32_e32 v22, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v6, v6, v40
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[48:49], v[8:9]
	v_add_f32_e32 v6, v6, v41
	v_add_f32_e32 v6, v6, v8
	v_pk_mul_f32 v[22:23], v[50:51], v[22:23]
	v_add_f32_e32 v6, v6, v9
	v_add_f32_e32 v6, v6, v22
	v_add_u32_e32 v8, 1, v37
	v_add_f32_e32 v6, v6, v23
	v_cmp_eq_u32_e32 vcc, s36, v8
	v_add_f32_e32 v7, v26, v6
	v_mov_b32_e32 v25, v27
	v_addc_co_u32_e64 v6, s[6:7], 0, v27, vcc
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_293
; %bb.299:                              ;   in Loop: Header=BB1_294 Depth=2
	ds_bpermute_b32 v9, v17, v7
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v9
	ds_swizzle_b32 v9, v7 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v9
	v_mov_b32_e32 v9, 0
	s_nop 0
	v_add_f32_dpp v7, v7, v7 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v7, v7, v7 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v7, v7, v7 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v9, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_292
; %bb.300:                              ;   in Loop: Header=BB1_294 Depth=2
	v_lshl_add_u32 v10, v27, 2, s47
	ds_read_b32 v21, v10
	v_add_f32_e32 v7, v7, v9
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v21
	ds_write_b32 v10, v7
	s_branch .LBB1_292
.LBB1_301:                              ;   in Loop: Header=BB1_217 Depth=1
	v_mov_b64_e32 v[46:47], v[12:13]
	v_mov_b64_e32 v[44:45], v[8:9]
	v_mov_b64_e32 v[42:43], v[6:7]
	s_cmp_lt_i32 s42, s13
	s_mov_b32 s43, s42
	s_cbranch_scc1 .LBB1_217
	s_branch .LBB1_331
.LBB1_302:                              ; %Flow844
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v22, v24
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_317
.LBB1_303:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshlrev_b32_e32 v10, 4, v16
	v_ashrrev_i32_e32 v23, 31, v22
	v_lshl_add_u64 v[12:13], s[8:9], 0, v[10:11]
	v_lshlrev_b64 v[6:7], 10, v[22:23]
	v_lshl_add_u64 v[6:7], v[12:13], 0, v[6:7]
	global_load_dwordx4 v[6:9], v[6:7], off nt
	v_add_u32_e32 v20, 1, v22
	v_cmp_lt_i32_e32 vcc, v20, v24
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_305
; %bb.304:                              ;   in Loop: Header=BB1_217 Depth=1
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[2:3], 10, v[20:21]
	v_lshl_add_u64 v[2:3], v[12:13], 0, v[2:3]
	global_load_dwordx4 v[2:5], v[2:3], off nt
.LBB1_305:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mul_i32 s6, s45, s44
	s_lshl2_add_u32 s28, s6, s17
	v_cmp_ne_u32_e64 s[6:7], v27, v25
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execz .LBB1_309
; %bb.306:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v10, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v26, v10
	ds_swizzle_b32 v12, v10 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	v_mov_b32_e32 v12, 0
	s_nop 0
	v_add_f32_dpp v10, v10, v10 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v12, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_308
; %bb.307:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshl_add_u32 v13, v25, 2, s28
	ds_read_b32 v20, v13
	v_add_f32_e32 v10, v10, v12
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v20
	ds_write_b32 v13, v10
.LBB1_308:                              ; %Flow839
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v25, v27
.LBB1_309:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_lshl_or_b32 v10, v37, 11, v30
	ds_read_b128 v[20:23], v10
	ds_read_b128 v[38:41], v10 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v49, 0xffff0000, v7
	v_lshlrev_b32_e32 v48, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[20:21], v[6:7]
	v_pk_mul_f32 v[22:23], v[22:23], v[48:49]
	v_add_f32_e32 v6, 0, v6
	v_add_f32_e32 v6, v6, v7
	v_and_b32_e32 v13, 0xffff0000, v9
	v_lshlrev_b32_e32 v12, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v6, v6, v22
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[38:39], v[8:9]
	v_add_f32_e32 v6, v6, v23
	v_add_f32_e32 v6, v6, v8
	v_pk_mul_f32 v[12:13], v[40:41], v[12:13]
	v_add_f32_e32 v6, v6, v9
	v_add_f32_e32 v6, v6, v12
	v_add_f32_e32 v6, v6, v13
	v_add_f32_e32 v26, v26, v6
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB1_315
; %bb.310:                              ;   in Loop: Header=BB1_217 Depth=1
	v_add_u32_e32 v6, 1, v37
	v_cmp_eq_u32_e32 vcc, s36, v6
	s_nop 1
	v_addc_co_u32_e64 v7, s[6:7], 0, v27, vcc
	v_cmp_ne_u32_e64 s[6:7], v7, v25
	s_and_saveexec_b64 s[26:27], s[6:7]
	s_cbranch_execz .LBB1_314
; %bb.311:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v8, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v8, v26, v8
	ds_swizzle_b32 v9, v8 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v8, v8, v9
	v_mov_b32_e32 v9, 0
	s_nop 0
	v_add_f32_dpp v8, v8, v8 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v8, v8, v8 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v8, v8, v8 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v9, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_313
; %bb.312:                              ;   in Loop: Header=BB1_217 Depth=1
	v_lshl_add_u32 v10, v25, 2, s28
	ds_read_b32 v12, v10
	v_add_f32_e32 v8, v8, v9
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v8, v8, v12
	ds_write_b32 v10, v8
.LBB1_313:                              ; %Flow837
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v25, v7
.LBB1_314:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[26:27]
	v_lshlrev_b32_e32 v6, 11, v6
	v_cndmask_b32_e64 v6, v6, 0, vcc
	v_or_b32_e32 v10, v30, v6
	ds_read_b128 v[6:9], v10
	ds_read_b128 v[20:23], v10 offset:16
	v_and_b32_e32 v49, 0xffff0000, v2
	v_lshlrev_b32_e32 v48, 16, v2
	v_and_b32_e32 v41, 0xffff0000, v3
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[6:7], v[48:49]
	v_lshlrev_b32_e32 v40, 16, v3
	v_add_f32_e32 v6, 0, v6
	v_pk_mul_f32 v[8:9], v[8:9], v[40:41]
	v_add_f32_e32 v6, v6, v7
	v_and_b32_e32 v39, 0xffff0000, v4
	v_lshlrev_b32_e32 v38, 16, v4
	v_add_f32_e32 v6, v6, v8
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[20:21], v[38:39]
	v_add_f32_e32 v6, v6, v9
	v_and_b32_e32 v13, 0xffff0000, v5
	v_lshlrev_b32_e32 v12, 16, v5
	v_add_f32_e32 v6, v6, v20
	v_pk_mul_f32 v[12:13], v[22:23], v[12:13]
	v_add_f32_e32 v6, v6, v21
	v_add_f32_e32 v6, v6, v12
	v_add_f32_e32 v6, v6, v13
	v_add_f32_e32 v26, v26, v6
.LBB1_315:                              ; %Flow838
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v19, v24
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_320
	s_branch .LBB1_318
.LBB1_316:                              ; %Flow843
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[26:27]
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v22, v24
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execnz .LBB1_303
.LBB1_317:                              ; %Flow840
                                        ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v19, v24
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_320
.LBB1_318:                              ;   in Loop: Header=BB1_217 Depth=1
	ds_bpermute_b32 v6, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v6, v26, v6
	ds_swizzle_b32 v7, v6 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v6, v6, v7
	v_mov_b32_e32 v7, 0
	s_nop 0
	v_add_f32_dpp v6, v6, v6 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v6, v6, v6 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v6, v6, v6 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v7, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_b64 exec, exec, s[0:1]
	s_cbranch_execz .LBB1_320
; %bb.319:                              ;   in Loop: Header=BB1_217 Depth=1
	s_mul_i32 s45, s45, s44
	s_lshl2_add_u32 s8, s45, s17
	v_lshl_add_u32 v8, v25, 2, s8
	ds_read_b32 v9, v8
	v_add_f32_e32 v6, v6, v7
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v6, v6, v9
	ds_write_b32 v8, v6
.LBB1_320:                              ;   in Loop: Header=BB1_217 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_cmp_gt_i32_e32 vcc, s44, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_216
; %bb.321:                              ;   in Loop: Header=BB1_217 Depth=1
	s_sub_i32 s8, s43, s31
	s_lshl2_add_u32 s28, s8, s33
	s_lshl_b32 s29, s44, 2
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v6, v33
	v_mov_b32_e32 v7, v0
	s_branch .LBB1_323
.LBB1_322:                              ; %Flow833
                                        ;   in Loop: Header=BB1_323 Depth=2
	s_or_b64 exec, exec, s[10:11]
	v_bfe_u32 v8, v10, 16, 1
	v_add3_u32 v8, v8, v10, s15
	v_or_b32_e32 v9, 0x400000, v10
	v_cmp_u_f32_e32 vcc, v10, v10
	v_add_u32_e32 v6, v6, v34
	s_nop 0
	v_cndmask_b32_e32 v8, v8, v9, vcc
	v_lshl_add_u32 v9, v7, 2, s28
	v_add_u32_e32 v7, v7, v1
	v_cmp_le_i32_e32 vcc, s44, v7
	v_and_b32_e32 v8, 0xffff0000, v8
	s_or_b64 s[8:9], vcc, s[8:9]
	ds_write_b32 v9, v8
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB1_216
.LBB1_323:                              ;   Parent Loop BB1_217 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_325 Depth 3
                                        ;       Child Loop BB1_329 Depth 3
	s_mov_b64 s[26:27], -1
	v_mov_b32_e32 v10, 0
	v_mov_b32_e32 v8, 0
	s_and_saveexec_b64 s[10:11], s[2:3]
	s_cbranch_execz .LBB1_327
; %bb.324:                              ; %.preheader329
                                        ;   in Loop: Header=BB1_323 Depth=2
	v_lshl_add_u32 v8, v7, 2, s17
	s_mov_b32 s43, 0
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v10, 0
.LBB1_325:                              ;   Parent Loop BB1_217 Depth=1
                                        ;     Parent Loop BB1_323 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s45, s43, s44
	v_lshl_add_u32 v9, s45, 2, v8
	ds_read_b32 v12, v9
	v_add_u32_e32 v9, s29, v9
	v_add_u32_e32 v13, s29, v9
	ds_read_b32 v9, v9
	ds_read_b32 v19, v13
	v_add_u32_e32 v13, s29, v13
	v_add_u32_e32 v20, s29, v13
	ds_read_b32 v13, v13
	ds_read_b32 v21, v20
	v_add_u32_e32 v20, s29, v20
	v_add_u32_e32 v22, s29, v20
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v10, v10, v12
	ds_read_b32 v20, v20
	ds_read_b32 v23, v22
	v_add_u32_e32 v12, s29, v22
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v9, v10, v9
	ds_read_b32 v10, v12
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v9, v9, v19
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v9, v9, v13
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v9, v9, v21
	s_add_i32 s43, s43, 8
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v9, v9, v20
	v_cmp_eq_u32_e32 vcc, s43, v32
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v9, v9, v23
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v9, v10
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_325
; %bb.326:                              ;   in Loop: Header=BB1_323 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_orn2_b64 s[26:27], s[4:5], exec
	v_mov_b32_e32 v8, v32
.LBB1_327:                              ; %Flow832
                                        ;   in Loop: Header=BB1_323 Depth=2
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[10:11], s[26:27]
	s_cbranch_execz .LBB1_322
; %bb.328:                              ;   in Loop: Header=BB1_323 Depth=2
	v_mad_u64_u32 v[8:9], s[26:27], s29, v8, v[6:7]
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v9, v31
.LBB1_329:                              ;   Parent Loop BB1_217 Depth=1
                                        ;     Parent Loop BB1_323 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v12, v8
	v_add_u32_e32 v9, -1, v9
	v_cmp_eq_u32_e32 vcc, 0, v9
	v_add_u32_e32 v8, s29, v8
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v12
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_329
; %bb.330:                              ; %Flow831
                                        ;   in Loop: Header=BB1_323 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_branch .LBB1_322
.LBB1_331:
	v_mul_f32_e32 v2, 0x4f7ffffe, v35
	v_cvt_u32_f32_e32 v2, v2
	s_mul_hi_i32 s7, s30, s14
	s_mul_i32 s6, s30, s14
	s_ashr_i32 s15, s14, 31
	s_lshl_b64 s[6:7], s[6:7], 1
	s_add_u32 s42, s37, s6
	v_mov_b32_e32 v5, 0
	v_mul_lo_u32 v3, s46, v2
	s_addc_u32 s43, s38, s7
	s_sub_i32 s6, s12, s31
	v_mov_b32_e32 v4, v5
	v_mov_b32_e32 v6, v5
	v_mov_b32_e32 v7, v5
	v_mul_hi_u32 v3, v2, v3
	s_lshl2_add_u32 s44, s6, s33
	s_movk_i32 s45, 0x7fff
	v_add_u32_e32 v35, v2, v3
	s_mov_b32 s47, s31
	v_mov_b64_e32 v[12:13], v[6:7]
	v_mov_b64_e32 v[10:11], v[4:5]
	v_mov_b32_e32 v36, 0
	v_mov_b32_e32 v37, 0
	v_mov_b32_e32 v38, 0
	v_mov_b32_e32 v39, 0
	v_mov_b32_e32 v40, 0
	v_mov_b32_e32 v41, 0
	v_mov_b64_e32 v[8:9], v[2:3]
	v_mov_b64_e32 v[6:7], v[0:1]
	s_branch .LBB1_333
.LBB1_332:                              ;   in Loop: Header=BB1_333 Depth=1
	v_mov_b32_e32 v41, v7
	v_mov_b32_e32 v40, v6
	v_mov_b32_e32 v39, v9
	v_mov_b32_e32 v38, v8
	v_mov_b32_e32 v37, v3
	v_mov_b32_e32 v36, v2
	s_cmp_lt_i32 s46, s13
	s_mov_b32 s47, s46
	s_cbranch_scc0 .LBB1_447
.LBB1_333:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_336 Depth 2
                                        ;     Child Loop BB1_341 Depth 2
                                        ;     Child Loop BB1_393 Depth 2
                                        ;       Child Loop BB1_395 Depth 3
                                        ;       Child Loop BB1_399 Depth 3
                                        ;     Child Loop BB1_405 Depth 2
                                        ;     Child Loop BB1_410 Depth 2
                                        ;     Child Loop BB1_438 Depth 2
                                        ;       Child Loop BB1_440 Depth 3
                                        ;       Child Loop BB1_444 Depth 3
	s_add_i32 s46, s47, 64
	s_min_i32 s48, s13, s46
	s_mov_b64 s[6:7], -1
	s_and_b64 vcc, exec, s[20:21]
                                        ; implicit-def: $vgpr7
                                        ; implicit-def: $vgpr2_vgpr3
                                        ; implicit-def: $vgpr8_vgpr9
	s_cbranch_vccz .LBB1_402
; %bb.334:                              ;   in Loop: Header=BB1_333 Depth=1
	s_sub_i32 s49, s48, s47
	v_mul_lo_u32 v2, s49, v28
	v_readfirstlane_b32 s10, v0
	v_cmp_lt_i32_e32 vcc, v0, v2
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_337
; %bb.335:                              ; %.preheader325
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v3, v33
	v_mov_b32_e32 v4, v0
.LBB1_336:                              ;   Parent Loop BB1_333 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v4, v4, v1
	v_cmp_ge_i32_e32 vcc, v4, v2
	ds_write_b32 v3, v5
	s_or_b64 s[8:9], vcc, s[8:9]
	v_add_u32_e32 v3, v3, v34
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB1_336
.LBB1_337:                              ; %Flow771
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mul_i32 s6, s49, s40
	v_add_u32_e32 v2, s6, v29
	v_sub_u32_e32 v4, 0, v2
	v_ashrrev_i32_e32 v3, 31, v2
	v_max_i32_e32 v2, v4, v2
	v_mul_hi_u32 v4, v2, v14
	v_mul_lo_u32 v6, v4, v28
	v_sub_u32_e32 v2, v2, v6
	v_add_u32_e32 v6, 1, v4
	v_cmp_ge_u32_e32 vcc, v2, v28
	s_lshr_b32 s50, s10, 6
	s_mul_hi_i32 s7, s47, s30
	v_cndmask_b32_e32 v4, v4, v6, vcc
	v_sub_u32_e32 v6, v2, v28
	v_cndmask_b32_e32 v2, v2, v6, vcc
	v_add_u32_e32 v6, 1, v4
	v_cmp_ge_u32_e32 vcc, v2, v28
	v_mov_b32_e32 v44, 0
	v_mov_b32_e32 v9, v39
	v_cndmask_b32_e32 v2, v4, v6, vcc
	v_xor_b32_e32 v2, v2, v3
	v_sub_u32_e32 v2, v2, v3
	v_mul_lo_u32 v4, s50, v2
	v_sub_u32_e32 v3, 0, v4
	v_max_i32_e32 v3, v3, v4
	v_mul_hi_u32 v6, v3, v35
	v_mul_lo_u32 v7, v6, s41
	v_sub_u32_e32 v3, v3, v7
	v_add_u32_e32 v7, 1, v6
	v_cmp_le_u32_e32 vcc, s41, v3
	v_add_u32_e32 v2, v4, v2
	v_min_i32_e32 v42, s6, v2
	v_cndmask_b32_e32 v6, v6, v7, vcc
	v_subrev_u32_e32 v7, s41, v3
	v_cndmask_b32_e32 v3, v3, v7, vcc
	v_xor_b32_e32 v2, s40, v4
	v_add_u32_e32 v7, 1, v6
	v_cmp_le_u32_e32 vcc, s41, v3
	v_ashrrev_i32_e32 v2, 31, v2
	s_mul_i32 s6, s47, s30
	v_cndmask_b32_e32 v3, v6, v7, vcc
	v_xor_b32_e32 v3, v3, v2
	v_sub_u32_e32 v45, v3, v2
	s_lshl_b64 s[6:7], s[6:7], 1
	v_mul_lo_u32 v2, v45, s40
	s_add_u32 s8, s42, s6
	v_sub_u32_e32 v46, v4, v2
	v_add_u32_e32 v2, 4, v4
	s_addc_u32 s9, s43, s7
	v_cmp_le_i32_e32 vcc, v2, v42
	v_mov_b32_e32 v7, v41
	v_mov_b32_e32 v6, v40
	v_mov_b32_e32 v8, v38
	v_mov_b32_e32 v3, v37
	v_mov_b32_e32 v2, v36
	v_mov_b32_e32 v24, v4
	v_mov_b32_e32 v43, v45
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_356
; %bb.338:                              ;   in Loop: Header=BB1_333 Depth=1
	v_mov_b32_e32 v19, v5
	s_mul_i32 s6, s50, s49
	v_lshl_add_u64 v[20:21], s[8:9], 0, v[18:19]
	s_lshl2_add_u32 s51, s6, s17
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v44, 0
	v_mov_b32_e32 v22, v4
	v_mov_b32_e32 v43, v45
	s_branch .LBB1_341
.LBB1_339:                              ; %Flow760
                                        ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v43, v19
.LBB1_340:                              ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_cndmask_b32_e64 v48, v24, 0, vcc
	v_lshl_or_b32 v24, v48, 10, v15
	ds_read_b128 v[24:27], v24
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v47, 0xffff0000, v6
	v_lshlrev_b32_e32 v46, 16, v6
	v_and_b32_e32 v45, 0xffff0000, v7
	v_lshlrev_b32_e32 v44, 16, v7
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[24:25], v[46:47]
	v_pk_mul_f32 v[26:27], v[26:27], v[44:45]
	v_add_f32_e32 v24, v24, v25
	v_add_f32_e32 v24, v24, v26
	v_add_f32_e32 v24, v24, v27
	v_add_f32_e32 v44, v23, v24
	v_add_u32_e32 v23, 1, v48
	v_cmp_eq_u32_e32 vcc, s40, v23
	v_add_u32_e32 v24, 4, v22
	s_nop 0
	v_cndmask_b32_e64 v46, v23, 0, vcc
	v_addc_co_u32_e32 v45, vcc, 0, v19, vcc
	v_add_u32_e32 v19, 8, v22
	v_cmp_gt_i32_e32 vcc, v19, v42
	s_or_b64 s[26:27], vcc, s[26:27]
	v_mov_b32_e32 v22, v24
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execz .LBB1_374
.LBB1_341:                              ;   Parent Loop BB1_333 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_ashrrev_i32_e32 v23, 31, v22
	v_lshlrev_b64 v[2:3], 9, v[22:23]
	v_lshl_add_u64 v[26:27], v[20:21], 0, v[2:3]
	v_add_u32_e32 v2, 1, v22
	v_ashrrev_i32_e32 v3, 31, v2
	v_lshlrev_b64 v[2:3], 9, v[2:3]
	v_lshl_add_u64 v[48:49], v[20:21], 0, v[2:3]
	v_add_u32_e32 v2, 2, v22
	v_ashrrev_i32_e32 v3, 31, v2
	v_lshlrev_b64 v[2:3], 9, v[2:3]
	v_lshl_add_u64 v[50:51], v[20:21], 0, v[2:3]
	v_add_u32_e32 v2, 3, v22
	v_ashrrev_i32_e32 v3, 31, v2
	v_lshlrev_b64 v[2:3], 9, v[2:3]
	v_lshl_add_u64 v[52:53], v[20:21], 0, v[2:3]
	global_load_dwordx2 v[24:25], v[26:27], off nt
	global_load_dwordx2 v[2:3], v[48:49], off nt
	global_load_dwordx2 v[8:9], v[50:51], off nt
	global_load_dwordx2 v[6:7], v[52:53], off nt
	v_cmp_ne_u32_e32 vcc, v45, v43
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_345
; %bb.342:                              ;   in Loop: Header=BB1_341 Depth=2
	ds_bpermute_b32 v19, v17, v44
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v44, v19
	ds_swizzle_b32 v23, v19 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v23
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_add_f32_dpp v19, v19, v19 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v23, v19 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_344
; %bb.343:                              ;   in Loop: Header=BB1_341 Depth=2
	v_lshl_add_u32 v26, v43, 2, s51
	ds_read_b32 v27, v26
	v_add_f32_e32 v19, v19, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v27
	ds_write_b32 v26, v19
.LBB1_344:                              ; %Flow765
                                        ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v44, 0
.LBB1_345:                              ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_lshl_or_b32 v19, v46, 10, v15
	ds_read_b128 v[48:51], v19
	s_waitcnt vmcnt(3)
	v_and_b32_e32 v27, 0xffff0000, v25
	v_lshlrev_b32_e32 v26, 16, v25
	v_and_b32_e32 v25, 0xffff0000, v24
	v_lshlrev_b32_e32 v24, 16, v24
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[48:49], v[24:25]
	v_pk_mul_f32 v[26:27], v[50:51], v[26:27]
	v_add_f32_e32 v19, v24, v25
	v_add_f32_e32 v19, v19, v26
	v_add_u32_e32 v24, 1, v46
	v_add_f32_e32 v19, v19, v27
	v_cmp_eq_u32_e32 vcc, s40, v24
	v_add_f32_e32 v23, v44, v19
	s_nop 0
	v_addc_co_u32_e64 v19, s[6:7], 0, v45, vcc
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_349
; %bb.346:                              ;   in Loop: Header=BB1_341 Depth=2
	ds_bpermute_b32 v25, v17, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	ds_swizzle_b32 v25, v23 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v23, v23, v23 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_348
; %bb.347:                              ;   in Loop: Header=BB1_341 Depth=2
	v_lshl_add_u32 v26, v45, 2, s51
	ds_read_b32 v27, v26
	v_add_f32_e32 v23, v23, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v27
	ds_write_b32 v26, v23
.LBB1_348:                              ; %Flow764
                                        ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v45, v19
.LBB1_349:                              ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_cndmask_b32_e64 v43, v24, 0, vcc
	v_lshl_or_b32 v24, v43, 10, v15
	ds_read_b128 v[24:27], v24
	s_waitcnt vmcnt(2)
	v_and_b32_e32 v49, 0xffff0000, v2
	v_lshlrev_b32_e32 v48, 16, v2
	v_and_b32_e32 v47, 0xffff0000, v3
	v_lshlrev_b32_e32 v46, 16, v3
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[24:25], v[48:49]
	v_pk_mul_f32 v[26:27], v[26:27], v[46:47]
	v_add_f32_e32 v24, v24, v25
	v_add_f32_e32 v24, v24, v26
	v_add_f32_e32 v24, v24, v27
	v_add_f32_e32 v23, v23, v24
	v_add_u32_e32 v24, 1, v43
	v_cmp_eq_u32_e32 vcc, s40, v24
	s_nop 1
	v_addc_co_u32_e64 v19, s[6:7], 0, v19, vcc
	v_cmp_ne_u32_e64 s[6:7], v19, v45
	s_and_saveexec_b64 s[28:29], s[6:7]
	s_cbranch_execz .LBB1_353
; %bb.350:                              ;   in Loop: Header=BB1_341 Depth=2
	ds_bpermute_b32 v25, v17, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	ds_swizzle_b32 v25, v23 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v23, v23, v23 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_352
; %bb.351:                              ;   in Loop: Header=BB1_341 Depth=2
	v_lshl_add_u32 v26, v45, 2, s51
	ds_read_b32 v27, v26
	v_add_f32_e32 v23, v23, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v27
	ds_write_b32 v26, v23
.LBB1_352:                              ; %Flow762
                                        ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v45, v19
.LBB1_353:                              ;   in Loop: Header=BB1_341 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_cndmask_b32_e64 v43, v24, 0, vcc
	v_lshl_or_b32 v24, v43, 10, v15
	ds_read_b128 v[24:27], v24
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v49, 0xffff0000, v8
	v_lshlrev_b32_e32 v48, 16, v8
	v_and_b32_e32 v47, 0xffff0000, v9
	v_lshlrev_b32_e32 v46, 16, v9
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[24:25], v[24:25], v[48:49]
	v_pk_mul_f32 v[26:27], v[26:27], v[46:47]
	v_add_f32_e32 v24, v24, v25
	v_add_f32_e32 v24, v24, v26
	v_add_f32_e32 v24, v24, v27
	v_add_f32_e32 v23, v23, v24
	v_add_u32_e32 v24, 1, v43
	v_cmp_eq_u32_e32 vcc, s40, v24
	v_mov_b32_e32 v43, v45
	s_nop 0
	v_addc_co_u32_e64 v19, s[6:7], 0, v19, vcc
	v_cmp_ne_u32_e64 s[6:7], v19, v45
	s_and_saveexec_b64 s[28:29], s[6:7]
	s_cbranch_execz .LBB1_340
; %bb.354:                              ;   in Loop: Header=BB1_341 Depth=2
	ds_bpermute_b32 v25, v17, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	ds_swizzle_b32 v25, v23 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v25
	v_mov_b32_e32 v25, 0
	s_nop 0
	v_add_f32_dpp v23, v23, v23 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v23, v23, v23 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v25, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_339
; %bb.355:                              ;   in Loop: Header=BB1_341 Depth=2
	v_lshl_add_u32 v26, v45, 2, s51
	ds_read_b32 v27, v26
	v_add_f32_e32 v23, v23, v25
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v23, v23, v27
	ds_write_b32 v26, v23
	s_branch .LBB1_339
.LBB1_356:                              ; %Flow768
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v24, v42
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execz .LBB1_375
.LBB1_357:                              ;   in Loop: Header=BB1_333 Depth=1
	v_mov_b32_e32 v19, v5
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshl_add_u64 v[22:23], s[8:9], 0, v[18:19]
	v_lshlrev_b64 v[20:21], 9, v[24:25]
	v_lshl_add_u64 v[20:21], v[22:23], 0, v[20:21]
	global_load_dwordx2 v[20:21], v[20:21], off nt
	v_add_u32_e32 v26, 1, v24
	v_cmp_lt_i32_e64 s[8:9], v26, v42
	s_and_saveexec_b64 s[6:7], s[8:9]
	s_cbranch_execz .LBB1_359
; %bb.358:                              ;   in Loop: Header=BB1_333 Depth=1
	v_ashrrev_i32_e32 v27, 31, v26
	v_lshlrev_b64 v[2:3], 9, v[26:27]
	v_lshl_add_u64 v[2:3], v[22:23], 0, v[2:3]
	global_load_dwordx2 v[2:3], v[2:3], off nt
.LBB1_359:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_add_u32_e32 v26, 2, v24
	v_cmp_lt_i32_e64 s[6:7], v26, v42
	s_and_saveexec_b64 s[10:11], s[6:7]
	s_cbranch_execz .LBB1_361
; %bb.360:                              ;   in Loop: Header=BB1_333 Depth=1
	v_ashrrev_i32_e32 v27, 31, v26
	v_lshlrev_b64 v[8:9], 9, v[26:27]
	v_lshl_add_u64 v[8:9], v[22:23], 0, v[8:9]
	global_load_dwordx2 v[8:9], v[8:9], off nt
.LBB1_361:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_add_u32_e32 v24, 3, v24
	v_cmp_lt_i32_e32 vcc, v24, v42
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_363
; %bb.362:                              ;   in Loop: Header=BB1_333 Depth=1
	v_ashrrev_i32_e32 v25, 31, v24
	v_lshlrev_b64 v[6:7], 9, v[24:25]
	v_lshl_add_u64 v[6:7], v[22:23], 0, v[6:7]
	global_load_dwordx2 v[6:7], v[6:7], off nt
.LBB1_363:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	s_mul_i32 s10, s50, s49
	s_lshl2_add_u32 s51, s10, s17
	v_cmp_ne_u32_e64 s[10:11], v45, v43
	s_and_saveexec_b64 s[28:29], s[10:11]
	s_cbranch_execz .LBB1_367
; %bb.364:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v19, v17, v44
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v44, v19
	ds_swizzle_b32 v22, v19 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v19, v19, v19 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v19, v19, v19 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v19 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[10:11], s[0:1]
	s_cbranch_execz .LBB1_366
; %bb.365:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshl_add_u32 v23, v43, 2, s51
	ds_read_b32 v24, v23
	v_add_f32_e32 v19, v19, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v19, v19, v24
	ds_write_b32 v23, v19
.LBB1_366:                              ; %Flow757
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_mov_b32_e32 v44, 0
	v_mov_b32_e32 v43, v45
.LBB1_367:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[28:29]
	v_lshl_or_b32 v19, v46, 10, v15
	ds_read_b128 v[22:25], v19
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v27, 0xffff0000, v21
	v_lshlrev_b32_e32 v26, 16, v21
	v_and_b32_e32 v21, 0xffff0000, v20
	v_lshlrev_b32_e32 v20, 16, v20
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[22:23], v[20:21]
	v_pk_mul_f32 v[24:25], v[24:25], v[26:27]
	v_add_f32_e32 v19, v20, v21
	v_add_f32_e32 v19, v19, v24
	v_add_f32_e32 v19, v19, v25
	v_add_f32_e32 v44, v44, v19
	v_add_u32_e32 v19, 1, v46
	v_cmp_eq_u32_e64 s[10:11], s40, v19
	s_nop 1
	v_cndmask_b32_e64 v19, v19, 0, s[10:11]
	v_addc_co_u32_e64 v20, s[10:11], 0, v45, s[10:11]
	s_and_saveexec_b64 s[10:11], s[8:9]
	s_cbranch_execz .LBB1_376
; %bb.368:                              ;   in Loop: Header=BB1_333 Depth=1
	v_cmp_ne_u32_e64 s[8:9], v20, v43
	s_and_saveexec_b64 s[28:29], s[8:9]
	s_cbranch_execz .LBB1_372
; %bb.369:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v21, v17, v44
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v44, v21
	ds_swizzle_b32 v22, v21 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v21, v21, v21 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[8:9], s[0:1]
	s_cbranch_execz .LBB1_371
; %bb.370:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshl_add_u32 v23, v43, 2, s51
	ds_read_b32 v24, v23
	v_add_f32_e32 v21, v21, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v24
	ds_write_b32 v23, v21
.LBB1_371:                              ; %Flow754
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_mov_b32_e32 v44, 0
	v_mov_b32_e32 v43, v20
.LBB1_372:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[28:29]
	v_lshl_or_b32 v21, v19, 10, v15
	ds_read_b128 v[22:25], v21
	v_and_b32_e32 v47, 0xffff0000, v2
	v_lshlrev_b32_e32 v46, 16, v2
	v_and_b32_e32 v27, 0xffff0000, v3
	v_lshlrev_b32_e32 v26, 16, v3
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[46:47]
	v_pk_mul_f32 v[24:25], v[24:25], v[26:27]
	v_add_f32_e32 v21, v22, v23
	v_add_f32_e32 v21, v21, v24
	v_add_u32_e32 v19, 1, v19
	v_add_f32_e32 v21, v21, v25
	v_cmp_eq_u32_e64 s[8:9], s40, v19
	v_add_f32_e32 v44, v44, v21
	s_nop 0
	v_cndmask_b32_e64 v19, v19, 0, s[8:9]
	v_addc_co_u32_e64 v20, s[8:9], 0, v20, s[8:9]
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execnz .LBB1_377
.LBB1_373:                              ; %Flow753
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execnz .LBB1_382
	s_branch .LBB1_387
.LBB1_374:                              ; %.loopexit324
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[26:27]
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v24, v42
	s_and_saveexec_b64 s[26:27], vcc
	s_cbranch_execnz .LBB1_357
.LBB1_375:                              ; %Flow759
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[26:27]
	v_cmp_lt_i32_e32 vcc, v4, v42
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execnz .LBB1_388
	s_branch .LBB1_390
.LBB1_376:                              ; %Flow756
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execz .LBB1_373
.LBB1_377:                              ;   in Loop: Header=BB1_333 Depth=1
	v_cmp_ne_u32_e64 s[6:7], v20, v43
	s_and_saveexec_b64 s[10:11], s[6:7]
	s_cbranch_execz .LBB1_381
; %bb.378:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v21, v17, v44
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v44, v21
	ds_swizzle_b32 v22, v21 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v21, v21, v21 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_380
; %bb.379:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshl_add_u32 v23, v43, 2, s51
	ds_read_b32 v24, v23
	v_add_f32_e32 v21, v21, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v24
	ds_write_b32 v23, v21
.LBB1_380:                              ; %Flow751
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v44, 0
	v_mov_b32_e32 v43, v20
.LBB1_381:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_lshl_or_b32 v21, v19, 10, v15
	ds_read_b128 v[22:25], v21
	v_and_b32_e32 v47, 0xffff0000, v8
	v_lshlrev_b32_e32 v46, 16, v8
	v_and_b32_e32 v27, 0xffff0000, v9
	v_lshlrev_b32_e32 v26, 16, v9
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[22:23], v[46:47]
	v_pk_mul_f32 v[24:25], v[24:25], v[26:27]
	v_add_f32_e32 v21, v22, v23
	v_add_f32_e32 v21, v21, v24
	v_add_u32_e32 v19, 1, v19
	v_add_f32_e32 v21, v21, v25
	v_cmp_eq_u32_e64 s[6:7], s40, v19
	v_add_f32_e32 v44, v44, v21
	s_nop 0
	v_cndmask_b32_e64 v19, v19, 0, s[6:7]
	v_addc_co_u32_e64 v20, s[6:7], 0, v20, s[6:7]
	s_or_b64 exec, exec, s[8:9]
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_387
.LBB1_382:                              ;   in Loop: Header=BB1_333 Depth=1
	v_cmp_ne_u32_e32 vcc, v20, v43
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB1_386
; %bb.383:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v21, v17, v44
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v44, v21
	ds_swizzle_b32 v22, v21 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v22
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_add_f32_dpp v21, v21, v21 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v21, v21, v21 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v22, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[10:11], s[0:1]
	s_cbranch_execz .LBB1_385
; %bb.384:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshl_add_u32 v23, v43, 2, s51
	ds_read_b32 v24, v23
	v_add_f32_e32 v21, v21, v22
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v21, v21, v24
	ds_write_b32 v23, v21
.LBB1_385:                              ; %Flow748
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_mov_b32_e32 v44, 0
	v_mov_b32_e32 v43, v20
.LBB1_386:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_lshl_or_b32 v19, v19, 10, v15
	ds_read_b128 v[20:23], v19
	v_and_b32_e32 v27, 0xffff0000, v6
	v_lshlrev_b32_e32 v26, 16, v6
	v_and_b32_e32 v25, 0xffff0000, v7
	v_lshlrev_b32_e32 v24, 16, v7
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[20:21], v[26:27]
	v_pk_mul_f32 v[22:23], v[22:23], v[24:25]
	v_add_f32_e32 v19, v20, v21
	v_add_f32_e32 v19, v19, v22
	v_add_f32_e32 v19, v19, v23
	v_add_f32_e32 v44, v44, v19
.LBB1_387:                              ; %Flow750
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_or_b64 exec, exec, s[26:27]
	v_cmp_lt_i32_e32 vcc, v4, v42
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_390
.LBB1_388:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v4, v17, v44
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v44, v4
	ds_swizzle_b32 v19, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v19
	v_mov_b32_e32 v19, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v19, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_b64 exec, exec, s[0:1]
	s_cbranch_execz .LBB1_390
; %bb.389:                              ;   in Loop: Header=BB1_333 Depth=1
	s_mul_i32 s50, s50, s49
	s_lshl2_add_u32 s8, s50, s17
	v_lshl_add_u32 v20, v43, 2, s8
	ds_read_b32 v21, v20
	v_add_f32_e32 v4, v4, v19
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v21
	ds_write_b32 v20, v4
.LBB1_390:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_cmp_gt_i32_e32 vcc, s49, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_401
; %bb.391:                              ;   in Loop: Header=BB1_333 Depth=1
	s_lshl2_add_u32 s28, s47, s44
	s_lshl_b32 s29, s49, 2
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v4, v33
	v_mov_b32_e32 v19, v0
	s_branch .LBB1_393
.LBB1_392:                              ; %Flow743
                                        ;   in Loop: Header=BB1_393 Depth=2
	s_or_b64 exec, exec, s[10:11]
	v_bfe_u32 v20, v22, 16, 1
	v_add3_u32 v20, v20, v22, s45
	v_or_b32_e32 v21, 0x400000, v22
	v_cmp_u_f32_e32 vcc, v22, v22
	v_add_u32_e32 v4, v4, v34
	s_nop 0
	v_cndmask_b32_e32 v20, v20, v21, vcc
	v_lshl_add_u32 v21, v19, 2, s28
	v_add_u32_e32 v19, v19, v1
	v_cmp_le_i32_e32 vcc, s49, v19
	v_and_b32_e32 v20, 0xffff0000, v20
	s_or_b64 s[8:9], vcc, s[8:9]
	ds_write_b32 v21, v20
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB1_401
.LBB1_393:                              ;   Parent Loop BB1_333 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_395 Depth 3
                                        ;       Child Loop BB1_399 Depth 3
	s_mov_b64 s[26:27], -1
	v_mov_b32_e32 v22, 0
	v_mov_b32_e32 v20, 0
	s_and_saveexec_b64 s[10:11], s[2:3]
	s_cbranch_execz .LBB1_397
; %bb.394:                              ; %.preheader318
                                        ;   in Loop: Header=BB1_393 Depth=2
	v_lshl_add_u32 v20, v19, 2, s17
	s_mov_b32 s50, 0
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v22, 0
.LBB1_395:                              ;   Parent Loop BB1_333 Depth=1
                                        ;     Parent Loop BB1_393 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s51, s50, s49
	v_lshl_add_u32 v21, s51, 2, v20
	ds_read_b32 v23, v21
	v_add_u32_e32 v21, s29, v21
	v_add_u32_e32 v24, s29, v21
	ds_read_b32 v21, v21
	ds_read_b32 v25, v24
	v_add_u32_e32 v24, s29, v24
	v_add_u32_e32 v26, s29, v24
	ds_read_b32 v24, v24
	ds_read_b32 v27, v26
	v_add_u32_e32 v26, s29, v26
	v_add_u32_e32 v42, s29, v26
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v22, v22, v23
	ds_read_b32 v26, v26
	ds_read_b32 v43, v42
	v_add_u32_e32 v23, s29, v42
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v21, v22, v21
	ds_read_b32 v22, v23
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v21, v21, v25
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v21, v21, v24
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v21, v21, v27
	s_add_i32 s50, s50, 8
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v21, v21, v26
	v_cmp_eq_u32_e32 vcc, s50, v32
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v21, v21, v43
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v21, v22
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_395
; %bb.396:                              ;   in Loop: Header=BB1_393 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_orn2_b64 s[26:27], s[4:5], exec
	v_mov_b32_e32 v20, v32
.LBB1_397:                              ; %Flow742
                                        ;   in Loop: Header=BB1_393 Depth=2
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[10:11], s[26:27]
	s_cbranch_execz .LBB1_392
; %bb.398:                              ;   in Loop: Header=BB1_393 Depth=2
	v_mad_u64_u32 v[20:21], s[26:27], s29, v20, v[4:5]
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v21, v31
.LBB1_399:                              ;   Parent Loop BB1_333 Depth=1
                                        ;     Parent Loop BB1_393 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v23, v20
	v_add_u32_e32 v21, -1, v21
	v_cmp_eq_u32_e32 vcc, 0, v21
	v_add_u32_e32 v20, s29, v20
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v22, v22, v23
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_399
; %bb.400:                              ; %Flow740
                                        ;   in Loop: Header=BB1_393 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_branch .LBB1_392
.LBB1_401:                              ; %Flow746
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mov_b64 s[6:7], 0
	s_waitcnt lgkmcnt(0)
	s_barrier
.LBB1_402:                              ; %Flow795
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_and_b64 vcc, exec, s[6:7]
	s_cbranch_vccz .LBB1_332
; %bb.403:                              ;   in Loop: Header=BB1_333 Depth=1
	s_sub_i32 s48, s48, s47
	v_mul_lo_u32 v2, s48, v28
	v_readfirstlane_b32 s10, v0
	v_cmp_lt_i32_e32 vcc, v0, v2
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_406
; %bb.404:                              ; %.preheader321
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v3, v33
	v_mov_b32_e32 v4, v0
.LBB1_405:                              ;   Parent Loop BB1_333 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_add_u32_e32 v4, v4, v1
	v_cmp_ge_i32_e32 vcc, v4, v2
	ds_write_b32 v3, v5
	s_or_b64 s[8:9], vcc, s[8:9]
	v_add_u32_e32 v3, v3, v34
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execnz .LBB1_405
.LBB1_406:                              ; %Flow793
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_lshr_b32 s49, s10, 6
	s_mul_i32 s10, s48, s36
	v_add_u32_e32 v2, s10, v29
	v_sub_u32_e32 v4, 0, v2
	v_ashrrev_i32_e32 v3, 31, v2
	v_max_i32_e32 v2, v4, v2
	v_mul_hi_u32 v4, v2, v14
	v_mul_lo_u32 v6, v4, v28
	v_sub_u32_e32 v2, v2, v6
	v_add_u32_e32 v6, 1, v4
	v_cmp_ge_u32_e32 vcc, v2, v28
	s_mul_hi_i32 s7, s47, s30
	s_mul_i32 s6, s47, s30
	v_cndmask_b32_e32 v4, v4, v6, vcc
	v_sub_u32_e32 v6, v2, v28
	v_cndmask_b32_e32 v2, v2, v6, vcc
	v_add_u32_e32 v6, 1, v4
	v_cmp_ge_u32_e32 vcc, v2, v28
	s_lshl_b64 s[6:7], s[6:7], 1
	s_add_u32 s8, s42, s6
	v_cndmask_b32_e32 v2, v4, v6, vcc
	v_xor_b32_e32 v2, v2, v3
	s_addc_u32 s9, s43, s7
	s_abs_i32 s6, s36
	v_sub_u32_e32 v2, v2, v3
	v_cvt_f32_u32_e32 v3, s6
	v_mul_lo_u32 v19, s49, v2
	v_add_u32_e32 v2, v19, v2
	v_min_i32_e32 v24, s10, v2
	v_rcp_f32_e32 v2, v3
	s_sub_i32 s7, 0, s6
	v_sub_u32_e32 v4, 0, v19
	v_max_i32_e32 v4, v4, v19
	v_mul_f32_e32 v2, 0x4f7ffffe, v2
	v_cvt_u32_f32_e32 v2, v2
	v_xor_b32_e32 v3, s36, v19
	v_ashrrev_i32_e32 v3, 31, v3
	v_mov_b32_e32 v26, 0
	v_mul_lo_u32 v6, s7, v2
	v_mul_hi_u32 v6, v2, v6
	v_add_u32_e32 v2, v2, v6
	v_mul_hi_u32 v2, v4, v2
	v_mul_lo_u32 v6, v2, s6
	v_sub_u32_e32 v4, v4, v6
	v_add_u32_e32 v6, 1, v2
	v_cmp_le_u32_e32 vcc, s6, v4
	v_mov_b32_e32 v22, v19
	s_waitcnt lgkmcnt(0)
	v_cndmask_b32_e32 v2, v2, v6, vcc
	v_subrev_u32_e32 v6, s6, v4
	v_cndmask_b32_e32 v4, v4, v6, vcc
	v_add_u32_e32 v6, 1, v2
	v_cmp_le_u32_e32 vcc, s6, v4
	s_barrier
	s_nop 0
	v_cndmask_b32_e32 v2, v2, v6, vcc
	v_xor_b32_e32 v2, v2, v3
	v_sub_u32_e32 v27, v2, v3
	v_mul_lo_u32 v2, v27, s36
	v_sub_u32_e32 v42, v19, v2
	v_add_u32_e32 v2, 2, v19
	v_cmp_le_i32_e32 vcc, v2, v24
	v_mov_b32_e32 v25, v27
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_417
; %bb.407:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshlrev_b32_e32 v4, 4, v16
	s_mul_i32 s6, s49, s48
	v_lshl_add_u64 v[2:3], s[8:9], 0, v[4:5]
	s_lshl2_add_u32 s50, s6, s17
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v20, v19
	v_mov_b32_e32 v25, v27
	s_branch .LBB1_410
.LBB1_408:                              ; %Flow785
                                        ;   in Loop: Header=BB1_410 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v6, 0
	v_mov_b32_e32 v25, v4
.LBB1_409:                              ;   in Loop: Header=BB1_410 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_cndmask_b32_e64 v7, v7, 0, vcc
	v_lshl_or_b32 v21, v7, 11, v30
	ds_read_b128 v[42:45], v21
	ds_read_b128 v[46:49], v21 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v51, 0xffff0000, v10
	v_lshlrev_b32_e32 v50, 16, v10
	v_and_b32_e32 v27, 0xffff0000, v11
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[42:43], v[42:43], v[50:51]
	v_lshlrev_b32_e32 v26, 16, v11
	v_add_f32_e32 v21, 0, v42
	v_pk_mul_f32 v[26:27], v[44:45], v[26:27]
	v_add_f32_e32 v21, v21, v43
	v_and_b32_e32 v23, 0xffff0000, v12
	v_lshlrev_b32_e32 v22, 16, v12
	v_add_f32_e32 v21, v21, v26
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[46:47], v[22:23]
	v_add_f32_e32 v21, v21, v27
	v_and_b32_e32 v9, 0xffff0000, v13
	v_lshlrev_b32_e32 v8, 16, v13
	v_add_f32_e32 v21, v21, v22
	v_pk_mul_f32 v[8:9], v[48:49], v[8:9]
	v_add_f32_e32 v21, v21, v23
	v_add_f32_e32 v8, v21, v8
	v_add_f32_e32 v8, v8, v9
	v_add_f32_e32 v26, v6, v8
	v_add_u32_e32 v6, 1, v7
	v_cmp_eq_u32_e32 vcc, s36, v6
	v_add_u32_e32 v22, 2, v20
	s_nop 0
	v_cndmask_b32_e64 v42, v6, 0, vcc
	v_addc_co_u32_e32 v27, vcc, 0, v4, vcc
	v_add_u32_e32 v4, 4, v20
	v_cmp_gt_i32_e32 vcc, v4, v24
	s_or_b64 s[26:27], vcc, s[26:27]
	v_mov_b32_e32 v20, v22
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execz .LBB1_431
.LBB1_410:                              ;   Parent Loop BB1_333 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[6:7], 10, v[20:21]
	v_lshl_add_u64 v[22:23], v[2:3], 0, v[6:7]
	v_add_u32_e32 v6, 1, v20
	v_ashrrev_i32_e32 v7, 31, v6
	v_lshlrev_b64 v[6:7], 10, v[6:7]
	v_lshl_add_u64 v[44:45], v[2:3], 0, v[6:7]
	global_load_dwordx4 v[6:9], v[22:23], off nt
	global_load_dwordx4 v[10:13], v[44:45], off nt
	v_cmp_ne_u32_e32 vcc, v27, v25
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_414
; %bb.411:                              ;   in Loop: Header=BB1_410 Depth=2
	ds_bpermute_b32 v4, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v26, v4
	ds_swizzle_b32 v21, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v21
	v_mov_b32_e32 v21, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v21, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_413
; %bb.412:                              ;   in Loop: Header=BB1_410 Depth=2
	v_lshl_add_u32 v22, v25, 2, s50
	ds_read_b32 v23, v22
	v_add_f32_e32 v4, v4, v21
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v23
	ds_write_b32 v22, v4
.LBB1_413:                              ; %Flow786
                                        ;   in Loop: Header=BB1_410 Depth=2
	s_or_b64 exec, exec, s[28:29]
	v_mov_b32_e32 v26, 0
.LBB1_414:                              ;   in Loop: Header=BB1_410 Depth=2
	s_or_b64 exec, exec, s[6:7]
	v_lshl_or_b32 v4, v42, 11, v30
	ds_read_b128 v[44:47], v4
	ds_read_b128 v[48:51], v4 offset:16
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v53, 0xffff0000, v7
	v_lshlrev_b32_e32 v52, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[44:45], v[6:7]
	v_pk_mul_f32 v[46:47], v[46:47], v[52:53]
	v_add_f32_e32 v4, 0, v6
	v_add_f32_e32 v4, v4, v7
	v_and_b32_e32 v23, 0xffff0000, v9
	v_lshlrev_b32_e32 v22, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v4, v4, v46
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[48:49], v[8:9]
	v_add_f32_e32 v4, v4, v47
	v_add_f32_e32 v4, v4, v8
	v_pk_mul_f32 v[22:23], v[50:51], v[22:23]
	v_add_f32_e32 v4, v4, v9
	v_add_f32_e32 v4, v4, v22
	v_add_u32_e32 v7, 1, v42
	v_add_f32_e32 v4, v4, v23
	v_cmp_eq_u32_e32 vcc, s36, v7
	v_add_f32_e32 v6, v26, v4
	v_mov_b32_e32 v25, v27
	v_addc_co_u32_e64 v4, s[6:7], 0, v27, vcc
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_409
; %bb.415:                              ;   in Loop: Header=BB1_410 Depth=2
	ds_bpermute_b32 v8, v17, v6
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v6, v6, v8
	ds_swizzle_b32 v8, v6 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v6, v6, v8
	v_mov_b32_e32 v8, 0
	s_nop 0
	v_add_f32_dpp v6, v6, v6 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v6, v6, v6 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v6, v6, v6 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v8, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[28:29], s[0:1]
	s_cbranch_execz .LBB1_408
; %bb.416:                              ;   in Loop: Header=BB1_410 Depth=2
	v_lshl_add_u32 v9, v27, 2, s50
	ds_read_b32 v21, v9
	v_add_f32_e32 v6, v6, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v6, v6, v21
	ds_write_b32 v9, v6
	s_branch .LBB1_408
.LBB1_417:                              ; %Flow790
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v22, v24
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_432
.LBB1_418:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshlrev_b32_e32 v4, 4, v16
	v_ashrrev_i32_e32 v23, 31, v22
	v_lshl_add_u64 v[2:3], s[8:9], 0, v[4:5]
	v_lshlrev_b64 v[6:7], 10, v[22:23]
	v_lshl_add_u64 v[6:7], v[2:3], 0, v[6:7]
	global_load_dwordx4 v[6:9], v[6:7], off nt
	v_add_u32_e32 v20, 1, v22
	v_cmp_lt_i32_e32 vcc, v20, v24
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_420
; %bb.419:                              ;   in Loop: Header=BB1_333 Depth=1
	v_ashrrev_i32_e32 v21, 31, v20
	v_lshlrev_b64 v[10:11], 10, v[20:21]
	v_lshl_add_u64 v[2:3], v[2:3], 0, v[10:11]
	global_load_dwordx4 v[10:13], v[2:3], off nt
.LBB1_420:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_mul_i32 s6, s49, s48
	s_lshl2_add_u32 s28, s6, s17
	v_cmp_ne_u32_e64 s[6:7], v27, v25
	s_and_saveexec_b64 s[8:9], s[6:7]
	s_cbranch_execz .LBB1_424
; %bb.421:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v2, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v26, v2
	ds_swizzle_b32 v3, v2 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 0
	v_add_f32_dpp v2, v2, v2 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_423
; %bb.422:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshl_add_u32 v4, v25, 2, s28
	ds_read_b32 v20, v4
	v_add_f32_e32 v2, v2, v3
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v20
	ds_write_b32 v4, v2
.LBB1_423:                              ; %Flow782
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v25, v27
.LBB1_424:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[8:9]
	v_lshl_or_b32 v4, v42, 11, v30
	ds_read_b128 v[20:23], v4
	ds_read_b128 v[44:47], v4 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v49, 0xffff0000, v7
	v_lshlrev_b32_e32 v48, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[20:21], v[6:7]
	v_pk_mul_f32 v[22:23], v[22:23], v[48:49]
	v_add_f32_e32 v4, 0, v6
	v_add_f32_e32 v4, v4, v7
	v_and_b32_e32 v3, 0xffff0000, v9
	v_lshlrev_b32_e32 v2, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v4, v4, v22
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[44:45], v[8:9]
	v_add_f32_e32 v4, v4, v23
	v_add_f32_e32 v4, v4, v8
	v_pk_mul_f32 v[2:3], v[46:47], v[2:3]
	v_add_f32_e32 v4, v4, v9
	v_add_f32_e32 v2, v4, v2
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v26, v26, v2
	s_and_saveexec_b64 s[8:9], vcc
	s_cbranch_execz .LBB1_430
; %bb.425:                              ;   in Loop: Header=BB1_333 Depth=1
	v_add_u32_e32 v2, 1, v42
	v_cmp_eq_u32_e32 vcc, s36, v2
	s_nop 1
	v_addc_co_u32_e64 v3, s[6:7], 0, v27, vcc
	v_cmp_ne_u32_e64 s[6:7], v3, v25
	s_and_saveexec_b64 s[26:27], s[6:7]
	s_cbranch_execz .LBB1_429
; %bb.426:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v4, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v26, v4
	ds_swizzle_b32 v6, v4 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v6
	v_mov_b32_e32 v6, 0
	s_nop 0
	v_add_f32_dpp v4, v4, v4 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v6, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[6:7], s[0:1]
	s_cbranch_execz .LBB1_428
; %bb.427:                              ;   in Loop: Header=BB1_333 Depth=1
	v_lshl_add_u32 v7, v25, 2, s28
	ds_read_b32 v8, v7
	v_add_f32_e32 v4, v4, v6
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v8
	ds_write_b32 v7, v4
.LBB1_428:                              ; %Flow779
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_mov_b32_e32 v26, 0
	v_mov_b32_e32 v25, v3
.LBB1_429:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[26:27]
	v_lshlrev_b32_e32 v2, 11, v2
	v_cndmask_b32_e64 v2, v2, 0, vcc
	v_or_b32_e32 v4, v30, v2
	ds_read_b128 v[6:9], v4
	ds_read_b128 v[20:23], v4 offset:16
	v_and_b32_e32 v47, 0xffff0000, v10
	v_lshlrev_b32_e32 v46, 16, v10
	v_and_b32_e32 v45, 0xffff0000, v11
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[6:7], v[46:47]
	v_lshlrev_b32_e32 v44, 16, v11
	v_add_f32_e32 v4, 0, v6
	v_pk_mul_f32 v[8:9], v[8:9], v[44:45]
	v_add_f32_e32 v4, v4, v7
	v_and_b32_e32 v43, 0xffff0000, v12
	v_lshlrev_b32_e32 v42, 16, v12
	v_add_f32_e32 v4, v4, v8
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[20:21], v[20:21], v[42:43]
	v_add_f32_e32 v4, v4, v9
	v_and_b32_e32 v3, 0xffff0000, v13
	v_lshlrev_b32_e32 v2, 16, v13
	v_add_f32_e32 v4, v4, v20
	v_pk_mul_f32 v[2:3], v[22:23], v[2:3]
	v_add_f32_e32 v4, v4, v21
	v_add_f32_e32 v2, v4, v2
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v26, v26, v2
.LBB1_430:                              ; %Flow781
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[8:9]
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v19, v24
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_435
	s_branch .LBB1_433
.LBB1_431:                              ; %Flow788
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[26:27]
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v22, v24
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execnz .LBB1_418
.LBB1_432:                              ; %Flow784
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_cmp_lt_i32_e32 vcc, v19, v24
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_435
.LBB1_433:                              ;   in Loop: Header=BB1_333 Depth=1
	ds_bpermute_b32 v2, v17, v26
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v26, v2
	ds_swizzle_b32 v3, v2 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v3
	v_mov_b32_e32 v3, 0
	s_nop 0
	v_add_f32_dpp v2, v2, v2 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v2, v2, v2 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v3, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_b64 exec, exec, s[0:1]
	s_cbranch_execz .LBB1_435
; %bb.434:                              ;   in Loop: Header=BB1_333 Depth=1
	s_mul_i32 s49, s49, s48
	s_lshl2_add_u32 s8, s49, s17
	v_lshl_add_u32 v4, v25, 2, s8
	ds_read_b32 v6, v4
	v_add_f32_e32 v2, v2, v3
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v6
	ds_write_b32 v4, v2
.LBB1_435:                              ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	v_cmp_gt_i32_e32 vcc, s48, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_446
; %bb.436:                              ;   in Loop: Header=BB1_333 Depth=1
	s_lshl2_add_u32 s28, s47, s44
	s_lshl_b32 s29, s48, 2
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v2, v33
	v_mov_b32_e32 v3, v0
	s_branch .LBB1_438
.LBB1_437:                              ; %Flow774
                                        ;   in Loop: Header=BB1_438 Depth=2
	s_or_b64 exec, exec, s[10:11]
	v_bfe_u32 v6, v4, 16, 1
	v_add3_u32 v6, v6, v4, s45
	v_or_b32_e32 v7, 0x400000, v4
	v_cmp_u_f32_e32 vcc, v4, v4
	v_add_u32_e32 v2, v2, v34
	s_nop 0
	v_cndmask_b32_e32 v4, v6, v7, vcc
	v_lshl_add_u32 v6, v3, 2, s28
	v_add_u32_e32 v3, v3, v1
	v_cmp_le_i32_e32 vcc, s48, v3
	v_and_b32_e32 v4, 0xffff0000, v4
	s_or_b64 s[8:9], vcc, s[8:9]
	ds_write_b32 v6, v4
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB1_446
.LBB1_438:                              ;   Parent Loop BB1_333 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_440 Depth 3
                                        ;       Child Loop BB1_444 Depth 3
	s_mov_b64 s[26:27], -1
	v_mov_b32_e32 v4, 0
	v_mov_b32_e32 v6, 0
	s_and_saveexec_b64 s[10:11], s[2:3]
	s_cbranch_execz .LBB1_442
; %bb.439:                              ; %.preheader316
                                        ;   in Loop: Header=BB1_438 Depth=2
	v_lshl_add_u32 v6, v3, 2, s17
	s_mov_b32 s47, 0
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v4, 0
.LBB1_440:                              ;   Parent Loop BB1_333 Depth=1
                                        ;     Parent Loop BB1_438 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	s_mul_i32 s49, s47, s48
	v_lshl_add_u32 v7, s49, 2, v6
	ds_read_b32 v8, v7
	v_add_u32_e32 v7, s29, v7
	v_add_u32_e32 v9, s29, v7
	ds_read_b32 v7, v7
	ds_read_b32 v19, v9
	v_add_u32_e32 v9, s29, v9
	v_add_u32_e32 v20, s29, v9
	ds_read_b32 v9, v9
	ds_read_b32 v21, v20
	v_add_u32_e32 v20, s29, v20
	v_add_u32_e32 v22, s29, v20
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v4, v4, v8
	ds_read_b32 v20, v20
	ds_read_b32 v23, v22
	v_add_u32_e32 v8, s29, v22
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v4, v4, v7
	ds_read_b32 v7, v8
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v4, v4, v19
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v4, v4, v9
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v4, v4, v21
	s_add_i32 s47, s47, 8
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v4, v4, v20
	v_cmp_eq_u32_e32 vcc, s47, v32
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v4, v4, v23
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v7
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_440
; %bb.441:                              ;   in Loop: Header=BB1_438 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_orn2_b64 s[26:27], s[4:5], exec
	v_mov_b32_e32 v6, v32
.LBB1_442:                              ; %Flow773
                                        ;   in Loop: Header=BB1_438 Depth=2
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[10:11], s[26:27]
	s_cbranch_execz .LBB1_437
; %bb.443:                              ;   in Loop: Header=BB1_438 Depth=2
	v_mad_u64_u32 v[6:7], s[26:27], s29, v6, v[2:3]
	s_mov_b64 s[26:27], 0
	v_mov_b32_e32 v7, v31
.LBB1_444:                              ;   Parent Loop BB1_333 Depth=1
                                        ;     Parent Loop BB1_438 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ds_read_b32 v8, v6
	v_add_u32_e32 v7, -1, v7
	v_cmp_eq_u32_e32 vcc, 0, v7
	v_add_u32_e32 v6, s29, v6
	s_or_b64 s[26:27], vcc, s[26:27]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v4, v4, v8
	s_andn2_b64 exec, exec, s[26:27]
	s_cbranch_execnz .LBB1_444
; %bb.445:                              ; %Flow772
                                        ;   in Loop: Header=BB1_438 Depth=2
	s_or_b64 exec, exec, s[26:27]
	s_branch .LBB1_437
.LBB1_446:                              ; %Flow777
                                        ;   in Loop: Header=BB1_333 Depth=1
	s_or_b64 exec, exec, s[6:7]
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_cmp_lt_i32 s46, s13
	s_mov_b32 s47, s46
	s_cbranch_scc1 .LBB1_333
.LBB1_447:                              ; %Flow798
	s_andn2_b64 s[22:23], s[22:23], exec
.LBB1_448:                              ; %Flow872
	s_or_b64 exec, exec, s[24:25]
	v_mov_b64_e32 v[4:5], s[14:15]
	s_and_saveexec_b64 s[0:1], s[22:23]
	s_xor_b64 s[4:5], exec, s[0:1]
	s_cbranch_execz .LBB1_493
; %bb.449:
	s_add_i32 s39, s39, s31
	s_sub_i32 s15, s39, s31
	s_mul_i32 s6, s15, s36
	v_add_u32_e32 v5, s6, v29
	v_sub_u32_e32 v2, 0, v5
	v_max_i32_e32 v4, v2, v5
	v_mad_u64_u32 v[2:3], s[0:1], v4, v14, 0
	v_mul_lo_u32 v2, s15, v28
	v_readfirstlane_b32 s7, v0
	v_cmp_lt_i32_e32 vcc, v0, v2
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB1_452
; %bb.450:                              ; %.preheader313
	s_lshl2_add_u32 s2, s30, s34
	v_lshl_add_u32 v6, v0, 2, s2
	v_lshlrev_b32_e32 v7, 2, v1
	s_mov_b64 s[2:3], 0
	v_mov_b32_e32 v8, 0
	v_mov_b32_e32 v9, v0
.LBB1_451:                              ; =>This Inner Loop Header: Depth=1
	v_add_u32_e32 v9, v9, v1
	v_cmp_ge_i32_e32 vcc, v9, v2
	ds_write_b32 v6, v8
	s_or_b64 s[2:3], vcc, s[2:3]
	v_add_u32_e32 v6, v6, v7
	s_andn2_b64 exec, exec, s[2:3]
	s_cbranch_execnz .LBB1_451
.LBB1_452:                              ; %Flow865
	s_or_b64 exec, exec, s[0:1]
	v_ashrrev_i32_e32 v2, 31, v5
	v_mul_lo_u32 v5, v3, v28
	v_sub_u32_e32 v4, v4, v5
	v_add_u32_e32 v5, 1, v3
	v_cmp_ge_u32_e32 vcc, v4, v28
	s_sub_i32 s0, s14, s35
	s_mul_i32 s2, s0, s30
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_sub_u32_e32 v5, v4, v28
	v_cndmask_b32_e32 v4, v4, v5, vcc
	v_add_u32_e32 v5, 1, v3
	v_cmp_ge_u32_e32 vcc, v4, v28
	s_mul_hi_i32 s3, s0, s30
	s_lshr_b32 s20, s7, 6
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_xor_b32_e32 v3, v3, v2
	v_sub_u32_e32 v2, v3, v2
	s_mul_hi_i32 s1, s31, s30
	s_mul_i32 s0, s31, s30
	v_mul_lo_u32 v19, s20, v2
	s_lshl_b64 s[0:1], s[0:1], 1
	v_add_u32_e32 v2, v19, v2
	s_add_u32 s0, s37, s0
	v_min_i32_e32 v20, s6, v2
	s_addc_u32 s1, s38, s1
	v_mov_b32_e32 v2, s3
	s_abs_i32 s3, s36
	v_cvt_f32_u32_e32 v4, s3
	s_mul_i32 s6, s36, s35
	v_cmp_le_i32_e32 vcc, s6, v19
	v_and_b32_e32 v18, 63, v0
	v_rcp_f32_e32 v4, v4
	v_cndmask_b32_e32 v3, 0, v2, vcc
	v_mov_b32_e32 v2, s2
	v_cndmask_b32_e32 v2, 0, v2, vcc
	v_lshl_add_u64 v[10:11], v[2:3], 1, s[0:1]
	v_mul_f32_e32 v3, 0x4f7ffffe, v4
	v_cvt_u32_f32_e32 v3, v3
	s_sub_i32 s0, 0, s3
	v_sub_u32_e32 v4, 0, v19
	v_max_i32_e32 v4, v4, v19
	v_mul_lo_u32 v5, s0, v3
	v_mul_hi_u32 v5, v3, v5
	v_add_u32_e32 v3, v3, v5
	v_mul_hi_u32 v3, v4, v3
	v_mul_lo_u32 v5, v3, s3
	v_sub_u32_e32 v4, v4, v5
	v_add_u32_e32 v5, 1, v3
	v_cmp_le_u32_e32 vcc, s3, v4
	v_xor_b32_e32 v2, s36, v19
	v_ashrrev_i32_e32 v2, 31, v2
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_subrev_u32_e32 v5, s3, v4
	v_cndmask_b32_e32 v4, v4, v5, vcc
	v_add_u32_e32 v5, 1, v3
	v_cmp_le_u32_e32 vcc, s3, v4
	v_mov_b32_e32 v7, 0
	v_mov_b32_e32 v23, 0
	v_cndmask_b32_e32 v3, v3, v5, vcc
	v_xor_b32_e32 v3, v3, v2
	v_sub_u32_e32 v22, v3, v2
	v_mul_lo_u32 v2, v22, s36
	v_sub_u32_e32 v24, v19, v2
	v_add_u32_e32 v2, 2, v19
	v_cmp_le_i32_e32 vcc, v2, v20
	v_mov_b32_e32 v16, v19
	v_mov_b32_e32 v21, v22
	s_waitcnt lgkmcnt(0)
	s_barrier
                                        ; implicit-def: $vgpr2_vgpr3_vgpr4_vgpr5
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_463
; %bb.453:
	v_lshlrev_b32_e32 v2, 2, v0
	v_lshlrev_b32_e32 v6, 4, v18
	v_and_b32_e32 v2, 0xfc, v2
	s_mul_i32 s0, s20, s15
	v_lshl_add_u64 v[12:13], v[10:11], 0, v[6:7]
	v_lshlrev_b32_e32 v17, 5, v18
	v_xor_b32_e32 v25, 0x80, v2
	v_cmp_eq_u32_e32 vcc, 0, v18
	s_lshl2_add_u32 s21, s0, s17
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v14, v19
	v_mov_b32_e32 v21, v22
	s_branch .LBB1_456
.LBB1_454:                              ; %Flow860
                                        ;   in Loop: Header=BB1_456 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_mov_b32_e32 v7, 0
	v_mov_b32_e32 v21, v6
.LBB1_455:                              ;   in Loop: Header=BB1_456 Depth=1
	s_or_b64 exec, exec, s[2:3]
	v_cndmask_b32_e64 v15, v8, 0, s[0:1]
	v_lshl_or_b32 v16, v15, 11, v17
	ds_read_b128 v[30:33], v16
	ds_read_b128 v[34:37], v16 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v39, 0xffff0000, v2
	v_lshlrev_b32_e32 v38, 16, v2
	v_and_b32_e32 v27, 0xffff0000, v3
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[30:31], v[30:31], v[38:39]
	v_lshlrev_b32_e32 v26, 16, v3
	v_add_f32_e32 v16, 0, v30
	v_pk_mul_f32 v[26:27], v[32:33], v[26:27]
	v_add_f32_e32 v16, v16, v31
	v_and_b32_e32 v23, 0xffff0000, v4
	v_lshlrev_b32_e32 v22, 16, v4
	v_add_f32_e32 v16, v16, v26
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[22:23], v[34:35], v[22:23]
	v_add_f32_e32 v16, v16, v27
	v_and_b32_e32 v9, 0xffff0000, v5
	v_lshlrev_b32_e32 v8, 16, v5
	v_add_f32_e32 v16, v16, v22
	v_pk_mul_f32 v[8:9], v[36:37], v[8:9]
	v_add_f32_e32 v16, v16, v23
	v_add_f32_e32 v8, v16, v8
	v_add_f32_e32 v8, v8, v9
	v_add_f32_e32 v23, v7, v8
	v_add_u32_e32 v7, 1, v15
	v_cmp_eq_u32_e64 s[0:1], s36, v7
	v_add_u32_e32 v16, 2, v14
	s_nop 0
	v_cndmask_b32_e64 v24, v7, 0, s[0:1]
	v_addc_co_u32_e64 v22, s[0:1], 0, v6, s[0:1]
	v_add_u32_e32 v6, 4, v14
	v_cmp_gt_i32_e64 s[0:1], v6, v20
	s_or_b64 s[8:9], s[0:1], s[8:9]
	v_mov_b32_e32 v14, v16
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB1_477
.LBB1_456:                              ; =>This Inner Loop Header: Depth=1
	v_ashrrev_i32_e32 v15, 31, v14
	v_lshlrev_b64 v[2:3], 10, v[14:15]
	v_lshl_add_u64 v[26:27], v[12:13], 0, v[2:3]
	v_add_u32_e32 v2, 1, v14
	v_ashrrev_i32_e32 v3, 31, v2
	v_lshlrev_b64 v[2:3], 10, v[2:3]
	v_lshl_add_u64 v[30:31], v[12:13], 0, v[2:3]
	global_load_dwordx4 v[6:9], v[26:27], off nt
	global_load_dwordx4 v[2:5], v[30:31], off nt
	v_cmp_ne_u32_e64 s[0:1], v22, v21
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB1_460
; %bb.457:                              ;   in Loop: Header=BB1_456 Depth=1
	ds_bpermute_b32 v15, v25, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v15, v23, v15
	ds_swizzle_b32 v16, v15 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v15, v15, v16
	v_mov_b32_e32 v16, 0
	s_nop 0
	v_add_f32_dpp v15, v15, v15 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v15, v15, v15 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v15, v15, v15 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v16, v15 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB1_459
; %bb.458:                              ;   in Loop: Header=BB1_456 Depth=1
	v_lshl_add_u32 v21, v21, 2, s21
	ds_read_b32 v23, v21
	v_add_f32_e32 v15, v15, v16
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v15, v15, v23
	ds_write_b32 v21, v15
.LBB1_459:                              ; %Flow861
                                        ;   in Loop: Header=BB1_456 Depth=1
	s_or_b64 exec, exec, s[0:1]
	v_mov_b32_e32 v23, 0
.LBB1_460:                              ;   in Loop: Header=BB1_456 Depth=1
	s_or_b64 exec, exec, s[2:3]
	v_lshl_or_b32 v15, v24, 11, v17
	ds_read_b128 v[30:33], v15
	ds_read_b128 v[34:37], v15 offset:16
	s_waitcnt vmcnt(1)
	v_and_b32_e32 v39, 0xffff0000, v7
	v_lshlrev_b32_e32 v38, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[30:31], v[6:7]
	v_pk_mul_f32 v[32:33], v[32:33], v[38:39]
	v_add_f32_e32 v6, 0, v6
	v_add_f32_e32 v6, v6, v7
	v_and_b32_e32 v27, 0xffff0000, v9
	v_lshlrev_b32_e32 v26, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v6, v6, v32
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[34:35], v[8:9]
	v_add_f32_e32 v6, v6, v33
	v_add_f32_e32 v6, v6, v8
	v_pk_mul_f32 v[26:27], v[36:37], v[26:27]
	v_add_f32_e32 v6, v6, v9
	v_add_f32_e32 v6, v6, v26
	v_add_u32_e32 v8, 1, v24
	v_add_f32_e32 v6, v6, v27
	v_cmp_eq_u32_e64 s[0:1], s36, v8
	v_add_f32_e32 v7, v23, v6
	v_mov_b32_e32 v21, v22
	v_addc_co_u32_e64 v6, s[2:3], 0, v22, s[0:1]
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB1_455
; %bb.461:                              ;   in Loop: Header=BB1_456 Depth=1
	ds_bpermute_b32 v9, v25, v7
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v9
	ds_swizzle_b32 v9, v7 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v9
	v_mov_b32_e32 v9, 0
	s_nop 0
	v_add_f32_dpp v7, v7, v7 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v7, v7, v7 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v7, v7, v7 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v9, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_454
; %bb.462:                              ;   in Loop: Header=BB1_456 Depth=1
	v_lshl_add_u32 v15, v22, 2, s21
	ds_read_b32 v16, v15
	v_add_f32_e32 v7, v7, v9
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v7, v7, v16
	ds_write_b32 v15, v7
	s_branch .LBB1_454
.LBB1_463:                              ; %Flow863
	s_or_b64 exec, exec, s[6:7]
	v_cmp_lt_i32_e32 vcc, v16, v20
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_478
.LBB1_464:
	v_lshlrev_b32_e32 v6, 4, v18
	v_mov_b32_e32 v7, 0
	v_ashrrev_i32_e32 v17, 31, v16
	v_lshl_add_u64 v[10:11], v[10:11], 0, v[6:7]
	v_lshlrev_b64 v[6:7], 10, v[16:17]
	v_lshl_add_u64 v[6:7], v[10:11], 0, v[6:7]
	global_load_dwordx4 v[6:9], v[6:7], off nt
	v_add_u32_e32 v12, 1, v16
	v_cmp_lt_i32_e64 s[0:1], v12, v20
	s_and_saveexec_b64 s[2:3], s[0:1]
	s_cbranch_execz .LBB1_466
; %bb.465:
	v_ashrrev_i32_e32 v13, 31, v12
	v_lshlrev_b64 v[2:3], 10, v[12:13]
	v_lshl_add_u64 v[2:3], v[10:11], 0, v[2:3]
	global_load_dwordx4 v[2:5], v[2:3], off nt
.LBB1_466:
	s_or_b64 exec, exec, s[2:3]
	v_lshlrev_b32_e32 v10, 2, v0
	v_and_b32_e32 v10, 0xfc, v10
	s_mul_i32 s2, s20, s15
	v_xor_b32_e32 v10, 0x80, v10
	v_cmp_eq_u32_e32 vcc, 0, v18
	s_lshl2_add_u32 s21, s2, s17
	v_cmp_ne_u32_e64 s[2:3], v22, v21
	s_and_saveexec_b64 s[8:9], s[2:3]
	s_cbranch_execz .LBB1_470
; %bb.467:
	ds_bpermute_b32 v11, v10, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v11, v23, v11
	ds_swizzle_b32 v12, v11 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v12, v11, v12
	v_mov_b32_e32 v11, 0
	s_nop 0
	v_add_f32_dpp v12, v12, v12 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v12, v12, v12 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v12, v12, v12 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v11, v12 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB1_469
; %bb.468:
	v_lshl_add_u32 v13, v21, 2, s21
	ds_read_b32 v14, v13
	v_add_f32_e32 v11, v12, v11
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v11, v11, v14
	ds_write_b32 v13, v11
.LBB1_469:                              ; %Flow858
	s_or_b64 exec, exec, s[2:3]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v21, v22
.LBB1_470:
	s_or_b64 exec, exec, s[8:9]
	v_lshlrev_b32_e32 v11, 5, v18
	v_lshl_or_b32 v25, v24, 11, v11
	ds_read_b128 v[12:15], v25
	ds_read_b128 v[30:33], v25 offset:16
	s_waitcnt vmcnt(0)
	v_and_b32_e32 v27, 0xffff0000, v7
	v_lshlrev_b32_e32 v26, 16, v7
	v_and_b32_e32 v7, 0xffff0000, v6
	v_lshlrev_b32_e32 v6, 16, v6
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[6:7], v[12:13], v[6:7]
	v_pk_mul_f32 v[14:15], v[14:15], v[26:27]
	v_add_f32_e32 v6, 0, v6
	v_add_f32_e32 v6, v6, v7
	v_and_b32_e32 v17, 0xffff0000, v9
	v_lshlrev_b32_e32 v16, 16, v9
	v_and_b32_e32 v9, 0xffff0000, v8
	v_lshlrev_b32_e32 v8, 16, v8
	v_add_f32_e32 v6, v6, v14
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[30:31], v[8:9]
	v_add_f32_e32 v6, v6, v15
	v_add_f32_e32 v6, v6, v8
	v_pk_mul_f32 v[16:17], v[32:33], v[16:17]
	v_add_f32_e32 v6, v6, v9
	v_add_f32_e32 v6, v6, v16
	v_add_f32_e32 v6, v6, v17
	v_add_f32_e32 v23, v23, v6
	s_and_saveexec_b64 s[8:9], s[0:1]
	s_cbranch_execz .LBB1_476
; %bb.471:
	v_add_u32_e32 v6, 1, v24
	v_cmp_eq_u32_e64 s[0:1], s36, v6
	s_nop 1
	v_addc_co_u32_e64 v7, s[2:3], 0, v22, s[0:1]
	v_cmp_ne_u32_e64 s[2:3], v7, v21
	s_and_saveexec_b64 s[10:11], s[2:3]
	s_cbranch_execz .LBB1_475
; %bb.472:
	ds_bpermute_b32 v8, v10, v23
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v8, v23, v8
	ds_swizzle_b32 v9, v8 offset:swizzle(SWAP,16)
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v9, v8, v9
	v_mov_b32_e32 v8, 0
	s_nop 0
	v_add_f32_dpp v9, v9, v9 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v9, v9, v9 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v9, v9, v9 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v8, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_saveexec_b64 s[2:3], vcc
	s_cbranch_execz .LBB1_474
; %bb.473:
	v_lshl_add_u32 v10, v21, 2, s21
	ds_read_b32 v12, v10
	v_add_f32_e32 v8, v9, v8
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v8, v8, v12
	ds_write_b32 v10, v8
.LBB1_474:                              ; %Flow856
	s_or_b64 exec, exec, s[2:3]
	v_mov_b32_e32 v23, 0
	v_mov_b32_e32 v21, v7
.LBB1_475:
	s_or_b64 exec, exec, s[10:11]
	v_lshlrev_b32_e32 v6, 11, v6
	v_cndmask_b32_e64 v6, v6, 0, s[0:1]
	v_or_b32_e32 v8, v11, v6
	v_and_b32_e32 v13, 0xffff0000, v5
	v_lshlrev_b32_e32 v12, 16, v5
	v_and_b32_e32 v15, 0xffff0000, v4
	v_lshlrev_b32_e32 v14, 16, v4
	ds_read_b128 v[4:7], v8
	ds_read_b128 v[8:11], v8 offset:16
	v_and_b32_e32 v17, 0xffff0000, v3
	v_lshlrev_b32_e32 v16, 16, v3
	v_and_b32_e32 v3, 0xffff0000, v2
	v_lshlrev_b32_e32 v2, 16, v2
	s_waitcnt lgkmcnt(1)
	v_pk_mul_f32 v[2:3], v[4:5], v[2:3]
	v_pk_mul_f32 v[6:7], v[6:7], v[16:17]
	v_add_f32_e32 v2, 0, v2
	v_add_f32_e32 v2, v2, v3
	v_add_f32_e32 v2, v2, v6
	s_waitcnt lgkmcnt(0)
	v_pk_mul_f32 v[8:9], v[8:9], v[14:15]
	v_add_f32_e32 v2, v2, v7
	v_add_f32_e32 v2, v2, v8
	v_pk_mul_f32 v[10:11], v[10:11], v[12:13]
	v_add_f32_e32 v2, v2, v9
	v_add_f32_e32 v2, v2, v10
	v_add_f32_e32 v2, v2, v11
	v_add_f32_e32 v23, v23, v2
.LBB1_476:                              ; %Flow857
	s_or_b64 exec, exec, s[8:9]
	s_or_b64 exec, exec, s[6:7]
	v_cmp_lt_i32_e32 vcc, v19, v20
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB1_481
	s_branch .LBB1_479
.LBB1_477:                              ; %Flow862
	s_or_b64 exec, exec, s[8:9]
	s_or_b64 exec, exec, s[6:7]
	v_cmp_lt_i32_e32 vcc, v16, v20
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execnz .LBB1_464
.LBB1_478:                              ; %Flow859
	s_or_b64 exec, exec, s[6:7]
	v_cmp_lt_i32_e32 vcc, v19, v20
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB1_481
.LBB1_479:
	v_lshlrev_b32_e32 v2, 2, v0
	v_and_b32_e32 v2, 0xfc, v2
	v_xor_b32_e32 v2, 0x80, v2
	ds_bpermute_b32 v2, v2, v23
	v_cmp_eq_u32_e32 vcc, 0, v18
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v3, v23, v2
	ds_swizzle_b32 v4, v3 offset:swizzle(SWAP,16)
	v_mov_b32_e32 v2, 0
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v3, v3, v4
	s_nop 1
	v_add_f32_dpp v3, v3, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v3, v3, v3 row_shl:4 row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_add_f32_dpp v3, v3, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_mov_b32_dpp v2, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf
	s_and_b64 exec, exec, vcc
	s_cbranch_execz .LBB1_481
; %bb.480:
	s_mul_i32 s20, s20, s15
	s_lshl2_add_u32 s2, s20, s17
	v_lshl_add_u32 v4, v21, 2, s2
	ds_read_b32 v5, v4
	v_add_f32_e32 v2, v3, v2
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v2, v2, v5
	ds_write_b32 v4, v2
.LBB1_481:
	s_or_b64 exec, exec, s[0:1]
	v_cmp_gt_i32_e32 vcc, s15, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_and_saveexec_b64 s[6:7], vcc
	s_cbranch_execz .LBB1_492
; %bb.482:
	s_sub_i32 s2, s12, s35
	v_bfe_u32 v3, v1, 6, 3
	s_lshl2_add_u32 s3, s30, s34
	v_cmp_lt_u32_e32 vcc, 6, v29
	v_and_b32_e32 v6, 0x3f8, v28
	v_cmp_ne_u32_e64 s[0:1], 0, v3
	s_lshl_b32 s22, s15, 2
	v_lshl_add_u32 v2, v0, 2, s3
	v_lshlrev_b32_e32 v7, 2, v1
	s_mov_b64 s[8:9], 0
	v_mov_b32_e32 v8, s2
	s_movk_i32 s23, 0x7fff
	v_mov_b32_e32 v9, v0
	s_branch .LBB1_484
.LBB1_483:                              ; %Flow852
                                        ;   in Loop: Header=BB1_484 Depth=1
	s_or_b64 exec, exec, s[10:11]
	v_add_u32_e32 v4, s31, v9
	v_cmp_le_i32_e64 s[2:3], s13, v4
	v_bfe_u32 v11, v10, 16, 1
	v_subrev_u32_e32 v5, s31, v4
	v_cndmask_b32_e64 v4, 0, v8, s[2:3]
	v_add3_u32 v11, v11, v10, s23
	v_or_b32_e32 v12, 0x400000, v10
	v_cmp_u_f32_e64 s[2:3], v10, v10
	v_add_u32_e32 v9, v9, v1
	v_lshlrev_b32_e32 v5, 2, v5
	v_cndmask_b32_e64 v10, v11, v12, s[2:3]
	v_lshlrev_b32_e32 v4, 2, v4
	v_cmp_le_i32_e64 s[2:3], s15, v9
	v_and_b32_e32 v10, 0xffff0000, v10
	v_add3_u32 v4, s33, v5, v4
	s_or_b64 s[8:9], s[2:3], s[8:9]
	v_add_u32_e32 v2, v2, v7
	ds_write_b32 v4, v10
	s_andn2_b64 exec, exec, s[8:9]
	s_cbranch_execz .LBB1_492
.LBB1_484:                              ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_486 Depth 2
                                        ;     Child Loop BB1_490 Depth 2
	s_mov_b64 s[2:3], -1
	v_mov_b32_e32 v10, 0
	v_mov_b32_e32 v4, 0
	s_and_saveexec_b64 s[10:11], vcc
	s_cbranch_execz .LBB1_488
; %bb.485:                              ; %.preheader
                                        ;   in Loop: Header=BB1_484 Depth=1
	v_lshl_add_u32 v4, v9, 2, s17
	s_mov_b32 s24, 0
	s_mov_b64 s[20:21], 0
	v_mov_b32_e32 v10, 0
.LBB1_486:                              ;   Parent Loop BB1_484 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	s_mul_i32 s2, s24, s15
	v_lshl_add_u32 v5, s2, 2, v4
	ds_read_b32 v11, v5
	v_add_u32_e32 v5, s22, v5
	v_add_u32_e32 v12, s22, v5
	ds_read_b32 v5, v5
	ds_read_b32 v13, v12
	v_add_u32_e32 v12, s22, v12
	v_add_u32_e32 v14, s22, v12
	ds_read_b32 v12, v12
	ds_read_b32 v15, v14
	v_add_u32_e32 v14, s22, v14
	v_add_u32_e32 v16, s22, v14
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v10, v10, v11
	ds_read_b32 v14, v14
	ds_read_b32 v17, v16
	v_add_u32_e32 v11, s22, v16
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v5, v10, v5
	ds_read_b32 v10, v11
	s_waitcnt lgkmcnt(5)
	v_add_f32_e32 v5, v5, v13
	s_waitcnt lgkmcnt(4)
	v_add_f32_e32 v5, v5, v12
	s_waitcnt lgkmcnt(3)
	v_add_f32_e32 v5, v5, v15
	s_add_i32 s24, s24, 8
	s_waitcnt lgkmcnt(2)
	v_add_f32_e32 v5, v5, v14
	v_cmp_eq_u32_e64 s[2:3], s24, v6
	s_waitcnt lgkmcnt(1)
	v_add_f32_e32 v5, v5, v17
	s_or_b64 s[20:21], s[2:3], s[20:21]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v5, v10
	s_andn2_b64 exec, exec, s[20:21]
	s_cbranch_execnz .LBB1_486
; %bb.487:                              ;   in Loop: Header=BB1_484 Depth=1
	s_or_b64 exec, exec, s[20:21]
	s_orn2_b64 s[2:3], s[0:1], exec
	v_mov_b32_e32 v4, v6
.LBB1_488:                              ; %Flow851
                                        ;   in Loop: Header=BB1_484 Depth=1
	s_or_b64 exec, exec, s[10:11]
	s_and_saveexec_b64 s[10:11], s[2:3]
	s_cbranch_execz .LBB1_483
; %bb.489:                              ;   in Loop: Header=BB1_484 Depth=1
	v_mad_u64_u32 v[4:5], s[2:3], s22, v4, v[2:3]
	s_mov_b64 s[20:21], 0
	v_mov_b32_e32 v5, v3
.LBB1_490:                              ;   Parent Loop BB1_484 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ds_read_b32 v11, v4
	v_add_u32_e32 v5, -1, v5
	v_cmp_eq_u32_e64 s[2:3], 0, v5
	v_add_u32_e32 v4, s22, v4
	s_or_b64 s[20:21], s[2:3], s[20:21]
	s_waitcnt lgkmcnt(0)
	v_add_f32_e32 v10, v10, v11
	s_andn2_b64 exec, exec, s[20:21]
	s_cbranch_execnz .LBB1_490
; %bb.491:                              ; %Flow849
                                        ;   in Loop: Header=BB1_484 Depth=1
	s_or_b64 exec, exec, s[20:21]
	s_branch .LBB1_483
.LBB1_492:                              ; %Flow854
	s_or_b64 exec, exec, s[6:7]
	s_ashr_i32 s15, s14, 31
	s_waitcnt lgkmcnt(0)
	s_barrier
	v_mov_b64_e32 v[4:5], s[14:15]
.LBB1_493:                              ; %Flow873
	s_or_b64 exec, exec, s[4:5]
	v_add_u32_e32 v2, s31, v0
	v_cmp_gt_i32_e32 vcc, s13, v2
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB1_496
; %bb.494:
	s_ashr_i32 s0, s16, 31
	v_mul_lo_u32 v3, v5, s16
	v_mul_lo_u32 v6, v4, s0
	v_mad_u64_u32 v[4:5], s[0:1], v4, s16, 0
	v_add3_u32 v5, v5, v6, v3
	v_lshlrev_b32_e32 v0, 2, v0
	v_lshl_add_u64 v[4:5], v[4:5], 1, s[18:19]
	s_lshl_b32 s2, s12, 2
	v_lshl_add_u32 v0, s30, 2, v0
	v_lshlrev_b32_e32 v6, 2, v1
	s_mov_b64 s[0:1], 0
	s_movk_i32 s3, 0x7fff
.LBB1_495:                              ; =>This Inner Loop Header: Depth=1
	ds_read_b32 v7, v0
	v_ashrrev_i32_e32 v3, 31, v2
	v_add_u32_e32 v10, s2, v0
	v_lshl_add_u64 v[8:9], v[2:3], 1, v[4:5]
	ds_read_b32 v3, v10
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v10, 0xbfb8aa3b, v7
	v_exp_f32_e32 v10, v10
	v_add_u32_e32 v2, v2, v1
	v_cmp_le_i32_e32 vcc, s13, v2
	s_or_b64 s[0:1], vcc, s[0:1]
	v_add_f32_e32 v10, 1.0, v10
	v_div_scale_f32 v11, s[4:5], v10, v10, v7
	v_rcp_f32_e32 v13, v11
	v_div_scale_f32 v12, vcc, v7, v10, v7
	v_add_u32_e32 v0, v0, v6
	v_fma_f32 v14, -v11, v13, 1.0
	v_fmac_f32_e32 v13, v14, v13
	v_mul_f32_e32 v14, v12, v13
	v_fma_f32 v15, -v11, v14, v12
	v_fmac_f32_e32 v14, v15, v13
	v_fma_f32 v11, -v11, v14, v12
	v_div_fmas_f32 v11, v11, v13, v14
	v_div_fixup_f32 v7, v11, v10, v7
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v3, v3, v7
	v_bfe_u32 v7, v3, 16, 1
	v_or_b32_e32 v10, 0x400000, v3
	v_add3_u32 v7, v7, v3, s3
	v_cmp_u_f32_e32 vcc, v3, v3
	s_nop 1
	v_cndmask_b32_e32 v3, v7, v10, vcc
	v_lshrrev_b32_e32 v3, 16, v3
	global_store_short v[8:9], v3, off sc0 sc1
	s_andn2_b64 exec, exec, s[0:1]
	s_cbranch_execnz .LBB1_495
.LBB1_496:
	s_endpgm
.Lfunc_end1:
	.size	etx_unfused_d0, .Lfunc_end1-etx_unfused_d0
	.cfi_endproc
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel etx_unfused_d0
		.amdhsa_group_segment_fixed_size 21120
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 616
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 54
		.amdhsa_next_free_sgpr 60
		.amdhsa_accum_offset 56
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
                                        ; -- End function
	.set .Letx_unfused_d0.num_vgpr, 54
	.set .Letx_unfused_d0.num_agpr, 0
	.set .Letx_unfused_d0.numbered_sgpr, 60
	.set .Letx_unfused_d0.num_named_barrier, 0
	.set .Letx_unfused_d0.private_seg_size, 0
	.set .Letx_unfused_d0.uses_vcc, 1
	.set .Letx_unfused_d0.uses_flat_scratch, 0
	.set .Letx_unfused_d0.has_dyn_sized_stack, 0
	.set .Letx_unfused_d0.has_recursion, 0
	.set .Letx_unfused_d0.has_indirect_call, 0
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 28988
; TotalNumSgprs: 66
; NumVgprs: 54
; NumAgprs: 0
; TotalNumVgprs: 54
; ScratchSize: 0
; MemoryBound: 1
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 21120 bytes/workgroup (compile time only)
; SGPRBlocks: 8
; VGPRBlocks: 6
; NumSGPRsForWavesPerEU: 66
; NumVGPRsForWavesPerEU: 54
; AccumOffset: 56
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 2
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX90A:ACCUM_OFFSET: 13
; COMPUTE_PGM_RSRC3_GFX90A:TG_SPLIT: 0
	.text
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.set amdgpu.max_num_named_barrier, 0
	.text
	.type	__hip_cuid_6d419d575ba9abe3,@object ; @__hip_cuid_6d419d575ba9abe3
	.section	.bss,"aw",@nobits
	.globl	__hip_cuid_6d419d575ba9abe3
__hip_cuid_6d419d575ba9abe3:
	.byte	0                               ; 0x0
	.size	__hip_cuid_6d419d575ba9abe3, 1

	.ident	"Homebrew clang version 23.1.1"
	.ident	"AMD clang version 22.0.0git (https://github.com/RadeonOpenCompute/llvm-project roc-7.2.4 26084 f58b06dce1f9c15707c5f808fd002e18c2accf7e)"
	.section	".note.GNU-stack","",@progbits
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     0
    .args:
      - .offset:         0
        .size:           352
        .value_kind:     by_value
      - .offset:         352
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         356
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         360
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         364
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         366
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         368
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         370
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         372
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         374
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         392
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         400
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         408
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         416
        .size:           2
        .value_kind:     hidden_grid_dims
    .group_segment_fixed_size: 21148
    .kernarg_segment_align: 8
    .kernarg_segment_size: 608
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           etx_megakernel_d0
    .private_segment_fixed_size: 0
    .sgpr_count:     106
    .sgpr_spill_count: 16
    .symbol:         etx_megakernel_d0.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     127
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .agpr_count:     0
    .args:
      - .offset:         0
        .size:           352
        .value_kind:     by_value
      - .offset:         352
        .size:           4
        .value_kind:     by_value
      - .offset:         360
        .size:           4
        .value_kind:     hidden_block_count_x
      - .offset:         364
        .size:           4
        .value_kind:     hidden_block_count_y
      - .offset:         368
        .size:           4
        .value_kind:     hidden_block_count_z
      - .offset:         372
        .size:           2
        .value_kind:     hidden_group_size_x
      - .offset:         374
        .size:           2
        .value_kind:     hidden_group_size_y
      - .offset:         376
        .size:           2
        .value_kind:     hidden_group_size_z
      - .offset:         378
        .size:           2
        .value_kind:     hidden_remainder_x
      - .offset:         380
        .size:           2
        .value_kind:     hidden_remainder_y
      - .offset:         382
        .size:           2
        .value_kind:     hidden_remainder_z
      - .offset:         400
        .size:           8
        .value_kind:     hidden_global_offset_x
      - .offset:         408
        .size:           8
        .value_kind:     hidden_global_offset_y
      - .offset:         416
        .size:           8
        .value_kind:     hidden_global_offset_z
      - .offset:         424
        .size:           2
        .value_kind:     hidden_grid_dims
    .group_segment_fixed_size: 21120
    .kernarg_segment_align: 8
    .kernarg_segment_size: 616
    .language:       OpenCL C
    .language_version:
      - 2
      - 0
    .max_flat_workgroup_size: 1024
    .name:           etx_unfused_d0
    .private_segment_fixed_size: 0
    .sgpr_count:     66
    .sgpr_spill_count: 0
    .symbol:         etx_unfused_d0.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     54
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa-unknown-gfx942
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
